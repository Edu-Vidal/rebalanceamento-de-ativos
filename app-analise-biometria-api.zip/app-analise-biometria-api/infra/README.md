Para o procesos de desenvolvimento se fez necessário criar múltiplos projetos.
Para o utilizado como referência para integração no front:
- Principal: biometria-teste/terraform.tfstate
    - dev: biometria/dev/terraform.tfstate
- Teste de organização de VPC: biometria-teste-rds/terraform.tfstate
    - dev: biometria-teste-rds/dev/terraform.tfstate

Empacotamento de funções lambda funciona exclusivamente em sistemas Linux. Portanto, em windows é necessário executar o terraform com o WSL.
