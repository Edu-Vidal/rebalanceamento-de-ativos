# Bem vindo ao guia de contribuição

Nesse guia irei informar como configurar o seu repositório local para dar continuidade ao desenvolvimento.

# Configurando o ambiente de desenvolvimento

## Passo 1: Instalar pré-requisitos

Antes de configurar o projeto, certifique-se de ter os seguintes pré-requisitos instalados:

- [Git](https://git-scm.com/downloads): Sistema de controle de versão usado no projeto

- [Python](https://www.python.org/downloads/): Linguagem de programação usada no projeto (Python 3.8)

- [pyenv](https://github.com/pyenv/pyenv): Ferramenta de gerenciamento de versões do Python (recomendado)

- [Poetry](https://python-poetry.org/docs/#installation): Ferramenta de gerenciamento de dependências e empacotamento para Python

- [Make](https://www.gnu.org/software/make/): Ferramenta de automação de compilação (Como instalar no windows: [Make for Windows](https://www.technewstoday.com/install-and-use-make-in-windows/))

## Passo 2: Clonar o repositório

Clone o repositório do projeto para o seu computador local usando o seguinte comando:

```bash
git clone https://github.com/snlv-com-br/app-analise-biometria-api
cd app-analise-biometria-api
```

## Passo 3: Instalar dependências e configurar o ambiente

Usando o Makefile fornecido no projeto, instale as dependências e configure o ambiente executando o seguinte comando:

```bash
make setup
```

Isso criará um ambiente virtual com o Poetry, instalará as dependências necessárias e configurará o pre-commit.

#### Pre-commit Hook

Para se certificar que código enviado ao repositório está livre de erros utiliza-se o evento `pre-commit` do git para configurar o script responsável por executar o linter.

Para isso faz-se o uso do framework [pre-commit](https://pre-commit.com/).

Estabeleça a pasta `.githooks` como padrão executar os Git Hooks

```
git config core.hooksPath .githooks
```

Após cada commit as alterações serão avaliadas, caso os arquivos possuam erros um aviso será retornado, impedindo o commit.

### Formatter

Para unificar estilização do código utiliza-se o [Black](https://black.readthedocs.io/en/stable/). É recomendado integrar o formatter ao editor de sua escolha. Para o VSCode, use como referência o seguinte [post](https://dev.to/adamlombard/how-to-use-the-black-python-code-formatter-in-vscode-3lo0).

### Commits

Para todos os commits, exceto merges, utiliza-se o seguinte formato:

[gitmoji](https://gitmoji.dev/) <span style="color: green">Mensagem</span> (#Issue_Id)

Por exemplo:

- `✨ adiciona endpoint para reset de senha (#3)`

- `⬆️ atualiza versão de serverless` -> Caso não haja issue vinculada

É recomendado a extensão `gitmoji` do VSCode, para fácil acesso à referência dos emojis.
