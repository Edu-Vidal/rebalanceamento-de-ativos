import ast
import json
import os
from datetime import datetime
from enum import Enum
from secrets import compare_digest

import boto3
from aws_lambda_powertools import Logger, Metrics, Tracer
from aws_lambda_powertools.logging import correlation_paths
from aws_lambda_powertools.utilities.typing import LambdaContext
from pydantic import BaseModel, Field, ValidationError

from app.common.models.check import (
    UnicoCheckStatusType,
    UnicoCheckSuspiciousPersonEventType,
)
from app.common.models.sns_topic import (
    CheckUpdatePayload,
    TopicMessage,
    TopicMessageType,
)


class UnicoEventType(str, Enum):
    UPDATE_CHECK = "update_process"
    SUSPICIOUS_PERSON = "person_suspect"


class UnicoUpdateCheckData(BaseModel):
    id: str
    score: int
    status: UnicoCheckStatusType


class UnicoSuspiciousPersonData(BaseModel):
    code: str
    type: UnicoCheckSuspiciousPersonEventType


class UnicoUpdateCheckEventInput(BaseModel):
    event_date: datetime = Field(..., alias="eventDate")
    data: UnicoUpdateCheckData
    event: UnicoEventType = Field(default=UnicoEventType.UPDATE_CHECK, const=True)

    class Config:
        json_encoders = {
            datetime: lambda x: x.isoformat(timespec="seconds"),
        }


class UnicoSuspiciousPersonEventInput(BaseModel):
    event_date: datetime = Field(..., alias="eventDate")
    data: UnicoSuspiciousPersonData
    event: UnicoEventType = Field(default=UnicoEventType.SUSPICIOUS_PERSON, const=True)

    class Config:
        json_encoders = {
            datetime: lambda x: x.isoformat(timespec="seconds"),
        }


logger: Logger = Logger()
metrics: Metrics = Metrics(namespace="Biometria", service="unico-webhook")
metrics.set_default_dimensions(environment="development")
tracer: Tracer = Tracer()

sns = boto3.client("sns")

sns_topic_arn = os.environ["SNS_TOPIC_ARN"]
webhook_secret = os.environ["WEBHOOK_SECRET"]

event_parser = {
    UnicoEventType.UPDATE_CHECK: UnicoUpdateCheckEventInput,
    UnicoEventType.SUSPICIOUS_PERSON: UnicoSuspiciousPersonEventInput,
}


@logger.inject_lambda_context(
    log_event=True,
    correlation_id_path=correlation_paths.LAMBDA_FUNCTION_URL,
    clear_state=True,
)
@tracer.capture_lambda_handler
def lambda_handler(event: dict, context: LambdaContext) -> dict:
    secret_received = event.get("headers", {}).get("authorization", "")
    secret_received = secret_received.split(" ")[-1]
    if not compare_digest(secret_received, webhook_secret):
        logger.exception(f"Invalid secret: {secret_received}")
        raise ValueError("Invalid secret")

    event_body = event.get("body", {})
    if isinstance(event_body, str):
        event_body = ast.literal_eval(event_body)
    if not isinstance(event_body, dict):
        logger.exception(f"Invalid event body type: {event_body}")
        raise ValueError(f"Invalid event body type: {event_body}")

    event_type = event_body.get("event", "")
    if event_type not in UnicoEventType.__members__.values():
        logger.exception(f"Handler não definido para evento: {event_type}")
        raise ValueError(f"Handler não definido para evento: {event_type}")

    unico_event_type = UnicoEventType(event_type)
    try:
        unico_event: UnicoUpdateCheckEventInput | UnicoSuspiciousPersonEventInput = (
            event_parser[unico_event_type](**event_body)
        )
    except ValidationError as e:
        logger.exception(f"Erro ao validar evento: {event_body}\nErro: {e}")
        raise ValueError(f"Erro ao validar evento: {event_body}\nErro: {e}") from e

    message = TopicMessage(
        message_type=TopicMessageType.UPDATE_UNICO_CHECK,  # TODO: implementar para SUSPICIOUS_PERSON # noqa
        check_update_payload=CheckUpdatePayload(
            unico_id=unico_event.data.id,
            score=unico_event.data.score,
            status=unico_event.data.status,
        ),
    )
    response = sns.publish(
        TopicArn=sns_topic_arn,
        Message=message.json(),
    )

    logger.info(f"Message published to SNS: {response}")

    return {
        "statusCode": 200,
        "body": json.dumps({"message": "Event processed successfully"}),
    }
