import os

from aws_lambda_powertools.metrics import MetricUnit
from fastapi import FastAPI, status
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse
from fastapi_async_sqlalchemy import (
    SQLAlchemyMiddleware,  # provide access to a database session
)
from fastapi_pagination import add_pagination
from mangum import Mangum
from starlette.exceptions import ExceptionMiddleware

from app.api_rest.router import LoggerRouteHandler
from app.api_rest.v1.api import router as api_v1_router
from app.common.db.session import engine
from app.utils.utils import logger, metrics, tracer

stage = os.getenv("STAGE")
app = FastAPI(
    root_path=f"/{stage}" if stage else "",
)

origins = ["*"]
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_origin_regex="https?://localhost:[0-9]+",
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
app.add_middleware(ExceptionMiddleware, handlers=app.exception_handlers)
# once the SQLAlchemyMiddleware is applied, any route can
# then access the database session from the global ``db``
app.add_middleware(SQLAlchemyMiddleware, custom_engine=engine)

add_pagination(app)

app.include_router(api_v1_router, prefix="/v1")
app.router.route_class = LoggerRouteHandler


@app.exception_handler(Exception)
async def unhandled_exception_handler(_request, _err):
    metrics.add_metric(name="UnhandledExceptions", unit=MetricUnit.Count, value=1)
    logger.exception("Unhandled exception")
    return JSONResponse(
        status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
        content={"detail": "Internal Server Error"},
    )


handler = Mangum(app)
# Add tracing
handler.__name__ = "handler"  # tracer requires __name__ to be set
handler = tracer.capture_lambda_handler(handler)
# Add logging
handler = logger.inject_lambda_context(handler, clear_state=True, log_event=True)
# Add metrics
handler = metrics.log_metrics(handler, capture_cold_start_metric=True)


def debug():
    import uvicorn

    # app.add_middleware(
    #     PyInstrumentProfilerMiddleware,
    app.debug = True
    uvicorn.run(
        "app.main:app",
        host="0.0.0.0",  # noqa: S104
        port=int(os.getenv("PORT", "8000")),
        reload=True,
    )


if __name__ == "__main__":
    debug()
