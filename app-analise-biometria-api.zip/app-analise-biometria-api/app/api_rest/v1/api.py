from fastapi import APIRouter

from .endpoints import (
    accounts,
    billings,
    unico_checks,
    users,
)

router = APIRouter()
router.include_router(accounts.router, prefix="/accounts", tags=["Accounts"])
router.include_router(users.router, prefix="/users", tags=["Users"])
router.include_router(unico_checks.router, prefix="/unico", tags=["UnicoChecks"])
router.include_router(billings.router, prefix="/billings", tags=["Billings"])
