import asyncio
import io
from datetime import datetime
from uuid import UUID

import pandas as pd
from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from fastapi.responses import JSONResponse, RedirectResponse
from fastapi_pagination import Page, Params

from app.api_rest import deps
from app.api_rest.deps import TokenClaims
from app.common.crud import unico_check_crud as db
from app.common.managers.file_sharing import create_presigned_url, upload_file_to_s3
from app.common.managers.unico import create_unico_check, create_unico_sms_check
from app.common.models.account import AccountRead
from app.common.models.check import (
    DocumentType,
    UnicoCheckCreate,
    UnicoCheckRead,
    UnicoCheckStatusType,
    UnicoCheckType,
    UnicoRate,
)
from app.common.models.enum import RoleType
from app.common.models.input import (
    BiometriaCheckInput,
    BiometriaSMSCheckInput,
)
from app.common.models.output import Message
from app.common.models.report import UnicoCheckCount, UnicoHistory, UnicoRanking
from app.common.models.tables import UnicoCheck
from app.utils.utils import sqlmodel_to_df

router = APIRouter()


@router.post("/checks", response_model=Message)
async def create_check_route(
    check_input: BiometriaCheckInput,
    token_claims: TokenClaims = Depends(deps.get_current_user()),
) -> Response:
    """
    Rota para iniciar uma análise de biometria.
    """
    unico_id = create_unico_check(check_input.payload).id
    check_create = UnicoCheckCreate(
        unico_id=unico_id,
        check_type=UnicoCheckType.BIOMETRIA,
        created_by_id=token_claims.user_id,
        billed_account_id=token_claims.account_id,
        name=check_input.name,
        document_type=DocumentType.CPF,
        document=check_input.cpf,
        status=UnicoCheckStatusType.PENDING,
    )

    check = await db.create_unico_check(check_create)

    return JSONResponse(
        content={"detail": f"Análise iniciada com sucesso. Id: {check.check_id}"}
    )


@router.post("/checks/sms", response_model=Message)
async def create_sms_check_route(
    sms_check_input: BiometriaSMSCheckInput,
    token_claims: TokenClaims = Depends(deps.get_current_user()),
) -> Response:
    """
    Rota para iniciar uma análise de biometria por SMS.
    """
    unico_id = create_unico_sms_check(sms_check_input.payload).id
    check_create = UnicoCheckCreate(
        unico_id=unico_id,
        check_type=UnicoCheckType.BIOMETRIA_SMS,
        created_by_id=token_claims.user_id,
        billed_account_id=token_claims.account_id,
        name=sms_check_input.name,
        document_type=DocumentType.CPF,
        document=sms_check_input.cpf,
        status=UnicoCheckStatusType.PENDING,
    )

    check = await db.create_unico_check(check_create)

    return JSONResponse(
        content={"detail": f"Análise iniciada com sucesso. Id: {check.check_id}"}
    )


@router.get("/checks", response_model=Page[UnicoCheckRead])
async def get_unico_checks(
    account_id: UUID | None = None,
    order_by: str = Depends(deps.get_order_by(model=UnicoCheckRead), use_cache=True),
    desc: bool = True,
    name: str | None = None,
    created_after: datetime | None = None,
    created_before: datetime | None = None,
    score_min: int | None = None,
    score_max: int | None = None,
    check_types: list[UnicoCheckType] | None = Query(None, alias="check_type"),
    status_types: list[UnicoCheckStatusType] | None = Query(None, alias="status_type"),
    params=Depends(Params),
    token_claims: TokenClaims = Depends(
        deps.get_current_user(required_roles=[RoleType.SA])
    ),
) -> Page[UnicoCheck]:
    """
    Retorna todas análises de todas as contas.
    Tamanho da resposta pode exceder limite de lambda (256 KB)
    Para evitar erros, computa filtragem para período de 1 mês.
    """
    return await db.get_unico_checks_paginated(
        order_by=order_by,
        descending=desc,
        name=name,
        created_after=created_after,
        created_before=created_before,
        score_min=score_min,
        score_max=score_max,
        check_types=check_types,
        status=status_types,
        params=params,
    )


@router.get("/checks/{check_id}")
async def get_unico_check(
    check_id: UUID,
    token_claims: TokenClaims = Depends(deps.get_current_user()),
) -> UnicoCheckRead:
    """
    Retorna os detalhes de uma análise biométrica.
    A análise é especificada pelo check_id na URL.
    """
    check = await db.get_unico_check(check_id=check_id)
    if not check:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Análise não encontrada"
        )

    user_is_admin = token_claims.role == RoleType.SA
    users_account_made_check = (
        token_claims.account_id == check.billed_account.account_id
    )
    if not (user_is_admin or users_account_made_check):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    return UnicoCheckRead.from_orm(check)


@router.delete("/checks/{check_id}", response_model=Message)
async def delete_unico_check(
    check_id: UUID,
    token_claims: TokenClaims = Depends(deps.get_current_user()),
) -> Response:
    """
    Exclui uma verificação de biometria específica.
    A verificação é especificada pelo check_id na URL.
    """
    user_is_admin = token_claims.role == RoleType.SA
    if not user_is_admin:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    check = await db.get_unico_check(check_id=check_id)
    if not check:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Análise não encontrada"
        )

    await db.delete_unico_check(check)

    return JSONResponse(content={"detail": f"Processo {check_id} deletado com sucesso"})


@router.get("/report")
async def get_report(
    account_id: UUID | None = None,
    created_after: datetime | None = None,
    created_before: datetime | None = None,
    token_claims: TokenClaims = Depends(deps.get_current_user()),
) -> UnicoCheckCount:
    """
    Rota para gerar contagem de análises com base no período.
    É possível filtragem por conta.
    Caso um account_id não seja passado, retorna relatório de toda a plataforma.
    """
    user_is_admin = token_claims.role == RoleType.SA
    query_whole_platform = not account_id
    user_belongs_to_selected_account = (
        account_id and token_claims.account_id == account_id
    )
    if (
        query_whole_platform or (account_id and not user_belongs_to_selected_account)
    ) and not user_is_admin:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    tasks = [
        db.get_unico_check_count(
            account_id,
            created_after=created_after,
            created_before=created_before,
            check_types=[UnicoCheckType.BIOMETRIA],
            status=[UnicoCheckStatusType.CONCLUDED],
        ),
        db.get_unico_check_count(
            account_id,
            created_after=created_after,
            created_before=created_before,
            check_types=[UnicoCheckType.BIOMETRIA_SMS],
            status=[UnicoCheckStatusType.CONCLUDED],
        ),
    ]

    tasks = await asyncio.gather(*tasks)

    return UnicoCheckCount(
        sms=tasks[1],
        standard=tasks[0],
    )


@router.get("/ranking")
async def get_checks_ranking(
    created_after: datetime | None = None,
    created_before: datetime | None = None,
    limit: int = 5,
    desc: bool = True,
    token_claims: TokenClaims = Depends(
        deps.get_current_user(required_roles=[RoleType.SA])
    ),
) -> UnicoRanking:
    """
    Rota responsável pelo ranking de contas por análises.
    """
    result = await db.get_unico_check_count_by_account(
        created_after=created_after,
        created_before=created_before,
        check_types=[UnicoCheckType.BIOMETRIA, UnicoCheckType.BIOMETRIA_SMS],
        status=[UnicoCheckStatusType.CONCLUDED],
        limit=limit,
        descending=desc,
    )

    ranking = {}
    for n, item in enumerate(result.items(), start=1):
        _, check_count_info = item
        ranking[n] = {}
        ranking[n]["account"] = AccountRead.from_orm(check_count_info["account"])
        ranking[n]["check_count"] = UnicoCheckCount(
            sms=check_count_info.get(UnicoCheckType.BIOMETRIA_SMS, 0),
            standard=check_count_info.get(UnicoCheckType.BIOMETRIA, 0),
        )

    return UnicoRanking(ranking=ranking)


@router.get("/history")
async def get_history(
    account_id: UUID | None = None,
    token_claims: TokenClaims = Depends(deps.get_current_user()),
) -> UnicoHistory:
    """
    Rota para recuperar o histórico de relatórios por mês.
    """
    user_is_admin = token_claims.role == RoleType.SA
    query_whole_platform = not account_id
    user_belongs_to_selected_account = (
        account_id and token_claims.account_id == account_id
    )
    if (
        query_whole_platform or (account_id and not user_belongs_to_selected_account)
    ) and not user_is_admin:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    result = await db.get_unico_check_count_by_month(
        account_id=account_id,
        check_types=[UnicoCheckType.BIOMETRIA, UnicoCheckType.BIOMETRIA_SMS],
        status=[UnicoCheckStatusType.CONCLUDED],
    )

    history = {}
    for year, months_count in result.items():
        history[year] = {}
        for month, count in months_count.items():
            history[year][month] = UnicoCheckCount(
                sms=count.get(UnicoCheckType.BIOMETRIA_SMS, 0),
                standard=count.get(UnicoCheckType.BIOMETRIA, 0),
            )

    return UnicoHistory(history=history)


@router.get("/excel")
async def get_excel(
    account_id: UUID | None = None,
    order_by: str = Depends(deps.get_order_by(model=UnicoCheckRead), use_cache=True),
    desc: bool = True,
    name: str | None = None,
    created_after: datetime | None = None,
    created_before: datetime | None = None,
    score_min: int | None = None,
    score_max: int | None = None,
    check_types: list[UnicoCheckType] | None = Query(None, alias="check_type"),
    status_types: list[UnicoCheckStatusType] | None = Query(None, alias="status_type"),
    token_claims: TokenClaims = Depends(
        deps.get_current_user(required_roles=[RoleType.SA])
    ),
) -> RedirectResponse:
    """
    Rota para gerar relatório de análises em EXCEL.
    """
    user_is_admin = token_claims.role == RoleType.SA
    query_whole_platform = not account_id
    user_belongs_to_selected_account = (
        account_id and token_claims.account_id == account_id
    )
    if (
        query_whole_platform or (account_id and not user_belongs_to_selected_account)
    ) and not user_is_admin:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    # Se não houver intervalo de tempo ou for maior que 1 mês, retorna erro
    if created_after and created_before:
        delta = created_before - created_after
        if delta.days > 31:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Intervalo de tempo muito grande. Máximo de 1 mês.",
            )

    if not created_after:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="É necessário informar a data inicial. O intervalo não deve ultrapassar 1 mês.",  # noqa
        )

    checks = await db.get_unico_checks(
        account_id,
        created_after=created_after,
        created_before=created_before,
        check_types=check_types,
        status=status_types,
        order_by=order_by,
        descending=desc,
        name=name,
        score_min=score_min,
        score_max=score_max,
    )

    df = sqlmodel_to_df(checks)

    file_name = f"historico_{datetime.now().strftime('%Y-%m-%d_%H-%M-%S')}.xlsx"
    content_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    # Cria arquivo EXCEL
    buffer: io.BytesIO = io.BytesIO()
    with pd.ExcelWriter(buffer) as writer:
        df.to_excel(writer, sheet_name="Histórico de consumo - UNICO", index=True)
    buffer.seek(0)

    object_key = upload_file_to_s3(
        file_obj=buffer,
        object_name=file_name,
        content_type=content_type,
    )

    presigned_url = create_presigned_url(
        object_name=object_key,
    )

    return RedirectResponse(url=presigned_url)


@router.get("/rates")
async def get_rates(
    token_claims: TokenClaims = Depends(deps.get_current_user()),
) -> UnicoRate:
    return UnicoRate()
