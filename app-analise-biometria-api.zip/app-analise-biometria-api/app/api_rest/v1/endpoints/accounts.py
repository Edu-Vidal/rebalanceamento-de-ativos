from datetime import datetime
from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from fastapi.responses import JSONResponse
from fastapi_pagination import Page, Params

from app.api_rest import deps
from app.api_rest.deps import TokenClaims
from app.common.crud import account_crud as db
from app.common.crud import unico_check_crud, user_crud
from app.common.models.account import AccountCreate, AccountRead, AccountUpdate
from app.common.models.check import (
    UnicoCheckRead,
    UnicoCheckStatusType,
    UnicoCheckType,
)
from app.common.models.enum import RoleType
from app.common.models.input import AccountCreateInput, AccountUpdateInput
from app.common.models.output import Message
from app.common.models.tables import Account, UnicoCheck, User
from app.common.models.user import UserRead

router = APIRouter()


@router.post("/")
async def create_account(
    account_create_input: AccountCreateInput,
    api_key: str = Depends(deps.api_key_auth),
) -> AccountRead:
    """
    Rota para criar uma nova conta/locadora.
    """
    account_create = AccountCreate(
        account_id=account_create_input.account_id,
        account_name=account_create_input.account_name,
        cnpj=account_create_input.cnpj,
    )
    account = await db.create_account(account_create)

    return AccountRead.from_orm(account)


@router.put("/{account_id}")
async def update_account(
    account_id: UUID,
    account_update_payload: AccountUpdateInput,
    api_key: str = Depends(deps.api_key_auth),
) -> AccountRead:
    """
    Rota para atualizar uma conta específica.
    Somente remoção de permissões são propagadas para usuários. Idempotente.
    """
    current_account = await db.get_account_by_id(account_id)
    if not current_account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Conta não encontrada"
        )

    new_account = AccountUpdate.from_orm(
        current_account, update=account_update_payload.dict(exclude_unset=True)
    )

    account_updated = await db.update_account(current_account, new_account)

    return AccountRead.from_orm(account_updated)


@router.delete("/{account_id}", response_model=Message)
async def delete_account(
    account_id: UUID,
    api_key: str = Depends(deps.api_key_auth),
) -> Response:
    """
    Rota para deletar uma conta específica.
    Contas deletadas são mantidas no banco de dados, mas não podem ser recuperadas.
    Efeito é propagado para usuários.
    """
    account = await db.get_account_by_id(account_id)
    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Conta não encontrada"
        )

    await db.delete_account(account)

    return JSONResponse(content={"detail": "Conta deletada com sucesso"})


@router.get("/{account_id}")
async def get_account(
    account_id: UUID,
    token_claims: TokenClaims = Depends(
        deps.get_current_user(required_roles=[RoleType.SA])
    ),
) -> AccountRead:
    """
    Rota para buscar uma conta específica.
    """
    account = await db.get_account_by_id(account_id)
    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Conta não encontrada"
        )
    return AccountRead.from_orm(account)


@router.get("/", response_model=Page[AccountRead])
async def get_accounts(
    params: Params = Depends(),
    token_claims: TokenClaims = Depends(
        deps.get_current_user(required_roles=[RoleType.SA])
    ),
    order_by: str = Depends(deps.get_order_by(model=AccountRead), use_cache=True),
    desc: bool = True,
    account_name: str | None = None,
) -> Page[Account]:
    """
    Rota para listar as contas cadastradas.
    """
    return await db.get_accounts_paginated(
        params,
        order_by=order_by,
        descending=desc,
        account_name_contains=account_name,
    )


# Users
@router.get("/{account_id}/users", response_model=Page[UserRead])
async def list_account_users(
    account_id: UUID,
    params: Params = Depends(),
    token_claims: TokenClaims = Depends(
        deps.get_current_user(required_roles=[RoleType.SA])
    ),
    order_by: str = Depends(deps.get_order_by(model=UserRead), use_cache=True),
    desc: bool = True,
    user_name: str | None = None,
    email: str | None = None,
) -> Page[User]:
    """
    Rota para listar todos os usuários de uma conta específica.
    """
    return await user_crud.get_users_paginated(
        params=params,
        account_id=account_id,
        order_by=order_by,
        descending=desc,
        user_name_contains=user_name,
        email_contains=email,
    )


@router.get("/{account_id}/unico_checks", response_model=Page[UnicoCheckRead])
async def get_unico_checks_from_account(
    account_id: UUID,
    order_by: str = Depends(deps.get_order_by(model=UnicoCheckRead), use_cache=True),
    desc: bool = True,
    name: str | None = None,
    score_min: int | None = None,
    score_max: int | None = None,
    created_after: datetime | None = None,
    created_before: datetime | None = None,
    check_types: list[UnicoCheckType] | None = Query(None, alias="check_type"),
    status_types: list[UnicoCheckStatusType] | None = Query(None, alias="status_type"),
    token_claims: TokenClaims = Depends(deps.get_current_user()),
    params: Params = Depends(),
) -> Page[UnicoCheck]:
    """
    Rota para listar todas as análises de uma conta específica.
    """
    if token_claims.role != RoleType.SA and token_claims.account_id != account_id:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    return await unico_check_crud.get_unico_checks_paginated(
        account_id=account_id,
        order_by=order_by,
        descending=desc,
        name=name,
        score_min=score_min,
        score_max=score_max,
        created_after=created_after,
        created_before=created_before,
        check_types=check_types,
        status=status_types,
        params=params,
    )
