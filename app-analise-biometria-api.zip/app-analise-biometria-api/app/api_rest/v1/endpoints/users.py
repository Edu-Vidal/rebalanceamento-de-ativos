from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Response, status
from fastapi.responses import JSONResponse
from fastapi_pagination import Page, Params
from pydantic import EmailStr

from app.api_rest import deps
from app.api_rest.deps import TokenClaims
from app.common.crud import account_crud
from app.common.crud import user_crud as db
from app.common.models.enum import RoleType
from app.common.models.input import (
    UserCreateInput,
    UserUpdateInput,
)
from app.common.models.output import (
    CreatedUserOutput,
    Message,
)
from app.common.models.tables import User
from app.common.models.user import UserCreate, UserRead, UserUpdate

router = APIRouter()


@router.get("/", response_model=Page[UserRead])
async def get_users(
    params: Params = Depends(),
    order_by: str = Depends(deps.get_order_by(model=UserRead), use_cache=True),
    desc: bool = True,
    user_name: str | None = None,
    email: str | None = None,
    token_claims: TokenClaims = Depends(
        deps.get_current_user(required_roles=[RoleType.SA])
    ),
) -> Page[User]:
    """
    Rota para obter todos os usuários.
    """
    return await db.get_users_paginated(
        params=params,
        order_by=order_by,
        descending=desc,
        user_name_contains=user_name,
        email_contains=email,
    )


@router.get("/{user_id}")
async def get_user(
    user_id: UUID,
    token_claims: TokenClaims = Depends(deps.get_current_user()),
) -> UserRead:
    """
    Rota para obter um usuário específico.
    """
    user = await db.get_user_by_id(user_id)

    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Usuário não encontrado"
        )

    own_information = token_claims.user_id == user_id
    user_is_account_manager = (
        token_claims.account_id == user.account.account_id
        and token_claims.role == RoleType.ADMIN
    )
    user_is_admin = token_claims.role == RoleType.SA

    if not (own_information or user_is_account_manager or user_is_admin):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    return UserRead.from_orm(user)


@router.post("/")
async def create_user(
    user_create_input: UserCreateInput,
    api_key: str = Depends(deps.api_key_auth),
) -> CreatedUserOutput:
    """
    Rota para criar um novo usuário.
    """
    account = await account_crud.get_account_by_id(user_create_input.account_id)
    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Locadora não encontrada"
        )

    user_create = UserCreate(
        account_id=account.account_id,
        user_id=user_create_input.user_id,
        user_name=user_create_input.user_name,
        email=EmailStr(user_create_input.email),
    )

    user = await db.create_user(user_create)

    return CreatedUserOutput(
        detail=f"Usuário {user.user_name} criado com sucesso",
        user=UserRead.from_orm(user),
    )


@router.put("/{user_id}")
async def update_user(
    user_id: UUID,
    user_update_payload: UserUpdateInput,
    api_key: str = Depends(deps.api_key_auth),
) -> UserRead:
    """
    Rota para atualizar um usuário.
    """
    user_to_update = await db.get_user_by_id(user_id)
    if not user_to_update:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Usuário não encontrado"
        )

    new_user = UserUpdate.from_orm(
        user_to_update, update=user_update_payload.dict(exclude_unset=True)
    )
    updated_user = await db.update_user(user_to_update, new_user)

    return UserRead.from_orm(updated_user)


@router.delete("/{user_id}", response_model=Message)
async def delete_user(
    user_id: UUID,
    api_key: str = Depends(deps.api_key_auth),
) -> Response:
    """
    Rota para deletar um usuário.
    """
    user = await db.get_user_by_id(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Usuário não encontrado"
        )

    user_update = UserUpdate.from_orm(user, update={"deleted": True})

    await db.update_user(user, user_update)

    return JSONResponse(content={"detail": f"Usuário {user_id} deletado com sucesso"})
