import io
from datetime import date, datetime, timedelta

import pandas as pd
from fastapi import APIRouter, Depends, HTTPException
from fastapi.responses import RedirectResponse

from app.api_rest import deps
from app.api_rest.deps import TokenClaims
from app.common.crud import unico_check_crud
from app.common.managers.file_sharing import create_presigned_url, upload_file_to_s3
from app.common.models.check import (
    UnicoCheckStatusType,
    UnicoCheckType,
    UnicoRate,
)
from app.common.models.enum import RoleType

router = APIRouter()


@router.get("/unico/{account_id}/invoices")
async def get_unico_invoices(
    token_claims: TokenClaims = Depends(
        deps.get_current_user(required_permissions=[RoleType.SA])
    ),
):
    """
    Rota para recuperar todas as faturas de uma conta específica.
    AINDA NÃO IMPLEMENTADO
    """
    # Search database for invoice entries
    # Get S3 download URL for each invoice
    # Return invoice data with download URLs
    raise HTTPException(status_code=501, detail="Not implemented")


@router.get("/unico/{account_id}/invoices/{year}/{month}")
async def get_unico_invoice(
    year: int = date.today().year,
    month: int = date.today().month,
    token_claims: TokenClaims = Depends(
        deps.get_current_user(required_permissions=[RoleType.SA])
    ),
):
    """
    Rota para recuperar uma fatura específica de uma conta, baseada no ano e mês.
    AINDA NÃO IMPLEMENTADO
    """
    raise HTTPException(status_code=501, detail="Not implemented")


@router.get("/unico")
async def get_unico_consumption(
    token_claims: TokenClaims = Depends(
        deps.get_current_user(required_roles=[RoleType.SA])
    ),
) -> RedirectResponse:
    """
    Retorna o consumo de API para serviços da Unico.
    Dados do último mês completo.
    Resultado em EXCEL.
    """
    today = datetime.today().replace(hour=0, minute=0, second=0, microsecond=0)

    first_day_this_month = today.replace(day=1)
    last_day_last_month = first_day_this_month - timedelta(days=1)
    first_day_last_month = last_day_last_month.replace(day=1)

    created_after = first_day_last_month
    created_before = first_day_this_month

    month_check_count = await unico_check_crud.get_unico_check_count_by_account(
        created_after=created_after,
        created_before=created_before,
        status=[UnicoCheckStatusType.CONCLUDED],
    )

    df_data = {}
    for i, check_count_info in enumerate(month_check_count.values(), start=1):
        account_name = check_count_info["account"].account_name
        biometria_check_count = check_count_info.get(UnicoCheckType.BIOMETRIA, 0)
        sms_check_count = check_count_info.get(UnicoCheckType.BIOMETRIA_SMS, 0)

        biometria_check_value = UnicoRate().standard * biometria_check_count / 100
        sms_check_value = UnicoRate().sms * sms_check_count / 100

        total_check_count = biometria_check_count + sms_check_count
        total_value = biometria_check_value + sms_check_value

        df_data[i] = {
            "Locadora": account_name,
            "Análises biometria": biometria_check_count,
            "Análises SMS": sms_check_count,
            "Contagem de Análises": total_check_count,
            "Custo Total": total_value,
        }

    df = pd.DataFrame.from_dict(df_data, orient="index")

    file_name = (
        f"relatorio_UNICO_{first_day_last_month.month}-{first_day_last_month.year}.xlsx"
    )
    content_type = "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"

    buffer: io.BytesIO = io.BytesIO()
    with pd.ExcelWriter(buffer) as writer:
        df.to_excel(writer, sheet_name="Relatório de consumo - UNICO", index=True)
    buffer.seek(0)

    object_key = upload_file_to_s3(
        file_obj=buffer,
        object_name=file_name,
        content_type=content_type,
    )

    presigned_url = create_presigned_url(
        object_name=object_key,
    )

    return RedirectResponse(url=presigned_url)
