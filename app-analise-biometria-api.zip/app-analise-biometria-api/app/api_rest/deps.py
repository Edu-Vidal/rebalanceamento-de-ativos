import os
from collections.abc import Callable
from typing import Annotated
from uuid import UUID

from fastapi import Depends, HTTPException, Query, Security, status
from fastapi.security import HTTPAuthorizationCredentials
from fastapi.security.api_key import APIKeyHeader
from fastapi.security.http import HTTPBearer
from httpx import AsyncClient
from jose import ExpiredSignatureError, JWTError, jwt
from pydantic import BaseModel
from sqlmodel import SQLModel

from app.common.models.enum import RoleType, ServiceType

AUTH_API_URL = os.getenv("AUTH_API_URL", "http://localhost:8000")

oauth2_scheme = HTTPBearer(
    scheme_name="Bearer",
    description="Bearer token fornecido pelo serviço de autenticação",
)
api_key_header = APIKeyHeader(
    name="x-api-key",
    description="Chave de api para uso interno. Não utilizado por clientes.",
)
AUTH_API_KEY = os.getenv("AUTH_API_KEY", "")


class TokenClaims(SQLModel):
    sub: str
    account: str
    account_id: UUID
    user_id: UUID
    role: str
    services: list[str] = []
    acl: list[str] = []


async def decode_token(access_token: str) -> TokenClaims:
    keys = await _get_jwks()

    # Tenta decodificar o token com chaves públicas disponíveis
    claims = None
    for key in keys:
        try:
            claims_dict = jwt.decode(
                token=access_token, key=key, algorithms=[key["alg"]]
            )
            claims = TokenClaims(**claims_dict)
        except ExpiredSignatureError as err:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Assinatura expirou. Faça login novamente",
            ) from err
        except JWTError:
            # Se não conseguir decodificar com uma chave, tenta com a próxima
            continue
    if not claims:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="Token inválido"
        )

    return claims


def get_current_user(
    required_roles: list[RoleType] | None = None,
    required_permissions: list[str] | None = None,
) -> Callable[[str], TokenClaims]:
    async def current_user(
        access_token: Annotated[HTTPAuthorizationCredentials, Depends(oauth2_scheme)],
    ) -> TokenClaims:
        credentials = access_token.credentials
        claims = await decode_token(credentials)

        # Verifica se usuário tem permissão para acessar o serviço
        if ServiceType.BIOMETRIA.value not in claims.services:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Usuário não tem permissão para acessar esse serviço",
            )

        if required_roles:
            has_role = False
            if any(role == claims.role for role in required_roles):
                has_role = True

            if not has_role:
                raise HTTPException(
                    status_code=403,
                    detail=f"Cargo {required_roles} é necessário para essa requisição",
                )

        if required_permissions:
            has_permission = False
            if all(permission in claims.acl for permission in required_permissions):
                has_permission = True

            if not has_permission:
                raise HTTPException(
                    status_code=403,
                    detail=f"Permissão {required_permissions} é necessária para essa requisição",  # noqa
                )

        return claims

    return current_user  # type: ignore


async def _get_jwks():
    async with AsyncClient() as client:
        response = await client.get(
            f"{AUTH_API_URL}/v1/.well-known/jwks.json",
        )
        response.raise_for_status()
        jwks = response.json()

    return jwks["keys"]


async def api_key_auth(
    api_key: str = Security(api_key_header),
) -> None:
    if api_key != AUTH_API_KEY:
        raise HTTPException(
            status_code=status.HTTP_401_FORBIDDEN, detail="API Key inválida"
        )


def get_order_by(model: type[BaseModel]) -> Callable[[str], str]:
    def order_by(order_by: str = Query(None)) -> str:
        valid_fields = list(model.__fields__.keys())
        if order_by:
            if order_by not in valid_fields:
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid 'order_by' field. \
                        Valid options are: {valid_fields}",
                )

        return order_by

    return order_by
