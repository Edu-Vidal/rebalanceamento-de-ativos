# https://stackoverflow.com/questions/75252097/fastapi-testing-runtimeerror-task-attached-to-a-different-loop/75444607#75444607
import os
from collections.abc import AsyncGenerator

from fastapi_async_sqlalchemy import db
from sqlalchemy.engine import URL
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker

POOL_SIZE = 1

DATABASE_URL = URL.create(
    drivername="postgresql+asyncpg",
    username=os.getenv("POSTGRES_USER", "postgres"),
    password=os.getenv("POSTGRES_PASSWORD", "pass"),
    host=os.getenv("POSTGRES_HOST", "localhost"),
    port=int(os.getenv("POSTGRES_PORT", "5432")),
    database=os.getenv("POSTGRES_DB", "postgres"),
)

connect_args = {"check_same_thread": False}

engine = create_async_engine(
    DATABASE_URL,
    echo=False,
    echo_pool=False,
    future=True,
    pool_size=POOL_SIZE,
)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


async def get_local_session() -> AsyncGenerator[AsyncSession, None]:
    """
    Get a local session independent of fastapi_async_sqlalchemy's db.session.
    Which depends on fastapi's execution context.
    """
    async with SessionLocal() as session:
        yield session


def get_session() -> AsyncSession:
    return db.session
