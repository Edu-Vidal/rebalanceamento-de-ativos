from datetime import datetime
from typing import TypedDict
from uuid import UUID

from fastapi import HTTPException
from fastapi import status as status_code
from fastapi_pagination import Page, Params
from fastapi_pagination.ext.sqlalchemy import paginate
from sqlalchemy import and_, exc
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import asc, col, desc, func, select
from sqlmodel.sql.expression import Select, SelectOfScalar

from app.common.db.session import get_session
from app.common.models.check import (
    DocumentType,
    UnicoCheckCreate,
    UnicoCheckStatusType,
    UnicoCheckType,
    UnicoCheckUpdate,
)
from app.common.models.tables import Account, UnicoCheck

# https://github.com/tiangolo/sqlmodel/issues/189
SelectOfScalar.inherit_cache = True  # type: ignore
Select.inherit_cache = True  # type: ignore


async def create_unico_check(
    check_create: UnicoCheckCreate,
    db_session: AsyncSession | None = None,
) -> UnicoCheck:
    db_session = db_session or get_session()

    check = UnicoCheck.from_orm(check_create)
    try:
        db_session.add(check)
        await db_session.commit()
    except exc.IntegrityError as e:
        await db_session.rollback()
        raise HTTPException(
            status_code=status_code.HTTP_409_CONFLICT,
            detail="Análise já existe. Verifique os dados e tente novamente.",
        ) from e
    await db_session.refresh(check)

    return check


async def get_unico_check(
    check_id: UUID | str | None = None,
    unico_id: str | None = None,
    db_session: AsyncSession | None = None,
) -> UnicoCheck | None:
    db_session = db_session or get_session()

    if check_id:
        result = await db_session.execute(
            select(UnicoCheck).where(UnicoCheck.check_id == check_id)
        )
    elif unico_id:
        result = await db_session.execute(
            select(UnicoCheck).where(UnicoCheck.unico_id == unico_id)
        )
    else:
        return None

    return result.scalar_one_or_none()


async def get_unico_check_count(
    account_id: UUID | str | None = None,
    created_after: datetime | None = None,
    created_before: datetime | None = None,
    check_types: list[UnicoCheckType] | None = None,
    status: list[UnicoCheckStatusType] | None = None,
    db_session: AsyncSession | None = None,
) -> int:
    db_session = db_session or get_session()

    query = select(func.count()).select_from(UnicoCheck)

    if account_id:
        query = query.where(UnicoCheck.billed_account_id == account_id)
    if created_after:
        query = query.where(UnicoCheck.created_at >= created_after)
    if created_before:
        query = query.where(UnicoCheck.created_at <= created_before)
    if check_types:
        query = query.where(col(UnicoCheck.check_type).in_(check_types))
    if status:
        query = query.where(col(UnicoCheck.status).in_(status))

    result = await db_session.execute(query)

    return result.scalar_one()


class CheckCountByAccount(TypedDict):
    account: Account
    check_count: dict[UnicoCheckType, int]


async def get_unico_check_count_by_account(
    accounts: list[UUID | str] | None = None,
    created_after: datetime | None = None,
    created_before: datetime | None = None,
    check_types: list[UnicoCheckType] | None = None,
    status: list[UnicoCheckStatusType] | None = None,
    limit: int | None = None,
    descending: bool = True,
    db_session: AsyncSession | None = None,
) -> CheckCountByAccount:
    db_session = db_session or get_session()

    # Subquery para determinar o total de análises por conta
    subquery = select(
        UnicoCheck.billed_account_id, func.count(UnicoCheck.check_id).label("total")
    )

    if accounts:
        subquery = subquery.where(col(UnicoCheck.billed_account_id).in_(accounts))
    if created_after:
        subquery = subquery.where(UnicoCheck.created_at >= created_after)
    if created_before:
        subquery = subquery.where(UnicoCheck.created_at <= created_before)
    if check_types:
        subquery = subquery.where(col(UnicoCheck.check_type).in_(check_types))
    if status:
        subquery = subquery.where(col(UnicoCheck.status).in_(status))
    if limit:
        subquery = subquery.limit(limit)

    subquery = (
        subquery.group_by(UnicoCheck.billed_account_id)
        .order_by(desc("total") if descending else asc("total"))
        .cte("top_accounts")
    )

    query = (
        select(
            Account,
            UnicoCheck.check_type,
            func.count(UnicoCheck.check_id).label("type_total"),
        )
        .join(UnicoCheck, Account.account_id == UnicoCheck.billed_account_id)
        .join(subquery, subquery.c.billed_account_id == Account.account_id)
        .group_by(Account, UnicoCheck.check_type)
        .order_by(desc("type_total") if descending else asc("type_total"))
    )

    if created_after:
        query = query.where(UnicoCheck.created_at >= created_after)
    if created_before:
        query = query.where(UnicoCheck.created_at <= created_before)
    if check_types:
        query = query.where(col(UnicoCheck.check_type).in_(check_types))
    if status:
        query = query.where(col(UnicoCheck.status).in_(status))

    result = await db_session.execute(query)

    check_count_by_account = {}
    for row in result.fetchall():
        account: Account = row[0]
        check_type: UnicoCheckType = row[1]
        type_count: int = row[2]
        if account.account_id not in check_count_by_account:
            check_count_by_account[account.account_id] = {
                "account": account,
            }

        check_count_by_account[account.account_id][check_type] = type_count

    return check_count_by_account


async def get_unico_check_count_by_month(
    account_id: UUID | str | None = None,
    created_after: datetime | None = None,
    created_before: datetime | None = None,
    check_types: list[UnicoCheckType] | None = None,
    status: list[UnicoCheckStatusType] | None = None,
    db_session: AsyncSession | None = None,
) -> dict[int, dict[int, dict[UnicoCheckType, int]]]:
    db_session = db_session or get_session()

    query = select(
        func.date_trunc("year", UnicoCheck.created_at).label("year"),
        func.date_trunc("month", UnicoCheck.created_at).label("month"),
        UnicoCheck.check_type,
        func.count(UnicoCheck.check_id).label("type_total"),
    ).select_from(UnicoCheck)

    if account_id:
        query = query.where(UnicoCheck.billed_account_id == account_id)
    if created_after:
        query = query.where(UnicoCheck.created_at >= created_after)
    if created_before:
        query = query.where(UnicoCheck.created_at <= created_before)
    if check_types:
        query = query.where(col(UnicoCheck.check_type).in_(check_types))
    if status:
        query = query.where(col(UnicoCheck.status).in_(status))

    query = query.group_by("year", "month", "check_type")

    result = await db_session.execute(query)

    check_count_by_month = {}
    for dt_year, dt_month, check_type, count in result.all():
        year = dt_year.year
        month = dt_month.month
        if year not in check_count_by_month:
            check_count_by_month[year] = {}
        if month not in check_count_by_month[year]:
            check_count_by_month[year][month] = {}
        check_count_by_month[year][month][check_type] = count

    return check_count_by_month


async def get_unico_checks(
    account_id: UUID | str | None = None,
    name: str | None = None,
    order_by: str | None = None,
    descending: bool = True,
    document_type: DocumentType | None = None,
    document: str | None = None,
    score_min: int | None = None,
    score_max: int | None = None,
    created_after: datetime | None = None,
    created_before: datetime | None = None,
    check_types: list[UnicoCheckType] | None = None,
    status: list[UnicoCheckStatusType] | None = None,
    db_session: AsyncSession | None = None,
) -> list[UnicoCheck]:
    db_session = db_session or get_session()

    query = select(UnicoCheck)

    if account_id:
        query = query.where(UnicoCheck.billed_account_id == account_id)
    if name:
        query = query.where(col(UnicoCheck.name).ilike(f"%{name}%"))
    if document_type:
        query = query.where(UnicoCheck.document_type == document_type)
        if document:
            query = query.where(UnicoCheck.document == document)
    if score_min is not None:
        query = query.where(
            and_(col(UnicoCheck.score).is_not(None), col(UnicoCheck.score) >= score_min)
        )
    if score_max is not None:
        query = query.where(
            and_(col(UnicoCheck.score).is_not(None), col(UnicoCheck.score) <= score_max)
        )
    if created_after:
        query = query.where(UnicoCheck.created_at >= created_after)
    if created_before:
        query = query.where(UnicoCheck.created_at <= created_before)
    if check_types:
        query = query.where(col(UnicoCheck.check_type).in_(check_types))
    if status:
        query = query.where(col(UnicoCheck.status).in_(status))

    try:
        order_by_attribute = col(UnicoCheck.created_at)
        if order_by:
            order_by_attribute = getattr(UnicoCheck, order_by)
    except AttributeError as e:
        raise HTTPException(
            status_code=status_code.HTTP_400_BAD_REQUEST,
            detail=f"Invalid 'order_by' field. Valid options are: {list(UnicoCheck.__fields__.keys())}",
        ) from e

    query = query.order_by(
        order_by_attribute.desc() if descending else order_by_attribute
    )

    checks = await db_session.execute(query)

    return checks.scalars().all()


async def get_unico_checks_paginated(
    account_id: UUID | str | None = None,
    order_by: str | None = None,
    descending: bool = True,
    name: str | None = None,
    document_type: DocumentType | None = None,
    document: str | None = None,
    score_min: int | None = None,
    score_max: int | None = None,
    created_after: datetime | None = None,
    created_before: datetime | None = None,
    check_types: list[UnicoCheckType] | None = None,
    status: list[UnicoCheckStatusType] | None = None,
    params: Params | None = Params(),
    db_session: AsyncSession | None = None,
) -> Page[UnicoCheck]:
    db_session = db_session or get_session()

    query = select(UnicoCheck)

    if account_id:
        query = query.where(UnicoCheck.billed_account_id == account_id)
    if name:
        query = query.where(col(UnicoCheck.name).ilike(f"%{name}%"))
    if document_type:
        query = query.where(UnicoCheck.document_type == document_type)
        if document:
            query = query.where(UnicoCheck.document == document)
    if score_min is not None:
        query = query.where(
            and_(col(UnicoCheck.score).is_not(None), col(UnicoCheck.score) >= score_min)
        )
    if score_max is not None:
        query = query.where(
            and_(col(UnicoCheck.score).is_not(None), col(UnicoCheck.score) <= score_max)
        )
    if created_after:
        query = query.where(UnicoCheck.created_at >= created_after)
    if created_before:
        query = query.where(UnicoCheck.created_at <= created_before)
    if check_types:
        query = query.where(col(UnicoCheck.check_type).in_(check_types))
    if status:
        query = query.where(col(UnicoCheck.status).in_(status))

    try:
        order_by_attribute = col(UnicoCheck.created_at)
        if order_by:
            order_by_attribute = getattr(UnicoCheck, order_by)
    except AttributeError as e:
        raise HTTPException(
            status_code=status_code.HTTP_400_BAD_REQUEST,
            detail=f"Invalid 'order_by' field. Valid options are: {list(UnicoCheck.__fields__.keys())}",
        ) from e

    query = query.order_by(
        order_by_attribute.desc() if descending else order_by_attribute
    )

    return await paginate(db_session, query, params)


async def update_unico_check(
    check: UnicoCheck,
    check_update: UnicoCheckUpdate,
    db_session: AsyncSession | None = None,
) -> UnicoCheck | None:
    db_session = db_session or get_session()

    update_data = check_update.dict(exclude_none=True)

    for field in update_data:
        setattr(check, field, update_data[field])

    db_session.add(check)

    try:
        await db_session.commit()
    except exc.IntegrityError as e:
        await db_session.rollback()
        raise HTTPException(
            status_code=status_code.HTTP_409_CONFLICT,
            detail="Erro ao atualizar análise. Verifique os dados e tente novamente.",
        ) from e
    await db_session.refresh(check)

    return check


async def delete_unico_check(
    check: UnicoCheck, db_session: AsyncSession | None = None
) -> None:
    db_session = db_session or get_session()

    await db_session.delete(check)

    await db_session.commit()
