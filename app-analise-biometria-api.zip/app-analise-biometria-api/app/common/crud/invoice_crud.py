from uuid import UUID

from fastapi import HTTPException, status
from fastapi_pagination import Page, Params
from fastapi_pagination.ext.async_sqlalchemy import paginate
from sqlalchemy import exc
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import select
from sqlmodel.sql.expression import Select, SelectOfScalar

from app.common.db.session import get_session
from app.common.models.invoice import InvoiceCreate
from app.common.models.tables import Invoice

# https://github.com/tiangolo/sqlmodel/issues/189
SelectOfScalar.inherit_cache = True  # type: ignore
Select.inherit_cache = True  # type: ignore


async def create_invoice(
    invoice_create: InvoiceCreate, db_session: AsyncSession | None = None
) -> Invoice:
    db_session = db_session or get_session()

    invoice = Invoice.from_orm(invoice_create)
    try:
        db_session.add(invoice)
        await db_session.commit()
    except exc.IntegrityError as e:
        await db_session.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Fatura já existe. Verifique os dados e tente novamente.",
        ) from e

    await db_session.refresh(invoice)

    return invoice


async def get_invoice_by_id(
    invoice_id: UUID | str, db_session: AsyncSession | None = None
) -> Invoice | None:
    db_session = db_session or get_session()

    result = await db_session.execute(
        select(Invoice).where(Invoice.invoice_id == invoice_id)
    )

    return result.scalar_one_or_none()


async def get_invoice_by_account_id(
    account_id: UUID | str,
    year: int,
    month: int,
    db_session: AsyncSession | None = None,
) -> Invoice | None:
    db_session = db_session or get_session()

    result = await db_session.execute(
        select(Invoice)
        .where(Invoice.account_id == account_id)
        .where(Invoice.year_reference == year)
        .where(Invoice.month_reference == month)
    )

    return result.scalar_one_or_none()


async def delete_invoice(
    invoice: Invoice, db_session: AsyncSession | None = None
) -> None:
    db_session = db_session or get_session()

    await db_session.delete(invoice)

    await db_session.commit()


async def get_invoices(
    account_id: UUID | str | None = None,
    year: int | None = None,
    month: int | None = None,
    db_session: AsyncSession | None = None,
) -> list[Invoice]:
    db_session = db_session or get_session()

    query = select(Invoice)

    if account_id:
        query = query.where(Invoice.account_id == account_id)
    if year:
        query = query.where(Invoice.year_reference == year)
    if month:
        query = query.where(Invoice.month_reference == month)

    invoices = await db_session.execute(query)

    return invoices.scalars().all()


async def get_invoices_paginated(
    account_id: UUID | str | None = None,
    year: int | None = None,
    month: int | None = None,
    params: Params | None = Params(),
    db_session: AsyncSession | None = None,
) -> Page[Invoice]:
    db_session = db_session or get_session()

    query = select(Invoice)

    if account_id:
        query = query.where(Invoice.account_id == account_id)
    if year:
        query = query.where(Invoice.year_reference == year)
    if month:
        query = query.where(Invoice.month_reference == month)

    return await paginate(db_session, query, params)
