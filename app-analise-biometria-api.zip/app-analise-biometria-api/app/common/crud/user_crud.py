from uuid import UUID

from fastapi import HTTPException, status
from fastapi_pagination import Page, Params
from fastapi_pagination.ext.async_sqlalchemy import paginate
from sqlalchemy import exc
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import asc, desc, select
from sqlmodel.sql.expression import Select, SelectOfScalar

from app.common.db.session import get_session
from app.common.models.tables import User
from app.common.models.user import (
    UserCreate,
    UserUpdate,
)

# https://github.com/tiangolo/sqlmodel/issues/189
SelectOfScalar.inherit_cache = True  # type: ignore
Select.inherit_cache = True  # type: ignore


async def create_user(
    user_create: UserCreate, db_session: AsyncSession | None = None
) -> User:
    db_session = db_session or get_session()

    user = User.from_orm(user_create)
    try:
        db_session.add(user)
        await db_session.commit()
    except exc.IntegrityError as e:
        await db_session.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Usuário já existe. Verifique os dados e tente novamente.",
        ) from e
    await db_session.refresh(user)

    return user


async def get_user_by_id(
    user_id: UUID | str, db_session: AsyncSession | None = None
) -> User | None:
    db_session = db_session or get_session()
    result = await db_session.execute(select(User).where(User.user_id == user_id))

    return result.scalar_one_or_none()


async def get_user_by_name(
    user_name: str, db_session: AsyncSession | None = None
) -> User | None:
    db_session = db_session or get_session()
    result = await db_session.execute(select(User).where(User.user_name == user_name))

    return result.scalar_one_or_none()


async def update_user(
    current_user: User,
    new_user: UserUpdate,
    db_session: AsyncSession | None = None,
) -> User:
    db_session = db_session or get_session()

    update_data = new_user.dict(exclude_unset=True)

    for field in update_data:
        setattr(current_user, field, update_data[field])

    db_session.add(current_user)
    await db_session.commit()
    await db_session.refresh(current_user)

    return current_user


async def delete_user(user: User, db_session: AsyncSession | None = None) -> None:
    db_session = db_session or get_session()

    if user.unico_checks:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Usuário possui análises vínculadas e não pode ser excluído.",
        )

    await db_session.delete(user)


async def get_users(db_session: AsyncSession | None = None) -> list[User]:
    db_session = db_session or get_session()

    query = select(User)

    users = await db_session.execute(query)

    return users.scalars().all()


async def get_users_paginated(
    params: Params | None = Params(),
    order_by: str | None = None,
    descending: bool = True,
    account_id: UUID | None = None,
    account_name: str | None = None,
    user_name_contains: str | None = None,
    email_contains: str | None = None,
    db_session: AsyncSession | None = None,
) -> Page[User]:
    db_session = db_session or get_session()

    query = select(User)

    if account_id:
        query = query.where(User.account_id == account_id)
    if account_name:
        query = query.where(User.account.account_name.ilike(f"%{account_name}%"))
    if user_name_contains:
        query = query.where(User.user_name.ilike(f"%{user_name_contains}%"))
    if email_contains:
        query = query.where(User.email.ilike(f"%{email_contains}%"))

    try:
        order_by_attribute = User.user_name
        if order_by:
            order_by_attribute = getattr(User, order_by)
    except AttributeError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid 'order_by' field. Valid options are: {list(User.__fields__.keys())}",
        ) from e

    query = query.order_by(
        desc(order_by_attribute) if descending else asc(order_by_attribute)
    )

    return await paginate(db_session, query, params)
