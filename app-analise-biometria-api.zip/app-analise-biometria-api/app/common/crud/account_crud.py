from uuid import UUID

from fastapi import HTTPException, status
from fastapi_pagination import Page, Params
from fastapi_pagination.ext.sqlalchemy import paginate
from sqlalchemy import exc
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import col, func, select
from sqlmodel.sql.expression import Select, SelectOfScalar

from app.common.db.session import get_session
from app.common.models.account import AccountCreate, AccountUpdate
from app.common.models.tables import Account

# https://github.com/tiangolo/sqlmodel/issues/189
SelectOfScalar.inherit_cache = True  # type: ignore
Select.inherit_cache = True  # type: ignore


async def create_account(
    account_create: AccountCreate, db_session: AsyncSession | None = None
) -> Account:
    db_session = db_session or get_session()

    account = Account.from_orm(account_create)
    try:
        db_session.add(account)
        await db_session.commit()
    except exc.IntegrityError as e:
        await db_session.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Conta já existe. Verifique os dados e tente novamente.",
        ) from e
    await db_session.refresh(account)

    return account


async def get_account_by_id(
    account_id: UUID | str, db_session: AsyncSession | None = None
) -> Account | None:
    db_session = db_session or get_session()
    result = await db_session.execute(
        select(Account).where(Account.account_id == account_id)
    )

    return result.scalar_one_or_none()


async def get_account_by_name(
    account_name: str, db_session: AsyncSession | None = None
) -> Account | None:
    db_session = db_session or get_session()
    result = await db_session.execute(
        select(Account).where(Account.account_name == account_name)
    )

    return result.scalar_one_or_none()


async def get_account_by_cnpj(
    cnpj: str, db_session: AsyncSession | None = None
) -> Account | None:
    db_session = db_session or get_session()
    result = await db_session.execute(select(Account).where(Account.cnpj == cnpj))

    return result.scalar_one_or_none()


async def get_account_count(db_session: AsyncSession | None = None) -> int:
    db_session = db_session or get_session()
    subquery = select(Account)

    query = select([func.count()]).select_from(subquery)
    count = await db_session.execute(query)
    value = count.scalar_one()

    return value


async def update_account(
    current_account: Account,
    new_account: AccountUpdate,
    db_session: AsyncSession | None = None,
) -> Account:
    db_session = db_session or get_session()

    update_data = new_account.dict(exclude_unset=True)

    for field in update_data:
        setattr(current_account, field, update_data[field])

    db_session.add(current_account)
    await db_session.commit()
    await db_session.refresh(current_account)

    return current_account


async def delete_account(
    account: Account, db_session: AsyncSession | None = None
) -> None:
    db_session = db_session or get_session()

    if account.users or account.unico_checks:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Conta não pode ser excluída pois possui usuários ou análises vinculadas.",
        )

    await db_session.delete(account)


async def get_accounts(db_session: AsyncSession | None = None) -> list[Account]:
    db_session = db_session or get_session()

    query = select(Account)

    accounts = await db_session.execute(query)

    return accounts.scalars().all()


async def get_accounts_paginated(
    params: Params | None = Params(),
    order_by: str | None = None,
    descending: bool = True,
    account_name_contains: str | None = None,
    db_session: AsyncSession | None = None,
) -> Page[Account]:
    db_session = db_session or get_session()

    query = select(Account)

    if account_name_contains:
        query = query.where(
            col(Account.account_name).ilike(f"%{account_name_contains}%")
        )

    try:
        order_by_attribute = col(Account.account_name)
        if order_by:
            order_by_attribute = getattr(Account, order_by)
    except AttributeError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid 'order_by' field. Valid options are: \
                {list(Account.__fields__.keys())}",
        ) from e

    query = query.order_by(
        order_by_attribute.desc() if descending else order_by_attribute
    )

    return await paginate(db_session, query, params)
