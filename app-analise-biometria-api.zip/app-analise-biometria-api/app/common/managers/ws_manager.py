import json
import os
from enum import Enum
from uuid import UUID

import boto3
from mypy_boto3_lambda import LambdaClient
from sqlmodel import SQLModel

from app.common.models.check import UnicoCheckRead
from app.utils.json_encoder import BaseModelEncoder

FUNCTION_NAME = os.environ["WS_BROADCAST_FUNCTION_NAME"]

client: LambdaClient = boto3.client(
    "lambda",
    region_name=os.getenv("AWS_REGION", "sa-east-1"),
)


class WebsocketMessageActionType(str, Enum):
    BIOMETRIA_CHECK_CREATED = "biometria_check_created"
    BIOMETRIA_CHECK_UPDATED = "biometria_check_updated"
    BIOMETRIA_CHECK_CONCLUDED = "biometria_check_concluded"


class WebsocketMessage(SQLModel):
    action: WebsocketMessageActionType
    data: dict[str, UnicoCheckRead]

    def serialize(self, **update) -> str:
        message = self.dict()
        message.update(update)
        return json.dumps(message, cls=BaseModelEncoder)


def send_ws_message(
    message: WebsocketMessage,
    account_id: UUID,
    api_stage: str = os.getenv("STAGE", "dev"),
    client: LambdaClient = client,
) -> None:
    client.invoke(
        FunctionName=FUNCTION_NAME,
        InvocationType="Event",
        Payload=message.serialize(account_id=account_id, api_stage=api_stage),
    )
