import os
from io import BytesIO

import boto3
from botocore.config import Config
from botocore.exceptions import ClientError
from fastapi import HTTPException, status
from mypy_boto3_s3 import S3Client

from app.utils.utils import logger

s3_client: S3Client = boto3.client(
    "s3",
    region_name=os.getenv("AWS_REGION", "sa-east-1"),
    config=Config(
        signature_version="s3v4",
    ),
)
BUCKET_NAME = os.environ["BUCKET_NAME"]


def upload_file_to_s3(
    file_obj: BytesIO,
    object_name: str,
    content_type: str,
    should_expire: bool = True,
    bucket_name: str = BUCKET_NAME,
) -> str:
    """Realiza upload de arquivo para o S3

    Args:
        file_obj (BytesIO): Arquivo a ser enviado
        object_name (str): Nome do arquivo. Desnecessário considerar local no bucket
        content_type (str): Mime type do arquivo
        should_expire (bool, optional): Define se o arquivo deve expirar. Padrão é True.
        bucket_name (str, optional): Nome do Bucket. Padrão é BUCKET_NAME.

    Raises:
        ValueError: Caso o nome do arquivo seja vazio
        HTTPException: Caso ocorra algum erro ao realizar o upload

    Returns:
        str: Nome do arquivo no bucket
    """
    if not object_name:
        raise ValueError("Nome do arquivo não pode ser vazio")

    key = object_name
    if should_expire:
        # Somente objetos com prefixo download/ possuem ciclo de vida de 1 dia
        object_prefix = "download/"
        key = object_prefix + object_name

    try:
        s3_client.upload_fileobj(
            file_obj, bucket_name, key, ExtraArgs={"ContentType": content_type}
        )
    except ClientError as e:
        logger.error(e)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao preparar arquivo para download",
        ) from e

    return key


def create_presigned_url(
    object_name: str, bucket_name: str = BUCKET_NAME, expiration: int = 600
):
    # Generate a presigned URL for the S3 object
    try:
        response = s3_client.generate_presigned_url(
            "get_object",
            Params={
                "Bucket": bucket_name,
                "Key": object_name,
            },
            ExpiresIn=expiration,
        )
    except Exception as e:
        logger.error(e)
        return "Error"
    # The response contains the presigned URL
    return response
