import os
from datetime import datetime, timedelta
from typing import Any

import boto3
import jwt
import requests
from botocore.exceptions import ClientError
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from fastapi import HTTPException, status
from pydantic import BaseModel

from app.utils.utils import base_64_to_bytes, logger, tracer

UNICO_TOKEN_EMISSION_URL = os.environ["UNICO_TOKEN_EMISSION_URL"]
UNICO_API_URL = os.environ["UNICO_API_URL"]
UNICO_API_KEY = os.environ["UNICO_API_KEY"]
UNICO_JWT_ACCESS_TOKEN_EXPIRES = timedelta(minutes=60)
UNICO_JWT_ALGORITHM = "RS256"
UNICO_SERVICE_ACCOUNT = os.environ["UNICO_SERVICE_ACCOUNT"]
UNICO_PRIVATE_PEM_STRING = os.environ["UNICO_PRIVATE_KEY"]
UNICO_KEY_ID = os.environ["UNICO_KEY_ID"]
UNICO_TENANT_ID = os.environ["UNICO_TENANT_ID"]

client = boto3.client("s3")
resource = boto3.resource("s3")
BUCKET_NAME = os.environ["BUCKET_NAME"]
UNICO_TOKEN_STORAGE_FILE = "unico-access-token.txt"  # noqa S105


def _create_access_token(account: str = "") -> str:
    """Função para criar token de acesso à API da unico"""
    service_token = _create_service_account_token(account)
    access_token = _request_access_token(service_token)
    return access_token


def is_access_token_valid(token: str) -> bool:
    # Verifica se o token é válido
    public_key = _load_private_key(UNICO_PRIVATE_PEM_STRING).public_key()
    try:
        jwt.decode(
            token,
            public_key,
            audience=UNICO_TOKEN_EMISSION_URL,
            algorithms=[UNICO_JWT_ALGORITHM],
        )
        return True
    except jwt.ExpiredSignatureError:
        return False
    except jwt.InvalidTokenError:
        return False


def _refresh_access_token() -> str:
    access_token = _create_access_token()
    _upload_unico_access_token_to_storage(access_token)

    return access_token


def _load_private_key(private_pem) -> Any:
    try:
        return serialization.load_pem_private_key(
            base_64_to_bytes(private_pem),
            password=None,
            backend=default_backend(),
        )
    except Exception as err:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Erro ao carregar pem private key.",
        ) from err


def _create_service_account_token(account: str = "") -> str:
    """Cria token de serviço da UNICO.

    Args:
        account (Optional[str]): Conta cujo serviço realizará ações por.

    Returns:
        str: Token JWT assinado com chave privada
    """

    payload = {
        "iss": f"{UNICO_SERVICE_ACCOUNT}@{UNICO_TENANT_ID}.iam.acesso.io",
        "aud": UNICO_TOKEN_EMISSION_URL,
        "scope": "*",
        "exp": datetime.utcnow() + UNICO_JWT_ACCESS_TOKEN_EXPIRES,
        "iat": datetime.utcnow(),
    }

    if account:
        payload["sub"] = account

    private_key = _load_private_key(UNICO_PRIVATE_PEM_STRING)

    try:
        return jwt.encode(payload, private_key, algorithm=UNICO_JWT_ALGORITHM)
    except Exception as err:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao gerar token de acesso da UNICO",
        ) from err


def _request_access_token(service_token: str) -> str:
    """Função para requisitar token de acesso à API da unico

    Args:
        service_token (str): Token JWT assinado com chave privada

    Returns:
        str: Token JWT assinado pela unico
    """

    payload = {
        "grant_type": "urn:ietf:params:oauth:grant-type:jwt-bearer",
        "assertion": service_token,
    }

    response = requests.post(
        f"{UNICO_TOKEN_EMISSION_URL}/oauth2/token",
        headers={"content-type": "application/x-www-form-urlencoded"},
        data=payload,
        timeout=15,
    )

    if response.status_code != 200:
        response = response.json()
        raise HTTPException(
            status_code=response["status_code"],
            detail=f"Erro ao gerar token de acesso da UNICO\
            \n\tResposta: {response['error_description']}",
        )
    return response.json()["access_token"]


def _get_unico_access_token() -> str:
    """Busca token de acesso UNICO

    Returns:
        str: Token de acesso UNICO
    """
    access_token = _load_unico_access_token_from_storage()

    if not access_token or not is_access_token_valid(access_token):
        access_token = _refresh_access_token()

    return access_token


def _upload_unico_access_token_to_storage(token: str) -> None:
    """Atualiza token de acesso UNICO

    Args:
        token (str): Token de acesso UNICO
    """
    try:
        resource.Object(BUCKET_NAME, UNICO_TOKEN_STORAGE_FILE).put(Body=token)
    except ClientError as err:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao atualizar token de acesso da UNICO.",
        ) from err


def _load_unico_access_token_from_storage() -> str:
    try:
        response = client.get_object(Bucket=BUCKET_NAME, Key=UNICO_TOKEN_STORAGE_FILE)
        return response["Body"].read().decode("utf-8")
    except ClientError as err:
        if err.response.get("Error", {}).get("Code", "") == "NoSuchKey":
            return ""
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao buscar token de acesso da UNICO.",
        ) from err


class UnicoCheckCreateResponseBody(BaseModel):
    id: str

    class Config:
        extra = "allow"


@tracer.capture_method
def create_unico_check(
    payload: dict,
    api_key: str = UNICO_API_KEY,
    api_url: str = UNICO_API_URL,
) -> UnicoCheckCreateResponseBody:
    access_token = _get_unico_access_token()
    headers = {
        "Content-Type": "application/json",
        "Authorization": access_token,
        "APIKEY": api_key,
    }
    response = requests.post(
        url=api_url + "/processes",
        headers=headers,
        json=payload,
        timeout=15,
    )
    status_code = response.status_code
    response = response.json()

    if status_code == status.HTTP_400_BAD_REQUEST:
        logger.error(
            f"BIOMETRIA - Erro ao criar análise.\n\tResposta:{response}",
        )
        if response["Error"]["Code"] == 20900:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Foto inadequada para processamento. Leia as instruções e tente novamente.",  # noqa E501
            )
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=response["Error"]["Description"],
        )

    if status_code != 200:
        logger.error(
            f"BIOMETRIA - Erro ao criar análise. Resposta não processada corretamente.\
                \tResposta:{response}",
        )
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao criar análise. Acione a equipe de suporte.",
        )

    return UnicoCheckCreateResponseBody(**response, id=response["Id"])


@tracer.capture_method
def create_unico_sms_check(
    payload: dict,
    api_key: str = UNICO_API_KEY,
    api_url: str = UNICO_API_URL,
) -> UnicoCheckCreateResponseBody:
    access_token = _get_unico_access_token()
    headers = {
        "Content-Type": "application/json",
        "Authorization": access_token,
        "APIKEY": api_key,
    }
    response = requests.post(
        url=api_url + "/messages",
        headers=headers,
        json=payload,
        timeout=15,
    )
    status_code = response.status_code
    response = response.json()

    if status_code == status.HTTP_400_BAD_REQUEST:
        print(f"BIOMETRIA - Erro ao criar análise.\n\tResposta:{response}")
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=response["Error"]["Description"],
        )

    if status_code != 200:
        print(f"BIOMETRIA - Erro ao criar análise.\n\tResposta:{response}")
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao criar análise. Acione a equipe de suporte.",
        )

    return UnicoCheckCreateResponseBody(**response, id=response["Id"])


def check_if_encoded_image_is_valid(encoded_image: str) -> None:
    payload = jwt.decode(encoded_image, options={"verify_signature": False})

    if datetime.fromtimestamp(payload["exp"]) < datetime.now():
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Imagem expirou. Envie uma nova imagem.",
        )
