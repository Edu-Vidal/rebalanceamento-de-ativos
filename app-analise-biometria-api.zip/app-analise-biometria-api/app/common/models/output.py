from sqlmodel import SQLModel

from app.common.models.user import UserRead


class Message(SQLModel):
    detail: str = ""


class TokenOutput(Message):
    access_token: str | None = None
    refresh_token: str | None = None
    token_type: str | None = None
    login_token: str | None = None


class CreatedUserOutput(Message):
    user: UserRead
