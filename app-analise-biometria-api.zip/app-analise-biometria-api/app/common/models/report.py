from uuid import UUID

from pydantic import validator
from sqlmodel import Field, SQLModel

from app.common.models.account import AccountRead
from app.common.models.check import CheckProvider


class UnicoCheckCount(SQLModel):
    sms: int = Field(default=0, ge=0)
    standard: int = Field(default=0, ge=0)
    amount: int = Field(default=0, ge=0)

    @validator("amount", always=True)
    def check_process_sum(cls, v, values):  # noqa N805
        return values["sms"] + values["standard"]

    def __add__(self, other: "UnicoCheckCount"):
        return UnicoCheckCount(
            sms=self.sms + other.sms,
            standard=self.standard + other.standard,
        )


class SgrlocCheckCount(SQLModel):
    banned: int = Field(default=0, ge=0)

    def __add__(self, other: "SgrlocCheckCount"):
        return SgrlocCheckCount(
            banned=self.banned + other.banned,
        )


class UnicoHistory(SQLModel):
    history: dict[int, dict[int, UnicoCheckCount]]

    class Config:
        schema_extra = {
            "example": {
                "history": {
                    2023: {
                        1: UnicoCheckCount(sms=1, standard=2),
                        2: UnicoCheckCount(sms=3, standard=4),
                    }
                }
            }
        }


class SgrlocHistory(SQLModel):
    history: dict[int, dict[int, SgrlocCheckCount]]

    class Config:
        schema_extra = {
            "example": {
                "history": {
                    2023: {
                        1: SgrlocCheckCount(banned=5),
                        2: SgrlocCheckCount(banned=10),
                    }
                }
            }
        }


class History(SQLModel):
    history: dict[
        int, dict[int, dict[CheckProvider, UnicoCheckCount | SgrlocCheckCount]]
    ]

    class Config:
        schema_extra = {
            "example": {
                "history": {
                    2023: {
                        1: {
                            CheckProvider.UNICO: UnicoCheckCount(sms=1, standard=2),
                        },
                        2: {
                            CheckProvider.UNICO: UnicoCheckCount(sms=3, standard=4),
                        },
                    }
                }
            }
        }


class UnicoRanking(SQLModel):
    ranking: dict[int, dict[str, AccountRead | UnicoCheckCount]]

    class Config:
        schema_extra = {
            "example": {
                "ranking": {
                    1: {
                        "account": AccountRead(
                            account_name="Locadora de Veículos Y",
                            cnpj="91.124.191/0001-59",
                            account_id=UUID("d1b0d0c0-0b0b-4b0b-8b0b-0b0b0b0b0b0b"),
                        ),
                        "check_count": UnicoCheckCount(sms=1, standard=2),
                    },
                    2: {
                        "account": AccountRead(
                            account_name="Locadora de Veículos X",
                            cnpj="69.337.804/0001-87",
                            account_id=UUID("d1b0d0c0-0b0b-4b0b-8b0b-0b0b0b0b0b0b"),
                        ),
                        "check_count": UnicoCheckCount(sms=3, standard=4),
                    },
                }
            }
        }
