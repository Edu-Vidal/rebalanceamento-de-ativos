from datetime import datetime
from uuid import UUID

from pydantic import EmailStr
from sqlmodel import Field, SQLModel

from app.common.models.account import AccountRead
from app.utils.partial import optional


class UserBase(SQLModel):
    user_id: UUID = Field(primary_key=True, nullable=False)
    user_name: str = Field(index=True, nullable=False)
    email: EmailStr = Field(index=True, nullable=False)
    account_id: UUID | None = Field(
        default=None, foreign_key="Account.account_id", nullable=False
    )

    class Config:
        extra = "ignore"
        validate_assignment = True
        orm_mode = True
        json_encoders = {
            datetime: lambda x: x.isoformat(),
        }


class UserCreate(UserBase):
    pass


@optional
class UserUpdate(UserBase):
    pass


class UserRead(UserBase):
    account: AccountRead
