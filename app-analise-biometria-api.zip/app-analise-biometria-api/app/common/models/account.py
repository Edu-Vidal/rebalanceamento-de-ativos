from datetime import datetime
from uuid import UUID

from pydantic import Extra, validator
from sqlmodel import Field, SQLModel

from app.utils.partial import optional
from app.utils.validators import is_cnpj_valid


class AccountBase(SQLModel):
    account_id: UUID = Field(primary_key=True, nullable=False)
    account_name: str = Field(index=True, nullable=False, description="Nome fantasia")
    cnpj: str = Field(index=True)

    @validator("cnpj")
    def format_cnpj(cls, v: str):  # noqa N805
        if not v:
            return v
        if not is_cnpj_valid(v):
            raise ValueError("Invalid CNPJ")

        # Remove caracteres não numéricos
        v = "".join(filter(str.isdigit, v))
        # Formata CNPJ
        v = f"{v[:2]}.{v[2:5]}.{v[5:8]}/{v[8:12]}-{v[12:]}"

        return v

    class Config:
        extra = Extra.ignore
        validate_assignment = True
        orm_mode = True
        json_encoders = {
            datetime: lambda x: x.isoformat(),
        }


class AccountCreate(AccountBase):
    pass


@optional
class AccountUpdate(AccountBase):
    pass


class AccountRead(AccountBase):
    pass
