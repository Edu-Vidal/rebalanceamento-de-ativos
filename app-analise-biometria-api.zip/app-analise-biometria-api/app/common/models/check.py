import os
from datetime import datetime
from enum import Enum, IntEnum
from uuid import UUID

from pydantic import Extra, validator
from sqlmodel import Field, SQLModel

from app.utils.partial import optional
from app.utils.validators import is_cpf_valid


class CheckProvider(str, Enum):
    UNICO = "UNICO"


class UnicoCheckType(str, Enum):
    BIOMETRIA = "BIOMETRIA"
    BIOMETRIA_SMS = "BIOMETRIA_SMS"


class UnicoCheckSMSTemplateType(str, Enum):
    COMPLETE = os.environ["UNICO_SMS_TEMPLATE"]
    SIMPLE = os.environ["UNICO_SIMPLE_SMS_TEMPLATE"]


class UnicoCheckStatusType(IntEnum):
    PENDING = 1
    DIVERGENCE = 2
    CONCLUDED = 3
    CANCELED = 4
    ERROR = 5
    SENDING = 6
    AWAITING_CAPTURE = 7
    RESENDING = 8


class UnicoCheckScoreIntervalType(str, Enum):
    NEGATIVE_40_TO_NEGATIVE_100 = "NEGATIVE_40_TO_NEGATIVE_100"
    NEGATIVE_11_TO_NEGATIVE_39 = "NEGATIVE_11_TO_NEGATIVE_100"
    NEGATIVE_10_TO_NEGATIVE_1 = "NEGATIVE_10_TO_NEGATIVE_1"
    ZERO = "ZERO"
    POSITIVE_1_TO_10 = "POSITIVE_1_TO_10"
    POSITIVE_11_TO_100 = "POSITIVE_11_TO_49"


class UnicoCheckSuspiciousPersonEventType(IntEnum):
    LIST_REMOVED = 0
    LIST_ADDED = 1
    DB_REMOVED = 2


class DocumentType(str, Enum):
    CPF = "CPF"


def get_status_description(status: UnicoCheckStatusType) -> str:
    """Retorna a descrição do status da análise.
    Para código não identificado retorna 5 -> Erro
    """
    status_description = {
        1: "Aguardando interação ou em processamento",
        2: "Em divergência",
        3: "Concluído",
        4: "Cancelado",
        5: "Erro",
        6: "Enviando mensagem",
        7: "Aguardando captura da mensagem",
        8: "Reenviando mensagem",
    }
    return status_description.get(status.value, "Erro")


def get_interval_from_interval_type(
    interval_type: UnicoCheckScoreIntervalType,
) -> tuple[int, int]:
    """Retorna o intervalo de score a partir do tipo de intervalo."""
    interval = {
        UnicoCheckScoreIntervalType.NEGATIVE_40_TO_NEGATIVE_100: (-100, -40),
        UnicoCheckScoreIntervalType.NEGATIVE_11_TO_NEGATIVE_39: (-39, -11),
        UnicoCheckScoreIntervalType.NEGATIVE_10_TO_NEGATIVE_1: (-10, -1),
        UnicoCheckScoreIntervalType.ZERO: (0, 0),
        UnicoCheckScoreIntervalType.POSITIVE_1_TO_10: (1, 10),
        UnicoCheckScoreIntervalType.POSITIVE_11_TO_100: (11, 100),
    }
    return interval[interval_type]


def get_score_description(score: int) -> str:
    if score < -40:
        return "Grande probabilidade da pessoa física não ser dona do CPF aprensentado."
    if score < -10:
        return "Evidências indicam que a foto analisada está vinculada a outros CPFs."
    if score == -10:
        return "Foto cadastrada na Base de Dados para o CPF informado é diferente \
            da fornecida para análise. Poucas evidências foram encontradas."
    if score == 10:
        return "Foto analisada está consistente com o CPF informado. \
            Poucas evidências encontradas."
    if score > 10:
        return "Foto analisada está consistente com o CPF informado."
    return "Inconclusivo. Base de Dados sem evidências para o CPF informado"


def get_score_interval(score: int) -> UnicoCheckScoreIntervalType:
    # Retorna o intervalo de score
    if score < -40:
        return UnicoCheckScoreIntervalType.NEGATIVE_40_TO_NEGATIVE_100
    if score < -10:
        return UnicoCheckScoreIntervalType.NEGATIVE_11_TO_NEGATIVE_39
    if score == -10:
        return UnicoCheckScoreIntervalType.NEGATIVE_10_TO_NEGATIVE_1
    if score == 10:
        return UnicoCheckScoreIntervalType.POSITIVE_1_TO_10
    if score > 10:
        return UnicoCheckScoreIntervalType.POSITIVE_11_TO_100
    return UnicoCheckScoreIntervalType.ZERO


def get_change_description(change_type: int):
    change_description = {
        0: "Removido da lista de score suspeito",
        1: "Adicionado na lista de score suspeito",
        2: "Pessoa removida da base de dados",
    }
    return change_description[change_type]


class CheckBase(SQLModel):
    check_provider: CheckProvider = Field(index=True, nullable=False)
    name: str
    document_type: DocumentType
    document: str

    billed_account_id: UUID | None = Field(
        default=None, foreign_key="Account.account_id"
    )
    created_by_id: UUID | None = Field(default=None, foreign_key="User.user_id")

    @validator("document")
    def verify_document(cls, v: str, values: dict):  # noqa N805
        if values["document_type"] != DocumentType.CPF:
            return v

        if not is_cpf_valid(v):
            raise ValueError("Invalid CPF")

        # Remove caracteres não numéricos
        v = "".join(filter(str.isdigit, v))
        # Formata CPF
        v = f"{v[:3]}.{v[3:6]}.{v[6:9]}-{v[9:]}"

        return v

    class Config:
        extra = Extra.allow
        validate_assignment = True
        orm_mode = True
        json_encoders = {
            datetime: lambda x: x.isoformat(),
        }


class UnicoCheckBase(CheckBase):
    unico_id: str = Field(index=True)
    check_provider: CheckProvider = Field(
        default=CheckProvider.UNICO, index=True, nullable=False
    )
    check_type: UnicoCheckType = Field(index=True, nullable=False)

    score: int | None = Field(default=None, index=True)
    status: UnicoCheckStatusType = Field(index=True)
    score_description: str = Field(default="")
    status_description: str = Field(default="")

    @validator("status")
    def verify_status(cls, v: UnicoCheckStatusType, values):  # noqa N805
        # Se status for concluído, score deve ser diferente de None
        if values["score"] is None and v == UnicoCheckStatusType.CONCLUDED:
            return UnicoCheckStatusType.ERROR
        return v

    @validator("score_description", always=True)
    def set_score_description(cls, _v, values):  # noqa N805
        if "score" not in values or not values["score"]:
            return ""
        return get_score_description(values["score"])

    @validator("status_description", always=True)
    def set_status_description(cls, _v, values):  # noqa N805
        if "status" not in values:
            return ""
        return get_status_description(values["status"])


class UnicoCheckCreate(UnicoCheckBase):
    pass


class UnicoCheckMigrate(UnicoCheckCreate):
    created_at: datetime
    updated_at: datetime


@optional
class UnicoCheckUpdate(UnicoCheckBase):
    pass


class UnicoCheckRead(UnicoCheckBase):
    check_id: UUID

    updated_at: datetime
    created_at: datetime


class UnicoRate(SQLModel):
    sms: int = 380
    standard: int = 380
