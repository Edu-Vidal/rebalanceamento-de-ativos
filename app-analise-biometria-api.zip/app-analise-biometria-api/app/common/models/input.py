from uuid import UUID

from pydantic import validator
from sqlmodel import Field, SQLModel

from app.common.managers.unico import check_if_encoded_image_is_valid
from app.common.models.check import UnicoCheckSMSTemplateType
from app.utils.validators import is_cpf_valid


class BiometriaCheckInput(SQLModel):
    # Modelo de dados para criar análise
    # Normaliza criação de payload para UNICO

    cpf: str
    name: str = Field(..., min_length=3, max_length=100)
    only_selfie: bool
    imagebase64: str
    with_mask: bool
    birth_date: str = Field(default="", regex=r"^\d{1,2}/\d{1,2}/\d{4}$")

    @validator("cpf")
    def validate_cpf(cls, v: str):  # noqa N805
        v = "".join(filter(str.isdigit, v))

        if not is_cpf_valid(v):
            raise ValueError("CPF inválido")

        return v

    @validator("imagebase64")
    def validate_encoded_image(cls, v: str):  # noqa N805
        # Raises HTTPException if image is invalid
        check_if_encoded_image_is_valid(v)
        return v

    @property
    def payload(self):
        if self.birth_date:
            return {
                "subject": {
                    "Code": self.cpf,
                    "Name": self.name,
                    "BirthDate": self.birth_date,
                },
                "onlySelfie": self.only_selfie,
                "withMask": self.with_mask,
                "imagebase64": self.imagebase64,
            }
        return {
            "subject": {"Code": self.cpf, "Name": self.name},
            "onlySelfie": self.only_selfie,
            "withMask": self.with_mask,
            "imagebase64": self.imagebase64,
        }

    class Config:
        arbitrary_types_allowed = True
        extra = "ignore"

        schema_extra = {
            "example": {
                "cpf": "34006202466",
                "name": "Isabelly Larissa Martins",
                "only_selfie": True,
                "imagebase64": "iVBORw0KGgoAAAANSUhEUgAAABAAAAAQCAYAAAAf8/9hAAAAAXNSR0I\
                    Ars4c6QAAAARnQU1BAACxjwv8YQUAAAAJcEhZcwAADsQAAA7EAZUrDhsAAAAgSURBVD\
                        hPY/wPBAwUACYoTTYYNWDUABAYNWDgDWBgAABrygQclUTopgAAAABJRU5ErkJgg\
                            g==",
                "with_mask": False,
                "birth_date": "9/1/2000",
            }
        }


class BiometriaSMSCheckInput(SQLModel):
    # Modelo de dados para criar análise via SMS
    # Normaliza criação de payload para UNICO

    cpf: str
    phone: str = Field(..., regex=r"^\d{13}$")
    name: str = Field(..., min_length=3, max_length=100)
    template: UnicoCheckSMSTemplateType = UnicoCheckSMSTemplateType.COMPLETE

    @validator("cpf")
    def validate_cpf(cls, v: str):  # noqa N805
        v = "".join(filter(str.isdigit, v))

        if not is_cpf_valid(v):
            raise ValueError("CPF inválido")

        return v

    @property
    def payload(self):
        return {
            "subject": {
                "Code": self.cpf,
                "Name": self.name,
                "Phone": self.phone,
            },
            "indexes": [{"key": "1", "value": "0", "page": "SMS"}],
            "template": self.template,
            "send": True,
            "enableQRCode": True,
        }

    class Config:
        arbitrary_types_allowed = True
        extra = "ignore"
        schema_extra = {
            "example": {
                "cpf": "34006202466",
                "name": "Isabelly Larissa Martins",
                "phone": "5531992507449",
                "template": "analise_biometrica_simples",
            }
        }


class AccountCreateInput(SQLModel):
    account_id: UUID
    account_name: str
    cnpj: str


class AccountUpdateInput(SQLModel):
    account_name: str | None = None
    cnpj: str | None = None


class UserCreateInput(SQLModel):
    account_id: UUID
    user_id: UUID
    user_name: str
    email: str


class UserUpdateInput(SQLModel):
    user_name: str | None = None
    email: str | None = None


class TokenInput(SQLModel):
    token: str
