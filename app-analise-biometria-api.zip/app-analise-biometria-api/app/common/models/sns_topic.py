from enum import Enum

from sqlmodel import SQLModel

from app.common.models.check import UnicoCheckStatusType


class TopicMessageType(str, Enum):
    UPDATE_UNICO_CHECK = "update_unico_check"
    SUSPICIOUS_PERSON = "suspicious_person"


class CheckUpdatePayload(SQLModel):
    unico_id: str
    score: int
    status: UnicoCheckStatusType


class TopicMessage(SQLModel):
    message_type: TopicMessageType
    check_update_payload: CheckUpdatePayload
    suspicious_person_payload: str | None = (
        None  # TODO: create a model for this payload
    )
