from uuid import UUID

from sqlmodel import Field, SQLModel

from app.utils.partial import optional


class InvoiceBase(SQLModel):
    year_reference: int  # Ano relativo à fatura
    month_reference: int  # Mês relativo à fatura
    url: str  # Caminho para pdf de fatura

    account_id: UUID = Field(foreign_key="Account.account_id")


class InvoiceCreate(InvoiceBase):
    pass


@optional
class InvoiceUpdate(InvoiceBase):
    pass


class InvoiceRead(InvoiceBase):
    invoice_id: UUID
