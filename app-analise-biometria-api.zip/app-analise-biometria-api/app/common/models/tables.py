from datetime import datetime

from sqlalchemy.orm import declared_attr
from sqlmodel import Field, Relationship

from app.common.models.account import AccountBase
from app.common.models.check import UnicoCheckBase
from app.common.models.invoice import InvoiceBase
from app.common.models.user import UserBase
from app.utils.uuid6 import UUID, uuid7


class Account(AccountBase, table=True):
    users: list["User"] = Relationship(
        back_populates="account", sa_relationship_kwargs={"lazy": "selectin"}
    )
    unico_checks: list["UnicoCheck"] = Relationship(
        back_populates="billed_account", sa_relationship_kwargs={"lazy": "selectin"}
    )
    invoices: list["Invoice"] = Relationship(
        back_populates="account", sa_relationship_kwargs={"lazy": "selectin"}
    )

    updated_at: datetime = Field(
        default_factory=datetime.utcnow, sa_column_kwargs={"onupdate": datetime.utcnow}
    )
    created_at: datetime = Field(default_factory=datetime.utcnow)

    @declared_attr
    def __tablename__(cls) -> str:  # noqa: N805
        return cls.__name__


class User(UserBase, table=True):
    account: Account = Relationship(
        back_populates="users", sa_relationship_kwargs={"lazy": "joined"}
    )
    unico_checks: list["UnicoCheck"] = Relationship(
        back_populates="created_by", sa_relationship_kwargs={"lazy": "selectin"}
    )

    updated_at: datetime = Field(
        default_factory=datetime.utcnow, sa_column_kwargs={"onupdate": datetime.utcnow}
    )
    created_at: datetime = Field(default_factory=datetime.utcnow)

    @declared_attr
    def __tablename__(cls) -> str:  # noqa: N805
        return cls.__name__


class UnicoCheck(UnicoCheckBase, table=True):
    check_id: UUID = Field(default_factory=uuid7, primary_key=True, nullable=False)

    billed_account: Account = Relationship(
        back_populates="unico_checks", sa_relationship_kwargs={"lazy": "joined"}
    )
    created_by: User = Relationship(
        sa_relationship_kwargs={
            "lazy": "joined",
            "primaryjoin": "UnicoCheck.created_by_id==User.user_id",
        }
    )

    updated_at: datetime = Field(
        default_factory=datetime.utcnow, sa_column_kwargs={"onupdate": datetime.utcnow}
    )
    created_at: datetime = Field(default_factory=datetime.utcnow)

    @declared_attr
    def __tablename__(cls) -> str:  # noqa: N805
        return cls.__name__


class Invoice(InvoiceBase, table=True):
    invoice_id: UUID = Field(default_factory=uuid7, primary_key=True, nullable=False)

    account: Account = Relationship(
        back_populates="invoices", sa_relationship_kwargs={"lazy": "joined"}
    )

    updated_at: datetime = Field(
        default_factory=datetime.utcnow, sa_column_kwargs={"onupdate": datetime.utcnow}
    )
    created_at: datetime = Field(default_factory=datetime.utcnow)

    @declared_attr
    def __tablename__(cls) -> str:  # noqa: N805
        return cls.__name__
