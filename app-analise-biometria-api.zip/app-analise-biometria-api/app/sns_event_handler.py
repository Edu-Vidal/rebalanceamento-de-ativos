import asyncio

from aws_lambda_powertools.utilities.data_classes import SNSEvent, event_source
from aws_lambda_powertools.utilities.typing import LambdaContext
from pydantic import ValidationError

from app.common.crud import unico_check_crud as db
from app.common.db.session import SessionLocal
from app.common.managers.ws_manager import (
    WebsocketMessage,
    WebsocketMessageActionType,
    send_ws_message,
)
from app.common.models.check import (
    UnicoCheckRead,
    UnicoCheckStatusType,
    UnicoCheckUpdate,
)
from app.common.models.sns_topic import TopicMessage
from app.utils.utils import logger, tracer

message_type_ref = {
    UnicoCheckStatusType.PENDING: WebsocketMessageActionType.BIOMETRIA_CHECK_CREATED,
    UnicoCheckStatusType.CONCLUDED: WebsocketMessageActionType.BIOMETRIA_CHECK_CONCLUDED,
    UnicoCheckStatusType.DIVERGENCE: WebsocketMessageActionType.BIOMETRIA_CHECK_CONCLUDED,
    UnicoCheckStatusType.CANCELED: WebsocketMessageActionType.BIOMETRIA_CHECK_CONCLUDED,
    UnicoCheckStatusType.ERROR: WebsocketMessageActionType.BIOMETRIA_CHECK_CONCLUDED,
    UnicoCheckStatusType.SENDING: WebsocketMessageActionType.BIOMETRIA_CHECK_UPDATED,
    UnicoCheckStatusType.AWAITING_CAPTURE: WebsocketMessageActionType.BIOMETRIA_CHECK_UPDATED,
    UnicoCheckStatusType.RESENDING: WebsocketMessageActionType.BIOMETRIA_CHECK_UPDATED,
}

session = SessionLocal()


@event_source(data_class=SNSEvent)
@tracer.capture_method
@logger.inject_lambda_context(
    log_event=True,
    clear_state=True,
)
def lambda_handler(event: SNSEvent, context: LambdaContext):
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main(event, context))


async def main(event: SNSEvent, context: LambdaContext):
    for record in event.records:
        message = record.sns.message
        try:
            topic_message = TopicMessage.parse_raw(message)
        except ValidationError as e:
            logger.exception(f"Erro ao fazer parse da mensagem do tópico: {e.json()}")
            raise e

        # TODO: implementar para SUSPICIOUS_PERSON
        unico_id = topic_message.check_update_payload.unico_id

        check = await db.get_unico_check(unico_id=unico_id, db_session=session)
        if not check:
            raise ValueError(
                f"Erro ao atualizar análise de unico_id: {unico_id}. \
                    Análise não encontrada"
            )

        check_update = UnicoCheckUpdate(
            **topic_message.check_update_payload.dict(exclude_unset=True),
        )

        await db.update_unico_check(check, check_update, db_session=session)

        logger.info(f"Análise de unico_id: {unico_id} atualizada com sucesso")

        ws_message = WebsocketMessage(
            action=message_type_ref[check_update.status],
            data={"check": UnicoCheckRead.from_orm(check)},
        )
        if not check.billed_account_id:
            logger.info(f"Análise de unico_id: {unico_id} não possui conta faturada")
            return
        send_ws_message(ws_message, check.billed_account_id)
