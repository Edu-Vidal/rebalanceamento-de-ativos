from app.common.models.check import UnicoCheckStatusType


def get_status_description(status: UnicoCheckStatusType) -> str:
    """Retorna a descrição do status da análise.
    Para código não identificado retorna 5 -> Erro
    """
    status_description = {
        1: "Aguardando interação ou em processamento",
        2: "Em divergência",
        3: "Concluído",
        4: "Cancelado",
        5: "Erro",
        6: "Enviando mensagem",
        7: "Aguardando captura da mensagem",
        8: "Reenviando mensagem",
    }
    return status_description.get(status.value, "Erro")


def get_score_description(score: int) -> str:
    if score < -40:
        return "Grande probabilidade da pessoa física não ser dona do CPF aprensentado."
    if score < -10:
        return "Evidências indicam que a foto analisada está vinculada a outros CPFs."
    if score == -10:
        return "Foto cadastrada na Base de Dados para o CPF informado é diferente \
            da fornecida para análise. Poucas evidências foram encontradas."
    if score == 10:
        return "Foto analisada está consistente com o CPF informado. \
            Poucas evidências encontradas."
    if score > 10:
        return "Foto analisada está consistente com o CPF informado."
    return "Inconclusivo. Base de Dados sem evidências para o CPF informado"


def get_change_description(change_type: int):
    change_description = {
        0: "Removido da lista de score suspeito",
        1: "Adicionado na lista de score suspeito",
        2: "Pessoa removida da base de dados",
    }
    return change_description[change_type]
