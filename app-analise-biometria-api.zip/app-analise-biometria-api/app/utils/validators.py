from itertools import cycle
from uuid import UUID


def is_cnpj_valid(cnpj: str) -> bool:
    # Remove caracteres não numéricos
    cnpj = "".join(c for c in cnpj if c.isdigit())

    if len(cnpj) != 14:
        return False

    if cnpj in (c * 14 for c in "1234567890"):
        return False

    cnpj_r = cnpj[::-1]
    for i in range(2, 0, -1):
        cnpj_enum = zip(cycle(range(2, 10)), cnpj_r[i:])
        dv = sum(int(x[1]) * x[0] for x in cnpj_enum) * 10 % 11
        if cnpj_r[i - 1 : i] != str(dv % 10):
            return False

    return True


def is_cpf_valid(cpf: str) -> bool:
    # Remove caracteres não numéricos
    cpf = "".join(c for c in cpf if c.isdigit())

    if len(cpf) != 11:
        return False

    if cpf in (c * 11 for c in "1234567890"):
        return False

    cpf_reverso = cpf[::-1]
    for i in range(2, 0, -1):
        cpf_enumerado = enumerate(cpf_reverso[i:], start=2)
        dv_calculado = sum(int(x[1]) * x[0] for x in cpf_enumerado) * 10 % 11
        if cpf_reverso[i - 1 : i] != str(dv_calculado % 10):
            return False

    return True


def is_valid_uuid(uuid_to_test, version=4) -> bool:
    try:
        uuid_obj = UUID(uuid_to_test, version=version)
    except ValueError:
        return False

    return str(uuid_obj) == uuid_to_test
