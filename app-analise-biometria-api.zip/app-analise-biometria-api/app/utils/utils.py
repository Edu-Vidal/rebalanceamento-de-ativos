import base64
import os
from collections.abc import Sequence
from datetime import date, datetime, timedelta

import pandas as pd
from aws_lambda_powertools import Logger, Metrics, Tracer
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from sqlmodel import SQLModel

logger: Logger = Logger()
metrics: Metrics = Metrics()
metrics.set_default_dimensions(environment=os.getenv("STAGE", "dev"))
tracer = Tracer()


def bytes_to_base_64(bytes: bytes) -> str:
    # Responsável por converter bytes para base64
    return base64.b64encode(bytes).decode("utf-8")


def base_64_to_bytes(b64: str) -> bytes:
    # Responsável por converter base64 para bytes
    return base64.b64decode(b64)


def create_public_pem_key(private_key: str) -> str:
    # Responsável por criar chave pública a partir da chave privada
    public_pem_bytes = (
        serialization.load_pem_private_key(
            base_64_to_bytes(private_key), password=None, backend=default_backend()
        )
        .public_key()
        .public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
    )

    return bytes_to_base_64(public_pem_bytes)


def get_week_start() -> datetime:
    # Retorna último domingo
    return datetime.now() - timedelta(days=(date.today().isoweekday() % 7))


def sqlmodel_to_df(objects: Sequence[SQLModel], set_index: bool = True) -> pd.DataFrame:
    """Converts SQLModel objects into a Pandas DataFrame.
    Usage
    ----------
    df = sqlmodel_to_df(list_of_sqlmodels)
    Parameters
    ----------
    :param objects: List[SQLModel]: List of SQLModel objects to be converted.
    :param set_index: bool: Sets the first column, usually the primary key, \
        to dataframe index.
    """
    if len(objects) == 0:
        return pd.DataFrame()

    records = [obj.dict() for obj in objects]
    columns = list(objects[0].schema()["properties"].keys())
    df = pd.DataFrame.from_records(records, columns=columns)
    return df.set_index(columns[0]) if set_index else df
