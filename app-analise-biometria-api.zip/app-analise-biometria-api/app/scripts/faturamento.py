import math
from datetime import datetime
from typing import Optional

from dateutil.relativedelta import relativedelta

from common.managers.db_conn import DynamoDatabase
from common.models.enum import CheckType, UnicoCheckStatusType
from common.models.report import CheckCount

db_conn = DynamoDatabase()


async def generate_invoice_for_account(month: int, year: int, account_id: str):
    account = db_conn.get_account(account_id=account_id)

    created_after = datetime(year, month, 1)
    created_before = created_after + relativedelta(months=1)

    with open(
        f"Faturamento_Mensal_{account.account_name}-{year}_{month}.csv", "w"
    ) as f:
        f.write(
            "Locadora,Quantidade UNICO,Quantidade SGRLOC,\
                Valor UNICO,Valor SGRLOC,Total\n"
        )
        checks = db_conn.get_checks_async(
            account_id=account.account_id,
            created_after=created_after,
            created_before=created_before,
        )

        checks_by_type = {}
        async for check in checks:
            if (
                check.check_type == CheckType.BIOMETRIA
                or check.check_type == CheckType.BIOMETRIA_SMS
            ):
                if check.status != UnicoCheckStatusType.CONCLUDED:
                    continue
            checks_by_type.setdefault(check.check_type, []).append(check)

        check_count = CheckCount(
            sms=len(checks_by_type.get(CheckType.BIOMETRIA_SMS, [])),
            standard=len(checks_by_type.get(CheckType.BIOMETRIA, [])),
            banned=len(checks_by_type.get(CheckType.SGRLOC, [])),
        )

        unico_quantity = check_count.standard + check_count.sms
        unico_cost = unico_quantity * 3.80
        sgrloc_cost = check_count.banned * 2.80
        total_cost = unico_cost + sgrloc_cost

        # Formata valores para duas casas decimais
        unico_cost = math.ceil(unico_cost * 100) / 100
        sgrloc_cost = math.ceil(sgrloc_cost * 100) / 100
        total_cost = math.ceil(total_cost * 100) / 100

        f.write(
            f"{account.account_name},{unico_quantity},{check_count.banned},\
                {unico_cost:.2f},{sgrloc_cost:.2f},{total_cost:.2f}\n"
        )


async def main(month: int, year: int, account_id: Optional[str] = None):
    # Busca locadoras cadastradas no banco de dados
    accounts = db_conn.get_accounts()

    created_after = datetime(year, month, 1)
    created_before = created_after + relativedelta(months=1)

    total_checks_cost = {"sms": 0, "standard": 0, "banned": 0}

    with open(f"Faturamento_Mensal_Geral_{month}_{year}.csv", "w") as f:
        f.write(
            "Locadora,Quantidade UNICO,Quantidade SGRLOC,\
                Valor UNICO,Valor SGRLOC,Total\n"
        )
        for account in accounts:
            # Busca análises da locadora
            checks = db_conn.get_checks_async(
                account_id=account.account_id,
                created_after=created_after,
                created_before=created_before,
            )

            checks_by_type = {}
            async for check in checks:
                if (
                    check.check_type == CheckType.BIOMETRIA
                    or check.check_type == CheckType.BIOMETRIA_SMS
                ):
                    if check.status != UnicoCheckStatusType.CONCLUDED:
                        continue
                checks_by_type.setdefault(check.check_type, []).append(check)

            check_count = CheckCount(
                sms=len(checks_by_type.get(CheckType.BIOMETRIA_SMS, [])),
                standard=len(checks_by_type.get(CheckType.BIOMETRIA, [])),
                banned=len(checks_by_type.get(CheckType.SGRLOC, [])),
            )

            total_checks_cost["sms"] += check_count.sms
            total_checks_cost["standard"] += check_count.standard
            total_checks_cost["banned"] += check_count.banned

            unico_quantity = check_count.standard + check_count.sms
            unico_cost = unico_quantity * 3.80
            sgrloc_cost = check_count.banned * 2.80
            total_cost = unico_cost + sgrloc_cost

            # Formata valores para duas casas decimais
            unico_cost = math.ceil(unico_cost * 100) / 100
            sgrloc_cost = math.ceil(sgrloc_cost * 100) / 100
            total_cost = math.ceil(total_cost * 100) / 100

            f.write(
                f"{account.account_name},{unico_quantity},{check_count.banned},\
                    {unico_cost:.2f},{sgrloc_cost:.2f},{total_cost:.2f}\n"
            )


if __name__ == "__main__":
    import asyncio

    asyncio.set_event_loop_policy(asyncio.WindowsSelectorEventLoopPolicy())
    asyncio.run(
        generate_invoice_for_account(
            month=5, year=2023, account_id="b722ecec-56f4-4e4f-90bf-aa809bb09e45"
        )
    )
