<div align="center">
    <img src="https://abla-assets.s3.sa-east-1.amazonaws.com/logo-abla.png"/>
</div>

<h1 align="center"> API - Biometria Facial</h1>

<div align="center">
    <a href="https://app.circleci.com/pipelines/github/snlv-com-br/app-analise-biometria-api?filter=all">
        <img src="https://circleci.com/gh/snlv-com-br/app-analise-biometria-api/tree/main.svg?style=shield&circle-token=372b6a553a397b66e66e38723d10ce7c8175697f"/>
    </a>
    <a href="https://github.com/psf/black">
        <img src="https://img.shields.io/badge/code%20style-black-000000.svg"/>
    </a>
<a href="https://github.com/astral-sh/ruff"><img src="https://img.shields.io/endpoint?url=https://raw.githubusercontent.com/charliermarsh/ruff/main/assets/badge/v2.json" alt="Ruff" style="max-width:100%;"></a>

</div>
</br>

Interface integrada com UNICO e SGRLOC para realização de análise de biométrica facial e verificação de CPF.

---

## Documentação da API - OpenAPI | Swagger

Endpoints estão definidos com [OpenAPI](https://7w2pgpr8ac.execute-api.sa-east-1.amazonaws.com/dev/docs) e são atualizados em conjunto com a aplicação.

## Executando localmente

Clone o projeto

```bash
git clone https://github.com/snlv-com-br/app-analise-biometria-api
```

Entre no diretório do projeto

```bash
cd app-analise-biometria-api
```

Configure variáveis de ambiente, acordo com a seção [Variáveis de Ambiente](#variáveis-de-ambiente), e com o docker em execução a orquestração de conteineres pode ser criada com:

```bash
docker-compose up
```

Configure as variáveis de ambiente. Gere uma cópia das variáveis de exemplo e substitua os valores de acordo:

```bash
cp .env.example .env
```

Execute o módulo main.py.

```bash
poetry run python -m app.main
```

Toda a infraestrutura é gerida pela Terraform e está localizada no diretório **infra**.
A api foi configurada para execução em ambiente serverless, utilizando AWS Lambda e API Gateway, onde são mantidos dois ambientes, um para produção e outro para desenvolvimento.

O projeto possui linter e formatter configurados, além de regras para criação de commits e branches.

Veja `CONTRIBUTING.md` para saber como começar.

## Deploy

Infraestrutura está definida, em sua totalidade, utilizando o terraform e todos os recursos são geridos com o seu intermédio.

Deploy do código é feito através do [CircleCI](https://github.com/snlv-com-br/app-analise-biometria-api/blob/main/.circleci/config.yml).

## Variáveis de Ambiente

Variáveis são definidas em [projeto configurado no CircleCI](https://app.circleci.com/pipelines/github/snlv-com-br/app-analise-biometria-api?filter=all).

Para executar o projeto, substitua os campos de variáveis de ambiente no arquivo **.env.example** e renomeie para **.env**.

## Usado por

Essa API é consumida por outros aplicativos

- [Portal de Análise Biométrica](https://github.com/snlv-com-br/app-analise-biometria)

## Contribuindo

Veja `CONTRIBUTING.md` para saber como começar.
