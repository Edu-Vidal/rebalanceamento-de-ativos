# Bem vindo ao guia de contribuição

Faz bem ao dedicar um tempo para aderir aos padrões do projeto!

Nesse guia irei informar como configurar o seu repositório local para dar continuidade ao desenvolvimento.

# Configurando o ambiente de desenvolvimento

## Passo 1: Instalar pré-requisitos

Antes de configurar o projeto, certifique-se de ter os seguintes pré-requisitos instalados:

- [Git](https://git-scm.com/downloads): Sistema de controle de versão usado no projeto

- [Python](https://www.python.org/downloads/): Linguagem de programação usada no projeto (de preferência Python 3.8.10)

- [pyenv](https://github.com/pyenv/pyenv): Ferramenta de gerenciamento de versões do Python (recomendado)

- [Poetry](https://python-poetry.org/docs/#installation): Ferramenta de gerenciamento de dependências e empacotamento para Python

- [Make](https://www.gnu.org/software/make/): Ferramenta de automação de compilação (Como instalar no windows: [Make for Windows](https://www.technewstoday.com/install-and-use-make-in-windows/))

## Passo 2: Clonar o repositório

Clone o repositório do projeto para o seu computador local usando o seguinte comando:

```bash
git clone https://github.com/snlv-com-br/app-analise-biometria-api
cd app-analise-biometria-api
```

## Passo 3: Instalar e configurar o pyenv (opcional)

Se você deseja gerenciar várias versões do Python em sua máquina, recomendamos usar o pyenv. Siga as instruções de instalação no repositório oficial do pyenv.

Após instalar o pyenv, instale a versão desejada do Python (neste caso, 3.8.\*):

```bash
pyenv install 3.8.x
```

\*Substitua "x" pela versão mais recente do Python 3.8 disponível.

Defina a versão do Python para ser usada no diretório do projeto:

```bash
pyenv local 3.8.x
```

## Passo 4: Instalar dependências e configurar o ambiente

Usando o Makefile fornecido no projeto, instale as dependências e configure o ambiente executando o seguinte comando:

```bash
make setup
```

Isso criará um ambiente virtual com o Poetry, instalará as dependências necessárias e configurará o pre-commit.

## Passo 5: Verificar a configuração

Após concluir a configuração, você pode verificar se o ambiente de desenvolvimento está funcionando corretamente executando os testes:

```bash
make test
```

Se os testes forem executados com sucesso (ou se você receber uma mensagem informando que nenhum teste foi encontrado), seu ambiente de desenvolvimento estará pronto para uso.

Agora você pode começar a contribuir para o projeto, seguindo as diretrizes de contribuição descritas no arquivo CONTRIBUTING.md.

### Linter

O projeto utiliza o [flake8](https://flake8.pycqa.org/en/latest/) para unificar as boas práticas e evitar erros o código, suas configurações estão em `setup.cfg`.

#### Pre-commit Hook

Para se certificar que código enviado ao repositório está livre de erros utiliza-se o evento `pre-commit` do git para configurar o script responsável por executar o linter.

Para isso faz-se o uso do framework [pre-commit](https://pre-commit.com/).

Estabeleça a pasta `.githooks` como padrão executar os Git Hooks

```
git config core.hooksPath .githooks
```

Após cada commit as alterações serão avaliadas, caso os arquivos possuam erros um aviso será retornado, impedindo o commit.

### Formatter

Para unificar estilização do código utiliza-se o [Black](https://black.readthedocs.io/en/stable/). É recomendado integrar o formatter ao editor de sua escolha. Para o VSCode, use como referência o seguinte [post](https://dev.to/adamlombard/how-to-use-the-black-python-code-formatter-in-vscode-3lo0).

### Commits

Para todos os commits, exceto merges, utiliza-se o seguinte formato:

[gitmoji](https://gitmoji.dev/) <span style="color: green">Mensagem</span> (#Issue_Id)

Por exemplo:

- `✨ adiciona endpoint para reset de senha (#3)`

- `⬆️ atualiza versão de serverless` -> Caso não haja issue vinculada

É recomendado a extensão `gitmoji` do VSCode, para acesso fácil à referência dos emojis.

#### Commit-msg Hook

Para se certificar de que os commits estão corretos o evento commit-msg executa um script responsável pela validação.

Para isso certifique-se que a pasta `.githooks` consta como padrão para executar os Git Hooks

```
git config core.hooksPath .githooks
```

## Realizando alterações

Está ansioso para começar a implementar novas features, mas não deixe de manter a organização! Siga as diretrizes a seguir pra manter unicidade no repositório.

1. Crie uma Issue com a proposta e explicação das alterações.

2. Vincule uma branch à issue

   - Certifique-se que o nome da branch possui referência à issue

   - Por exemplo, para a issue `#10`, cujo responsável é o [Eduardo Vidal](https://github.com/Edu-Vidal) -> <span style="color: purple">Edu/10</span>

3. Após alterações feitas e enviadas ao github, faça um Pull Request para integrar ao projeto.
