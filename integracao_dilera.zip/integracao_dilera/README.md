# Configurando projeto:

1. Instale dependencias:

```
    make install
```

2. Configure variáveis de ambiente substituindo os campos em .env.example:

```
    cp .env.example .env
```

3. Inicie banco de dados:

```
    docker-compose up db
```

4. Execute migrações:

```
    poetry run alembic upgrade head
```

5. Inicie aplicação:

```
    API Rest:
    poetry run python -m app.main
    OU
    docker-compose up api

    Poller:
    poetry run python -m app.result_poll
```

# Infraestrutura

Infraestrutura criada é definida em sua plenitude utilizando o terraform. Api está divida em estágios, dev e prod, e cada estágio possui seu próprio conjunto de recursos. Ambos estágios estão subordinados a uma implementação do API Gateway, localizada em /infra. Todo deploy, independente do estágio, deve ser precedido por um deploy do API Gateway.

# CI|CD

CI está configurado utilizando o Azure Devops. Configuração pode ser visualizada no arquivo azure-pipelines.yml. O gatilho para deploy é a crição de releases ou tags.

A configuração do deploy, CD, para executar o terraform e aplicar as mudanças na infraestrutura está presente exclusivamente no portal da Azure Devops.
