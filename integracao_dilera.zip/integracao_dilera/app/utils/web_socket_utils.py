import os

import boto3
from fastapi import HTTPException

websocket_api_name = os.environ["WEBSOCKET_API_NAME"]
region = os.environ["REGION"]


def get_websocket_api_url(api_stage: str = "prod") -> str:
    api_gateway_v2 = boto3.client("apigatewayv2", region_name=region)

    for api in api_gateway_v2.get_apis()["Items"]:
        if api["Name"] == websocket_api_name:
            api_id = api["ApiId"]
            return f"https://{api_id}.execute-api.{region}.amazonaws.com/{api_stage}"

    raise HTTPException(
        status_code=404,
        detail="Websocket API not found",
    )
