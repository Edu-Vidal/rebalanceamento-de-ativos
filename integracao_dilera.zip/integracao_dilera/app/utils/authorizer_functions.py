def generate_policy(principal_id, effect, resource) -> dict:
    auth_response = {}
    auth_response["principal_id"] = principal_id
    if effect and resource:
        auth_response["policyDocument"] = {
            "Version": "2012-10-17",
            "Statement": [
                {
                    "Action": "execute-api:Invoke",
                    "Effect": effect,
                    "Resource": resource,
                }
            ],
        }

    return auth_response


def generate_allow(principal_id, resource) -> dict:
    return generate_policy(principal_id, "Allow", resource)


def generate_deny(principal_id, resource, **kwargs) -> dict:
    return generate_policy(principal_id, "Deny", resource, **kwargs)
