import inspect
from collections.abc import Callable
from typing import TypeVar, get_type_hints

from pydantic import BaseModel, Field

T = TypeVar("T", bound=BaseModel)


def optional(*fields: str | type[BaseModel]) -> Callable[[type[T]], type[T]]:
    """
    A decorator that makes specified fields optional in a Pydantic model.
    Can be used either with specific field names or applied directly to a model class.

    Args:
        *fields: Either field names as strings or a Pydantic model class

    Returns:
        A decorator function that modifies the model fields to be optional

    Usage:
        @optional('field1', 'field2')
        class MyModel(BaseModel):
            field1: str
            field2: int
            field3: str

        # Or

        @optional
        class MyModel(BaseModel):
            field1: str
            field2: int
    """

    def dec(_cls: type[T]) -> type[T]:
        # Get the model's fields through type hints
        hints = get_type_hints(_cls)

        # Determine which fields to make optional
        field_names = fields if fields and isinstance(fields[0], str) else hints.keys()

        # Create new annotations with optional types
        new_annotations = {}
        for field_name, field_type in hints.items():
            if field_name in field_names:
                # Make the field optional by using Field with default=None
                setattr(_cls, field_name, Field(default=None))
                # Update annotation to make it Optional
                new_annotations[field_name] = field_type | None
            else:
                new_annotations[field_name] = field_type

        # Update the model's annotations
        _cls.__annotations__ = new_annotations

        return _cls

    # Handle case where decorator is used without arguments
    if fields and inspect.isclass(fields[0]) and issubclass(fields[0], BaseModel):
        cls = fields[0]
        fields = ()  # Make all fields optional
        return dec(cls)

    return dec
