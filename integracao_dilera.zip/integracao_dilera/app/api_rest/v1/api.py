from fastapi import APIRouter

from .endpoints import order

router = APIRouter()
router.include_router(order.router, prefix="/order", tags=["Order"])
# router.include_router(produto.router, prefix="/product", tags=["Product"])
