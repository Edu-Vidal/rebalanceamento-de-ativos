from fastapi import APIRouter, Depends, HTTPException, status

from app.api_rest import deps
from app.common.crm_sheets import get_sale_info
from app.common.jotform import JotformClient
from app.common.models.order import OrderCreate, OrderRead, StatusPedido

router = APIRouter()


@router.post("/")
async def create_order(
    order_create_input: OrderCreate,
    user_email: str = Depends(deps.get_user),
) -> OrderRead:
    """
    Rota para criar uma nova ordem de compra.
    """
    if (
        user_email.strip().lower() != order_create_input.email.strip().lower()
    ) and user_email.strip().lower() != "oi@gubo.com":
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Usuário {user_email} não autorizado.",
        )
    client = JotformClient()
    response = client.submit_purchase(order_create_input.to_jotform())

    submission_id = response["content"]["submissionID"]

    response = client.get_submission(submission_id)

    sale_id = response["content"]["answers"]["58"]["answer"]

    # order = get_sale_info(sale_id)

    # if not order:
    #     raise HTTPException(
    #         status_code=status.HTTP_404_NOT_FOUND,
    #         detail="Ordem de compra não encontrada.",
    #     )

    # return order

    return OrderRead(
        **order_create_input.model_dump(),
        id=sale_id,
        status=StatusPedido.PROCESSANDO_PEDIDO,
    )


# @router.get("/")
# async def get_orders(
#     user_id: str = Depends(deps.get_user),
#     skip: int = Query(0, ge=0),
#     limit: int = Query(10, le=100),
# ) -> list[OrderRead]:
#     """
#     Rota para listar produtos.
#     """
#     raise HTTPException(status_code=status.HTTP_501_NOT_IMPLEMENTED)


@router.get("/{order_id}")
async def get_order_by_id(
    order_id: int,
    user_email: str = Depends(deps.get_user),
) -> OrderRead:
    """
    Rota para buscar uma ordem de compra por ID.
    """
    order = get_sale_info(order_id)

    if not order:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND,
            detail="Ordem de compra não encontrada.",
        )

    if user_email.strip().lower() != order.email.strip().lower():
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN,
            detail=f"Usuário {user_email} não autorizado.",
        )

    return order
