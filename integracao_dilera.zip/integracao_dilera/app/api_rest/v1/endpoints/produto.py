from fastapi import APIRouter, Depends, HTTPException, status

from app.api_rest import deps
from app.common.models.product import ProductCreate, ProductRead, ProductUpdate

# from app.common.crm_sheets

router = APIRouter()


@router.post("/")
async def create_products(
    product_create_input: list[ProductCreate],
    user_id: str = Depends(deps.get_user),
) -> list[ProductRead]:
    """
    Rota para criar novos produtos.
    """
    raise HTTPException(status_code=status.HTTP_501_NOT_IMPLEMENTED)


# @router.get("/")
# async def get_products(
#     user_id: str = Depends(deps.get_user),
#     skip: int = Query(0, ge=0),
#     limit: int = Query(10, le=100),
# ) -> list[ProductRead]:
#     """
#     Rota para listar produtos.
#     """
#     raise HTTPException(status_code=status.HTTP_501_NOT_IMPLEMENTED)


@router.get("/{product_id}")
async def get_product_by_id(
    product_id: str,
    user_id: str = Depends(deps.get_user),
) -> ProductRead:
    """
    Rota para buscar um produto por ID.
    """
    raise HTTPException(status_code=status.HTTP_501_NOT_IMPLEMENTED)


@router.patch("/{product_id}")
async def update_product(
    product_id: str,
    product_update_input: ProductUpdate,
    user_id: str = Depends(deps.get_user),
) -> ProductRead:
    """
    Rota para atualizar um produto.
    """
    raise HTTPException(status_code=status.HTTP_501_NOT_IMPLEMENTED)
