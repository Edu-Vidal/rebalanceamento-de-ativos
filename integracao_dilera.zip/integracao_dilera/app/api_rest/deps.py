from fastapi import HTTPException, Security, status
from fastapi.security import APIKeyHeader

api_key_header = APIKeyHeader(name="X-API-Key")


def get_user(api_key_header: str = Security(api_key_header)):
    # if check_api_key(api_key_header):
    #     return get_user_from_api_key(api_key_header)
    if api_key_header:
        return "oi@gubo.com"
    raise HTTPException(
        status_code=status.HTTP_401_UNAUTHORIZED, detail="API Key inválida ou ausente."
    )

    # def get_order_by(model: type[BaseModel]) -> Callable[[str], str]:
    #     def order_by(order_by: str = Query(None)) -> str:
    #         valid_fields = list(model.__fields__.keys())
    #         if order_by:
    #             if order_by not in valid_fields:
    #                 raise HTTPException(
    #                     status_code=400,
    #                     detail=f"Invalid 'order_by' field. Valid options are: {valid_fields}",
    #                 )

    #         return order_by

    # return order_by
