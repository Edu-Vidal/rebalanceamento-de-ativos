import json
import os
from enum import Enum
from typing import Any

import requests
from pydantic import BaseModel, Field

from app.common.models.enum import UF, Cor, Tamanho

try:
    from dotenv import load_dotenv

    load_dotenv()
except ModuleNotFoundError:
    pass

JOTFORM_API_KEY = os.environ["JOTFORM_API_KEY"]
JOTFORM_COMPRA_FORM_ID = os.environ["JOTFORM_COMPRA_FORM_ID"]


# Enums
class PersonType(str, Enum):
    PF = "Pessoa física (PF)"
    PJ = "Pessoa jurídica (PJ)"


class BillingType(str, Enum):
    MANUAL = "Preencher manualmente (recomendado para dropshipping)"
    SAME = "Usar os mesmos dados do destinatário"


class PaymentMethod(str, Enum):
    PIX = "PIX"
    CREDIT_CARD = "Cartão de Crédito"


# Compra
class ProductItem(BaseModel):
    id: int = Field(
        ...,
        serialization_alias="ID Gubo do Produto (consulte em seu painel de controle)",
    )
    color: Cor = Field(..., serialization_alias="Cor")
    size: Tamanho = Field(..., serialization_alias="Tamanho")
    quantity: int = Field(..., serialization_alias="Quantidade")
    sale_price: str | None = Field(
        default=None, serialization_alias="Seu preço de venda unitário (opcional)"
    )


class ShippingAddress(BaseModel):
    zipcode: str = Field(..., serialization_alias="89")
    street: str = Field(..., serialization_alias="90")
    number: int = Field(..., serialization_alias="103")
    complement: str | None = Field(default=None, serialization_alias="27")
    neighborhood: str = Field(..., serialization_alias="91")
    city: str = Field(..., serialization_alias="99")
    state: UF = Field(..., serialization_alias="94")


class Recipient(BaseModel):
    person_type: PersonType = Field(..., serialization_alias="37")
    document: str = Field(..., serialization_alias="39")
    name: str = Field(..., serialization_alias="41")
    email: str = Field(..., serialization_alias="43")
    phone: str = Field(..., serialization_alias="44")


class BillingAddress(BaseModel):
    zipcode: str = Field(..., serialization_alias="144")
    street: str = Field(..., serialization_alias="145")
    number: int = Field(..., serialization_alias="146")
    complement: str | None = Field(default=None, serialization_alias="148")
    neighborhood: str = Field(..., serialization_alias="149")
    city: str = Field(..., serialization_alias="150")
    state: str = Field(..., serialization_alias="151")


class BillingPerson(BaseModel):
    person_type: PersonType = Field(..., serialization_alias="152")
    document: str = Field(..., serialization_alias="153")
    name: str = Field(..., serialization_alias="154")
    email: str = Field(..., serialization_alias="155")
    phone: str = Field(..., serialization_alias="156")
    registration: str = Field(..., serialization_alias="113")


class BillingInfo(BaseModel):
    billing_type: BillingType = Field(..., serialization_alias="110")
    address: BillingAddress
    person: BillingPerson


class PurchaseSubmission(BaseModel):
    email: str = Field(..., serialization_alias="7")
    products: list[ProductItem] = Field(..., serialization_alias="6")
    shipping_address: ShippingAddress
    recipient: Recipient
    billing: BillingInfo
    payment_method: PaymentMethod = Field(..., serialization_alias="10")
    discount_coupon: str | None = Field(default=None, serialization_alias="75")
    internal_id: str | None = Field(default=None, serialization_alias="135")


class JotformClient:
    def __init__(
        self,
        api_key: str = JOTFORM_API_KEY,
        purchase_form_id: str = JOTFORM_COMPRA_FORM_ID,
    ):
        self.api_key = api_key
        self.purchase_form_id = purchase_form_id
        self.base_url = "https://api.jotform.com"

    @staticmethod
    def _build_submission_data(purchase: PurchaseSubmission) -> dict:
        """Converts the purchase data into JotForm's expected submission format"""
        submission = {}

        # Email
        submission["submission[7]"] = purchase.email

        # Products - Convert to JSON string as expected by JotForm
        products_data = []
        for product in purchase.products:
            product_dict = product.model_dump(by_alias=True)
            products_data.append(product_dict)
        submission["submission[6]"] = json.dumps(products_data)

        # Shipping Address
        address = purchase.shipping_address.model_dump(by_alias=True)
        for field, value in address.items():
            if value is not None:
                submission[f"submission[{field}]"] = value

        # Recipient
        recipient = purchase.recipient.model_dump(by_alias=True)
        for field, value in recipient.items():
            if value is not None:
                submission[f"submission[{field}]"] = value

        # Billing Information
        submission["submission[110]"] = purchase.billing.billing_type

        billing_address = purchase.billing.address.model_dump(by_alias=True)
        for field, value in billing_address.items():
            if value is not None:
                submission[f"submission[{field}]"] = value

        billing_person = purchase.billing.person.model_dump(by_alias=True)
        for field, value in billing_person.items():
            if value is not None:
                submission[f"submission[{field}]"] = value

        # Payment and Additional Info
        submission["submission[10]"] = purchase.payment_method
        if purchase.discount_coupon:
            submission["submission[75]"] = purchase.discount_coupon
        if purchase.internal_id:
            submission["submission[135]"] = purchase.internal_id

        # Envia CPF/CNPJ no 112?
        submission["submission[112]"] = purchase.recipient.document

        return submission

    def submit_purchase(self, purchase: PurchaseSubmission) -> Any:
        """Submit purchase to JotForm"""
        url = f"{self.base_url}/form/{self.purchase_form_id}/submissions"
        headers = {
            "APIKEY": self.api_key,
        }

        data = self._build_submission_data(purchase)

        response = requests.post(url, headers=headers, data=data)
        response.raise_for_status()
        return response.json()

    def get_submission(self, submission_id: str) -> Any:
        """Get a submission by ID"""
        url = f"{self.base_url}/submission/{submission_id}"
        headers = {
            "APIKEY": self.api_key,
        }

        response = requests.get(url, headers=headers)
        response.raise_for_status()
        return response.json()
