import json
import os
from urllib.parse import quote

import requests
from google.oauth2 import service_account
from googleapiclient.discovery import build

from app.common.models.enum import UF, Cor, PessoaTipo, StatusPedido, Tamanho
from app.common.models.order import (
    Destinatario,
    Emitente,
    Endereco,
    OrderRead,
    ProdutoItem,
)
from app.utils.utils import logger

try:
    from dotenv import load_dotenv

    load_dotenv()
except ModuleNotFoundError:
    pass

google_credentials = {
    "type": "service_account",
    "project_id": "xenon-lyceum-438710-s2",
    "private_key_id": "bc33b35f2f98676a7f114814cbd04f72430b510c",
    "private_key": "-----BEGIN PRIVATE KEY-----\nMIIEvgIBADANBgkqhkiG9w0BAQEFAASCBKgwggSkAgEAAoIBAQDGASADbjyNnF72\nB2juSo26nfq3qHHvqok0JAHxAY7lYOuW/vZFsGc5uWzcIrmu3wbMuVGz+BQgKTNE\nSUdB8hcAQ17WJgYt3h4OXK6ORkG9YlTHZUO1AwQq4CCRH4Ar5TcmN44VLKVJzh/s\nfzF/o9dPF1xQr2vTQM4pABrHjmi9hJR67S0kF51d7wzYN7xkJqEjzFZORWE4DLnE\nmXkfCaPunz0Rrxodfpaj5LiT0GYzKInnsFGtEdmSc3ZmTmVYySbKDpk/Disu0ayr\nOCWjfYvuVNqoVr+4BFb5sqo2EEU56i1X/zz8K/OHv2HAnp6M+uDaH2oFjhviNBhk\nP3Z46HhzAgMBAAECggEAVWgR03j+xIRxD4VltPdSh+7xwLt3Hc487VEkxzyJUxaJ\nuDFUr/2loOgC9TdDSZMo3zCGde7pW2/6DZfgFSlj03i71PpEyw8WftJqdrMGUzax\nY+qhmFfrOcVANujUA9sUfTcUYbzGtP2kloHMq4ZT7mkgqCrqgw5efp/tbStXsXrW\nmMzexmN2w6aQGlHaNEUOxH9mY3xqGjcWfHQGjiA9kXAwMhMv4O2GHyMRZMvet38f\n00EdHew98V8rgdXDNTz64YPNyugV5sZ0fTyEzpiXA5uePu73KI6kAZYcEekpBJeA\nL/CuAro9oVEVKuSRVOuwqGHjHw9EMoyfXTWa9zyL4QKBgQDrP0icmOCEgXj6Yj8K\n95BHX2aFaDdkEkT6Dte1ESYKnBHkSlFvb1al1uN+9INko/7J41NFOlsn4t6zat0x\nnvFSVmJbQpUW7SeXmgTZcd3SHpGjBMRiCjK9E7y71fR3rNrjlYkPub4fErnXHHCH\nS42rZPMLHw7CITmEjjCvitQL4QKBgQDXeMRHMmDI/G9fde5dTT331uXL8i/csbUk\nNpnsfz68pfue5anyKt4HjXYmzPH9DPBi53iGlz4L6PDd8SElf7qa5FB9AnlDEXzY\nWEkXLctOkYT1Y6Jk7Zj6VEeu1ESeeb45pkV9+gKjwNrUOej7exqqw6AMNds54Nk7\n6IXxkAhu0wKBgQDePDKEfYfcpdN79kRIQAd05ZMchI+PYhL3h/4Pd9vQOhBM8khs\nVWot0Qupa6SU9rhEURThWXez/ocUR+gecGDZv/G69POTbQbyGPZr1T4QugArWN2N\nIMU+Cd9KM513UTyXszSAPqB1CmO165ACwEVdnUhdQUHX8zs7Fni33RblAQKBgH5O\nk7gshuGqYFr0FYtp6QZsWX5o9LeJEGcu/qHMoWkSX2JwvGNxz39b5EOwZbXxrMQ9\nbcBvzfZLUU64t7Z0nl2Hssrk9VJkYOutLQNCW+gtk2QJSLujL8amOvL4CVVghirj\nFd9X+84kEeLQI4uvSR2K2TnvJBhUfuMIVeQZi2fzAoGBAONONeLM+oNftNjfnZjH\nNKFg2PdbHhSv0TRMlaOs/kiQDyM3zmb08MpPElpBdebBFtUyaUW+8KsQxv6QHvt6\nJ5Owh/otMAq1FqR3EsuLFXV0y8uZx9LbpldkZU8FfDacBwLO+fOQetGQ/Ultd2oE\nhVxCbWMuej8iKzAwNaaB6iiC\n-----END PRIVATE KEY-----\n",
    "client_email": "local-352@xenon-lyceum-438710-s2.iam.gserviceaccount.com",
    "client_id": "102432463023606091042",
    "auth_uri": "https://accounts.google.com/o/oauth2/auth",
    "token_uri": "https://oauth2.googleapis.com/token",
    "auth_provider_x509_cert_url": "https://www.googleapis.com/oauth2/v1/certs",
    "client_x509_cert_url": "https://www.googleapis.com/robot/v1/metadata/x509/local-352%40xenon-lyceum-438710-s2.iam.gserviceaccount.com",
    "universe_domain": "googleapis.com",
}

SCOPES = [
    "https://www.googleapis.com/auth/drive.readonly",
    "https://www.googleapis.com/auth/spreadsheets",
    "https://www.googleapis.com/auth/drive.file",
]

credentials = service_account.Credentials.from_service_account_info(
    google_credentials, scopes=SCOPES
)
drive_service = build("drive", "v3", credentials=credentials)
sheets_service = build("sheets", "v4", credentials=credentials)

CRM_SPREADSHEET_URL = (
    f"https://docs.google.com/spreadsheets/d/{os.environ['CRM_SPREADSHEET_ID']}"
)


# Cria função para buscar, em planilha CRM, na aba "VENDAS", id da venda pelo submission_id do Jotform.
# O submission_id está presente na aba "VND" na coluna AV. O id da venda está na coluna B de "VND".
# A planilha é pública, utilize a Google Visualization API query para buscar somente a linha desejada.
def get_sale_id_by_jotform_submission_id(submission_id: int) -> int | None:
    query = f"SELECT B WHERE AV = {submission_id}"
    params = {
        "tq": query,
        "sheet": "VND",  # Nome da sua aba
        "headers": 1,  # Indica que a primeira linha contém cabeçalhos
    }

    url = "{}/gviz/tq?tq={}&sheet={}&headers={}".format(
        CRM_SPREADSHEET_URL,
        quote(str(params["tq"])),
        quote(str(params["sheet"])),
        quote(str(params["headers"])),
    )

    try:
        response = requests.get(url)

        if response.status_code != 200:
            logger.error(f"Erro ao buscar dados em CRM: {response.text}")
            raise Exception("Erro ao buscar dados em CRM")

        # A resposta vem em um formato específico que precisa ser limpo
        # Remove o prefixo "google.visualization.Query.setResponse("
        json_data = response.text
        start = json_data.find("{")
        end = json_data.rfind("}") + 1
        json_data = json_data[start:end]

        # Converter para objeto Python
        data = json.loads(json_data)

        # Verificar se há resultados
        if not data.get("table") or not data["table"].get("rows"):
            return None

        # Extrair os cabeçalhos e valores
        cols = [col["label"] for col in data["cols"]]
        row = [v.get("v") for v in data["rows"][0]["c"]]

        # Retornar somente o valor da coluna B
        return int(row[cols.index("B")])

    except Exception as e:
        logger.error(f"Erro ao buscar dados: {e}")
        return None


def parse_value(value: str | None) -> int:
    """
    Converte string de valor em centavos, suportando múltiplos formatos:
    - R$52,99
    - R$52.99
    - R$ 52,99
    - R$ 52.99
    - 52,99
    - 52.99
    - 52

    Args:
        value: String contendo o valor monetário ou None

    Returns:
        int: Valor em centavos
    """
    if not value:
        return 0

    # Remove 'R$' e espaços
    clean_value = value.replace("R$", "").strip()

    try:
        # Trata caso de número inteiro
        if clean_value.isdigit():
            return int(clean_value) * 100

        # Padroniza separador decimal para ponto
        if "," in clean_value:
            clean_value = clean_value.replace(".", "").replace(",", ".")

        # Converte para float e depois para centavos
        return int(float(clean_value) * 100)
    except (ValueError, TypeError):
        return 0


def get_sale_info(sale_id: int | str) -> OrderRead | None:
    """
    Busca informações de uma venda específica nas abas VND e VENDAS do CRM.

    Args:
        sale_id (int): ID da venda a ser buscada

    Returns:
        OrderRead | None: Objeto com as informações da venda ou None se não encontrar
    """
    # Primeira query para buscar dados da aba VENDAS
    query_vendas = f"SELECT * WHERE A = {sale_id}"
    params_vendas = {"tq": query_vendas, "sheet": "VENDAS", "headers": 1}

    url_vendas = "{}/gviz/tq?tq={}&sheet={}&headers={}".format(
        CRM_SPREADSHEET_URL,
        quote(str(params_vendas["tq"])),
        quote(str(params_vendas["sheet"])),
        quote(str(params_vendas["headers"])),
    )

    # Segunda query para buscar dados da aba VND
    query_vnd = f"SELECT * WHERE B = {sale_id}"
    params_vnd = {"tq": query_vnd, "sheet": "VND", "headers": 1}

    url_vnd = "{}/gviz/tq?tq={}&sheet={}&headers={}".format(
        CRM_SPREADSHEET_URL,
        quote(str(params_vnd["tq"])),
        quote(str(params_vnd["sheet"])),
        quote(str(params_vnd["headers"])),
    )
    try:
        # Buscar dados da aba VENDAS
        response_vendas = requests.get(url_vendas)

        if response_vendas.status_code != 200:
            logger.error(f"Erro ao buscar dados em VENDAS: {response_vendas.text}")
            return None

        # Processar resposta de VENDAS
        json_data_vendas = response_vendas.text
        start = json_data_vendas.find("{")
        end = json_data_vendas.rfind("}") + 1
        data_vendas = json.loads(json_data_vendas[start:end])

        if not data_vendas.get("table") or not data_vendas["table"].get("rows"):
            logger.error(f"Venda {sale_id} não encontrada na aba VENDAS")
            return None

        row_vendas = data_vendas["table"].get("rows")[0]["c"]

        # Buscar dados da aba VND
        response_vnd = requests.get(url_vnd)

        if response_vnd.status_code != 200:
            logger.error(f"Erro ao buscar dados em VND: {response_vnd.text}")
            return None

        # Processar resposta de VND
        json_data_vnd = response_vnd.text
        start = json_data_vnd.find("{")
        end = json_data_vnd.rfind("}") + 1
        data_vnd = json.loads(json_data_vnd[start:end])

        if not data_vnd.get("table") or not data_vnd["table"].get("rows"):
            logger.error(f"Venda {sale_id} não encontrada na aba VND")
            return None

        row_vnd = data_vnd["table"].get("rows")[0]["c"]

        # Dados do destinatário (aba VND)
        endereco_destinatario = Endereco(
            cep=row_vnd[5]["v"],
            logradouro=row_vnd[6]["v"],
            numero=int(row_vnd[7]["v"]),
            complemento=row_vnd[9]["v"] if row_vnd[9] and row_vnd[9].get("v") else None,
            bairro=row_vnd[10]["v"],
            cidade=row_vnd[11]["v"],
            uf=UF(row_vnd[12]["v"]),
        )

        destinatario = Destinatario(
            pessoa_tipo=PessoaTipo.FISICA
            if row_vnd[13]["v"] == "Pessoa física (PF)"
            else PessoaTipo.JURIDICA,
            cpf=row_vnd[14]["v"] if row_vnd[13]["v"] == "Pessoa física (PF)" else None,
            cnpj=row_vnd[14]["v"]
            if row_vnd[13]["v"] == "Pessoa jurídica (PJ)"
            else None,
            nome=row_vnd[15]["v"] if row_vnd[13]["v"] == "Pessoa física (PF)" else None,
            razao_social=row_vnd[15]["v"]
            if row_vnd[13]["v"] == "Pessoa jurídica (PJ)"
            else None,
            email=row_vnd[16]["v"],
            telefone=row_vnd[17]["v"],
            endereco=endereco_destinatario,
        )

        # Dados do emitente (aba VND)
        endereco_emitente = Endereco(
            cep=row_vnd[31]["v"],
            logradouro=row_vnd[32]["v"],
            numero=int(row_vnd[33]["v"]),
            complemento=row_vnd[35]["v"]
            if row_vnd[35] and row_vnd[35].get("v")
            else None,
            bairro=row_vnd[36]["v"],
            cidade=row_vnd[37]["v"],
            uf=UF(row_vnd[38]["v"]),
        )

        emitente = Emitente(
            pessoa_tipo=PessoaTipo.FISICA
            if row_vnd[39]["v"] == "Pessoa física (PF)"
            else PessoaTipo.JURIDICA,
            cpf=row_vnd[40]["v"] if row_vnd[39]["v"] == "Pessoa física (PF)" else None,
            cnpj=row_vnd[40]["v"]
            if row_vnd[39]["v"] == "Pessoa jurídica (PJ)"
            else None,
            nome=row_vnd[41]["v"] if row_vnd[39]["v"] == "Pessoa física (PF)" else None,
            email=row_vnd[42]["v"],
            telefone=row_vnd[43]["v"],
            endereco=endereco_emitente,
            razao_social=row_vnd[41]["v"]
            if row_vnd[39]["v"] == "Pessoa jurídica (PJ)"
            else None,
            rg=row_vnd[20]["v"] if row_vnd[39]["v"] == "Pessoa física (PF)" else None,
            inscricao_estadual=row_vnd[20]["v"]
            if row_vnd[39]["v"] == "Pessoa jurídica (PJ)"
            else None,
        )

        # Processar produtos (aba VND)
        produtos = []
        if row_vnd[4] and row_vnd[4].get("v"):
            produtos_str = row_vnd[4]["v"]
            for produto_str in produtos_str.split("\n"):
                if not produto_str:
                    continue
                partes = dict(parte.split(":") for parte in produto_str.split(", "))
                produtos.append(
                    ProdutoItem(
                        id=int(
                            partes[
                                "ID Gubo do Produto (consulte em seu painel de controle)"
                            ].strip()
                        ),
                        cor=Cor(partes["Cor"].strip()),
                        tamanho=Tamanho(partes["Tamanho"].strip()),
                        quantidade=int(partes["Quantidade"].strip()),
                        preco_venda=parse_value(
                            partes.get("Seu preço de venda (opcional)", "0").strip()
                        )
                        or None,
                    )
                )

        # Extrair status do pedido (coluna Q ou índice 16)
        status = StatusPedido(row_vendas[18]["v"])

        # Criar objeto OrderRead combinando dados das duas abas
        order = OrderRead(
            id=sale_id,
            email=row_vnd[2]["v"].split("#")[0],  # Email do comprador (VND)
            nome_loja=row_vnd[2]["v"].split("#")[1] if "#" in row_vnd[2]["v"] else "",
            produtos=produtos,
            destinatario=destinatario,
            emitente=emitente,
            status=status,  # Status do pedido (VENDAS)
            cod_rastreio=row_vendas[24]["v"]
            if row_vendas[24] and row_vendas[24].get("v")
            else None,  # Código rastreio (VENDAS)
            rastreio_url="https://www2.kangu.com.br/rastreio/",  # URL rastreio (VENDAS)
            identificacao_interna=row_vnd[29]["v"]
            if row_vnd[29] and row_vnd[29].get("v")
            else None,  # ID interno (VND)
        )

        return order

    except Exception as e:
        logger.error(f"Erro ao buscar informações da venda {sale_id}: {e}")
        return None
