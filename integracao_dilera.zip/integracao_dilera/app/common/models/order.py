from datetime import datetime

from pydantic import (
    AnyHttpUrl,
    BaseModel,
    EmailStr,
    Field,
    PositiveInt,
    ValidationInfo,
    field_validator,
)

from app.common import jotform
from app.common.models.enum import UF, Cor, PessoaTipo, StatusPedido, Tamanho
from app.utils.validators import is_cnpj_valid, is_cpf_valid


class Endereco(BaseModel):
    # Cep deve ter regex para validar
    cep: str = Field(..., pattern=r"\d{2}\.?\d{3}-?\d{3}")
    logradouro: str
    numero: int
    complemento: str | None = None
    bairro: str
    cidade: str
    uf: UF


class Emitente(BaseModel):
    endereco: Endereco
    email: EmailStr
    telefone: str
    pessoa_tipo: PessoaTipo
    cpf: str | None = None
    cnpj: str | None = None
    nome: str | None = None
    razao_social: str | None = None
    rg: str | None = None
    inscricao_estadual: str | None = None

    @field_validator("cnpj")
    @classmethod
    def format_cnpj(cls, v: str, info: ValidationInfo):  # noqa N805
        if info.data["pessoa_tipo"] == PessoaTipo.JURIDICA and not v:
            raise ValueError("CNPJ é obrigatório para pessoa jurídica")
        if not v:
            return v
        if not is_cnpj_valid(v):
            raise ValueError("Invalid CNPJ")

        # Remove caracteres não numéricos
        v = "".join(filter(str.isdigit, v))
        # Formata CNPJ
        v = f"{v[:2]}.{v[2:5]}.{v[5:8]}/{v[8:12]}-{v[12:]}"

        return v

    @field_validator("cpf")
    @classmethod
    def verify_cpf(cls, v: str, info: ValidationInfo):  # noqa N805
        if info.data["pessoa_tipo"] == PessoaTipo.FISICA and not v:
            raise ValueError("CPF é obrigatório para pessoa física")
        if not v:
            return v
        if not is_cpf_valid(v):
            raise ValueError("Invalid CPF")

        # Remove caracteres não numéricos
        v = "".join(filter(str.isdigit, v))
        # Formata CPF
        v = f"{v[:3]}.{v[3:6]}.{v[6:9]}-{v[9:]}"

        return v

    @field_validator("nome", "rg")
    @classmethod
    def verify_pf(cls, v: str, info: ValidationInfo):  # noqa N805
        if info.data["pessoa_tipo"] == PessoaTipo.FISICA and not v:
            raise ValueError("Nome e RG são obrigatórios para pessoa física")
        return v

    @field_validator("razao_social", "inscricao_estadual")
    @classmethod
    def verify_pj(cls, v: str, info: ValidationInfo):  # noqa N805
        if info.data["pessoa_tipo"] == PessoaTipo.JURIDICA and not v:
            raise ValueError(
                "Razão social e Inscrição Estadual são obrigatórios para pessoa jurídica"
            )
        return v


class ProdutoItem(BaseModel):
    id: int = Field(..., description="ID Gubo do produto")
    cor: Cor
    tamanho: Tamanho
    quantidade: PositiveInt
    preco_venda: int | None = Field(
        default=None,
        description="Seu preço de venda unitário (opcional). Representado em centavos de Real. Ex: 1000 = R$ 10,00",
    )


class Destinatario(BaseModel):
    endereco: Endereco
    email: EmailStr
    telefone: str
    pessoa_tipo: PessoaTipo
    cpf: str | None = None
    cnpj: str | None = None
    nome: str | None = None
    razao_social: str | None = None

    @field_validator("cnpj")
    @classmethod
    def format_cnpj(cls, v: str, info: ValidationInfo):  # noqa N805
        if info.data["pessoa_tipo"] == PessoaTipo.JURIDICA and not v:
            raise ValueError("CNPJ é obrigatório para pessoa jurídica")
        if not v:
            return v
        if not is_cnpj_valid(v):
            raise ValueError("Invalid CNPJ")

        # Remove caracteres não numéricos
        v = "".join(filter(str.isdigit, v))
        # Formata CNPJ
        v = f"{v[:2]}.{v[2:5]}.{v[5:8]}/{v[8:12]}-{v[12:]}"

        return v

    @field_validator("cpf")
    @classmethod
    def verify_cpf(cls, v: str, info: ValidationInfo):  # noqa N805
        if info.data["pessoa_tipo"] == PessoaTipo.FISICA and not v:
            raise ValueError("CPF é obrigatório para pessoa física")
        if not v:
            return v
        if not is_cpf_valid(v):
            raise ValueError("Invalid CPF")

        # Remove caracteres não numéricos
        v = "".join(filter(str.isdigit, v))
        # Formata CPF
        v = f"{v[:3]}.{v[3:6]}.{v[6:9]}-{v[9:]}"

        return v

    @field_validator("nome")
    @classmethod
    def verify_nome(cls, v: str, info: ValidationInfo):  # noqa N805
        if info.data["pessoa_tipo"] == PessoaTipo.FISICA and not v:
            raise ValueError("Nome é obrigatório para pessoa física")
        return v

    @field_validator("razao_social")
    @classmethod
    def verify_razao_social(cls, v: str, info: ValidationInfo):  # noqa N805
        if info.data["pessoa_tipo"] == PessoaTipo.JURIDICA and not v:
            raise ValueError("Razão social é obrigatória para pessoa jurídica")
        return v


class OrderBase(BaseModel):
    email: EmailStr = Field(..., description="E-mail cadastrado na Gubo")
    nome_loja: str = Field(..., description="Nome da loja na Gubo")
    produtos: list[ProdutoItem]
    destinatario: Destinatario
    emitente: Emitente = Field(..., description="Dados do emitente da nota fiscal")
    identificacao_interna: str | None = None

    def to_jotform(self):
        jotform_produtos = []
        for produto in self.produtos:
            jotform_produtos.append(
                jotform.ProductItem(
                    id=produto.id,
                    color=produto.cor,
                    size=produto.tamanho,
                    quantity=produto.quantidade,
                    sale_price=f"R${produto.preco_venda/100:.2f}".replace(".", ",")
                    if produto.preco_venda
                    else None,
                )
            )
        return jotform.PurchaseSubmission(
            # email=f'{self.email}#{self.nome_loja}',
            email=self.email,
            products=jotform_produtos,
            shipping_address=jotform.ShippingAddress(
                zipcode=self.destinatario.endereco.cep,
                street=self.destinatario.endereco.logradouro,
                number=self.destinatario.endereco.numero,
                complement=self.destinatario.endereco.complemento,
                neighborhood=self.destinatario.endereco.bairro,
                city=self.destinatario.endereco.cidade,
                state=self.destinatario.endereco.uf,
            ),
            recipient=jotform.Recipient(
                person_type=jotform.PersonType.PF
                if self.destinatario.pessoa_tipo == PessoaTipo.FISICA
                else jotform.PersonType.PJ,
                document=self.destinatario.cpf or self.destinatario.cnpj,  # type: ignore
                name=self.destinatario.nome or self.destinatario.razao_social,  # type: ignore
                email=self.destinatario.email,
                phone=self.destinatario.telefone,
            ),
            billing=jotform.BillingInfo(
                billing_type=jotform.BillingType.MANUAL,
                address=jotform.BillingAddress(
                    zipcode=self.emitente.endereco.cep,
                    street=self.emitente.endereco.logradouro,
                    number=self.emitente.endereco.numero,
                    complement=self.emitente.endereco.complemento,
                    neighborhood=self.emitente.endereco.bairro,
                    city=self.emitente.endereco.cidade,
                    state=self.emitente.endereco.uf,
                ),
                person=jotform.BillingPerson(
                    person_type=jotform.PersonType.PF
                    if self.emitente.pessoa_tipo == PessoaTipo.FISICA
                    else jotform.PersonType.PJ,
                    document=self.emitente.cpf or self.emitente.cnpj,  # type: ignore
                    name=self.emitente.nome or self.emitente.razao_social,  # type: ignore
                    email=self.emitente.email,
                    phone=self.emitente.telefone,
                    registration=self.emitente.rg or self.emitente.inscricao_estadual,  # type: ignore
                ),
            ),
            payment_method=jotform.PaymentMethod.PIX,
            internal_id=self.identificacao_interna,
            discount_coupon=None,
        )

    class Config:
        extra = "ignore"
        validate_assignment = True
        json_encoders = {
            datetime: lambda x: x.isoformat(),
        }


class OrderCreate(OrderBase):
    model_config = {
        "json_schema_extra": {
            "examples": [
                {
                    "email": "loja@email.com",
                    "nome_loja": "Nome da Loja",
                    "produtos": [
                        {
                            "id": 1,
                            "cor": "Off White",
                            "tamanho": "G",
                            "quantidade": 1,
                            "preco_venda": 1000,
                        }
                    ],
                    "destinatario": {
                        "endereco": {
                            "cep": "00000-000",
                            "logradouro": "Rua do Cliente",
                            "numero": 0,
                            "complemento": "Casa",
                            "bairro": "Bairro",
                            "cidade": "Cidade",
                            "uf": "SP",
                        },
                        "email": "cliente@email.com",
                        "telefone": "11999999999",
                        "pessoa_tipo": "PF",
                        "cpf": "938.747.730-43",
                        "nome": "Nome do Cliente",
                    },
                    "emitente": {
                        "endereco": {
                            "cep": "00000000",
                            "logradouro": "Rua da Loja",
                            "numero": 0,
                            "complemento": "Casa",
                            "bairro": "Bairro",
                            "cidade": "Cidade",
                            "uf": "SP",
                        },
                        "email": "loja@email.com",
                        "telefone": "11999999999",
                        "pessoa_tipo": "PF",
                        "nome": "Nome da Loja",
                        "razao_social": "Razão Social",
                        "rg": "123456789",
                        "inscricao_estadual": "123456789",
                        "cpf": "00064984001",
                    },
                    "identificacao_interna": "ABC123",
                }
            ]
        }
    }


class OrderRead(OrderBase):
    id: int = Field(..., description="ID do pedido")
    status: StatusPedido
    cod_rastreio: str | None = None
    rastreio_url: AnyHttpUrl | None = None
