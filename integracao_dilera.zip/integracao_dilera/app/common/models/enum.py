from enum import Enum


class StatusPedido(str, Enum):
    PROCESSANDO_PEDIDO = "⏱ Processando Pedido"
    AGUARDANDO_PAGAMENTO = "💰 Aguardando Pagamento"
    EM_PRODUCAO = "🏭 Em Produção"
    EM_TRANSITO = "🚚  Em Trânsito"
    ENTREGUE = "✅ Entregue"
    CANCELADO = "⛔ Cancelado"
    EXTRAVIO = "⛔ Extravio"
    PENDENTE = "⚠️ Pendente"


class StatusNFe(str, Enum):
    NAO_GERADO = "Não Gerado"
    NFE_CLIENTE = "1. NFE CLIENTE"
    NFE_REMESSA = "2. NFE REMESSA"
    NFE_REMESSA_KANGU = "3. REMESSA KANGU"
    CONCLUIDO = "CONCLUÍDO"
    PENDENTE = "PENDENTE"


class Cor(str, Enum):
    PRETO = "Preto"
    BRANCO = "Branco"
    OFF_WHITE = "Off White"
    AREIA = "Areia"
    ALGODAO_CRU = "Algodão Cru"


class UF(str, Enum):
    SP = "SP"
    AC = "AC"
    AL = "AL"
    AM = "AM"
    AP = "AP"
    BA = "BA"
    CE = "CE"
    DF = "DF"
    ES = "ES"
    GO = "GO"
    MA = "MA"
    MG = "MG"
    MS = "MS"
    MT = "MT"
    PA = "PA"
    PB = "PB"
    PE = "PE"
    PI = "PI"
    PR = "PR"
    RJ = "RJ"
    RN = "RN"
    RO = "RO"
    RR = "RR"
    RS = "RS"
    SC = "SC"
    SE = "SE"
    TO = "TO"


class Local(str, Enum):
    FRENTE = "frente"
    COSTAS = "costas"
    MANGA = "manga"
    GOLA = "gola"
    BOLSO = "bolso"
    BARRA = "barra"


class LocalEtiqueta(Enum):
    GOLA = "gola"
    MANGA = "manga"
    BARRA = "barra"


class Modelo(Enum):
    CAMISETA = "camiseta"
    CAMISA = "camisa"
    POLO = "polo"
    REGATA = "regata"
    MOLETOM = "moletom"
    JAQUETA = "jaqueta"
    BLUSA = "blusa"
    VESTIDO = "vestido"
    CALCA = "calca"
    SHORTS = "shorts"
    SAIA = "saia"
    MACACAO = "macacao"
    CAMISETA_INFANTIL = "camiseta_infantil"
    CAMISA_INFANTIL = "camisa_infantil"
    POLO_INFANTIL = "polo_infantil"
    REGATA_INFANTIL = "regata_infantil"
    MOLETOM_INFANTIL = "moletom_infantil"
    JAQUETA_INFANTIL = "jaqueta_infantil"
    BLUSA_INFANTIL = "blusa_infantil"
    VESTIDO_INFANTIL = "vestido_infantil"
    CALCA_INFANTIL = "calca_infantil"
    SHORTS_INFANTIL = "shorts_infantil"
    SAIA_INFANTIL = "saia_infantil"
    MACACAO_INFANTIL = "macacao_infantil"


class Posicao(Enum):
    ESQUERDA = "esquerda"
    DIREITA = "direita"
    CENTRO = "centro"
    SUPERIOR = "superior"
    INFERIOR = "inferior"


class Tamanho(str, Enum):
    P = "P"
    M = "M"
    G = "G"
    GG = "GG"
    XG = "XG"
    XGG = "XGG"
    UNI = "UNI"


class PessoaTipo(str, Enum):
    FISICA = "PF"
    JURIDICA = "PJ"
