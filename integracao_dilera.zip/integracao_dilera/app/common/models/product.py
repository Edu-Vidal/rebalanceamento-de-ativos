from datetime import datetime

from pydantic import BaseModel

from app.common.models.enum import Cor, Local, LocalEtiqueta, Modelo, Posicao, Tamanho
from app.utils.partial import optional


class Mockup(BaseModel):
    url: str


# Adicionar documentação para unidade de medida de largura e altura cm
class Estampa(BaseModel):
    url: str
    local: Local
    posicao: Posicao
    largura: float
    altura: float
    observacao: str | None


class Etiqueta(BaseModel):
    url: str
    local: LocalEtiqueta


class Tag(BaseModel):
    url: str


class CartaDeAgradecimento(BaseModel):
    url: str


class Saco(BaseModel):
    url: str


class ProductBase(BaseModel):
    codigo_interno: str
    nome: str
    modelo: Modelo
    tamanho: list[Tamanho]
    cor: Cor
    preco: float
    estampas: list[Estampa]
    mockups: list[Mockup]
    etiquetas: list[Etiqueta]
    tag: Tag
    carta_de_agradecimento: CartaDeAgradecimento
    saco: Saco

    class Config:
        extra = "ignore"
        validate_assignment = True
        json_encoders = {
            datetime: lambda x: x.isoformat(),
        }


class ProductCreate(ProductBase):
    pass


@optional
class ProductUpdate(ProductBase):
    pass


class ProductRead(ProductBase):
    preco_total: float
