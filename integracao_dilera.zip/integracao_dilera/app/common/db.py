api_keys = {
    "e54d4431-5dab-474e-b71a-0db1fcb9e659": "7oDYjo3d9r58EJKYi5x4E8",
    "f3c5c6e1-6c2f-4b8a-9c2f-6d7b9d3f6f4b": "rfGu7Vp45aiA1MrATiTaISi",
}

users = {
    "7oDYjo3d9r58EJKYi5x4E8": {"email": "leads4you@email.com"},
    "rfGu7Vp45aiA1MrATiTaISi": {"email": "oi@gubo.com"},
}


def check_api_key(api_key: str):
    return api_key in api_keys


def get_user_from_api_key(api_key: str):
    return users[api_keys[api_key]]
