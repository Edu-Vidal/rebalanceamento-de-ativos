from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import select
from sqlmodel.sql.expression import Select, SelectOfScalar

from app.common.db.session import get_session
from app.common.models.tables import City, State

# https://github.com/tiangolo/sqlmodel/issues/189
SelectOfScalar.inherit_cache = True  # type: ignore
Select.inherit_cache = True  # type: ignore


async def get_cities(db_session: AsyncSession | None = None) -> list[City]:
    db_session = db_session or get_session()

    result = await db_session.execute(select(City))

    return result.scalars().all()


async def get_states(db_session: AsyncSession | None = None) -> list[State]:
    db_session = db_session or get_session()

    result = await db_session.execute(select(State))

    return result.scalars().all()
