from fastapi import HTTPException
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import select
from sqlmodel.sql.expression import Select, SelectOfScalar

from app.common.db.session import get_session
from app.common.models.tables import KeyStore

# https://github.com/tiangolo/sqlmodel/issues/189
SelectOfScalar.inherit_cache = True  # type: ignore
Select.inherit_cache = True  # type: ignore


async def get_keys(
    is_active: bool | None = None,
    db_session: AsyncSession | None = None,
) -> list[KeyStore]:
    db_session = db_session or get_session()

    query = select(KeyStore)

    if is_active is not None:
        query = query.where(KeyStore.is_active == is_active)

    result = await db_session.execute(query)

    return result.scalars().all()


async def create_key(
    key: KeyStore,
    db_session: AsyncSession | None = None,
) -> KeyStore:
    db_session = db_session or get_session()

    db_session.add(key)
    try:
        await db_session.commit()
        await db_session.refresh(key)
    except Exception as e:
        await db_session.rollback()
        raise HTTPException(status_code=500, detail=str(e)) from e

    return key
