from fastapi import HTTPException, status
from sqlalchemy import exc
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import select
from sqlmodel.sql.expression import Select, SelectOfScalar

from app.common.db.session import get_session
from app.common.models.role import RoleCreate, RoleUpdate
from app.common.models.tables import Role

# https://github.com/tiangolo/sqlmodel/issues/189
SelectOfScalar.inherit_cache = True  # type: ignore
Select.inherit_cache = True  # type: ignore


async def create_role(
    role_create: RoleCreate, db_session: AsyncSession | None = None
) -> Role:
    db_session = db_session or get_session()

    role = Role.from_orm(role_create)

    try:
        db_session.add(role)
        await db_session.commit()
    except exc.IntegrityError as e:
        await db_session.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Role ja existe. Verifique os dados e tente novamente.",
        ) from e
    await db_session.refresh(role)

    return role


async def get_role_by_id(
    role_id: int, db_session: AsyncSession | None = None
) -> Role | None:
    db_session = db_session or get_session()
    result = await db_session.execute(select(Role).where(Role.role_id == role_id))

    return result.scalar_one_or_none()


async def get_role_by_name(
    name: str, db_session: AsyncSession | None = None
) -> Role | None:
    db_session = db_session or get_session()
    result = await db_session.execute(select(Role).where(Role.name == name))

    return result.scalar_one_or_none()


async def delete_role(role: Role, db_session: AsyncSession | None = None) -> None:
    db_session = db_session or get_session()

    await db_session.delete(role)
    await db_session.commit()


async def get_roles(db_session: AsyncSession | None = None) -> list[Role]:
    db_session = db_session or get_session()

    result = await db_session.execute(select(Role))

    return result.scalars().all()


async def update_role(
    current_role: Role, new_role: RoleUpdate, db_session: AsyncSession | None = None
) -> Role:
    db_session = db_session or get_session()

    update_data = new_role.dict(exclude_unset=True)

    for field in update_data:
        setattr(current_role, field, update_data[field])

    db_session.add(current_role)
    await db_session.commit()
    await db_session.refresh(current_role)

    return current_role
