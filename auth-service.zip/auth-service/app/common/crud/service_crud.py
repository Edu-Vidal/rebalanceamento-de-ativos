from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import select
from sqlmodel.sql.expression import Select, SelectOfScalar

from app.common.db.session import get_session
from app.common.models.tables import Service

# https://github.com/tiangolo/sqlmodel/issues/189
SelectOfScalar.inherit_cache = True  # type: ignore
Select.inherit_cache = True  # type: ignore


async def get_services(
    db_session: AsyncSession | None = None,
) -> list[Service]:
    db_session = db_session or get_session()

    query = select(Service)

    result = await db_session.execute(query)

    return result.scalars().all()
