from uuid import UUID

from fastapi import HTTPException, status
from sqlalchemy import exc
from sqlalchemy.ext.asyncio import AsyncSession
from sqlmodel import select
from sqlmodel.sql.expression import Select, SelectOfScalar

from app.common.db.session import get_session
from app.common.models.address import AddressCreate, AddressUpdate
from app.common.models.tables import Account, Address

# https://github.com/tiangolo/sqlmodel/issues/189
SelectOfScalar.inherit_cache = True  # type: ignore
Select.inherit_cache = True  # type: ignore


async def create_address(
    address_create: AddressCreate, db_session: AsyncSession | None = None
) -> Address:
    db_session = db_session or get_session()

    address = Address.from_orm(address_create)
    try:
        db_session.add(address)
        await db_session.commit()
    except exc.IntegrityError as e:
        await db_session.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Conta ja existe. Verifique os dados e tente novamente.",
        ) from e
    await db_session.refresh(address)

    return address


async def update_address(
    current_address: Address,
    new_address: AddressUpdate,
    db_session: AsyncSession | None = None,
) -> Address:
    db_session = db_session or get_session()
    update_data = new_address.dict(exclude_unset=True)

    for field in update_data:
        setattr(current_address, field, update_data[field])

    db_session.add(current_address)
    await db_session.commit()
    await db_session.refresh(current_address)

    return current_address


async def delete_address(
    address: Address, db_session: AsyncSession | None = None
) -> None:
    db_session = db_session or get_session()

    await db_session.delete(address)


async def get_addresses(db_session: AsyncSession | None = None) -> list[Account]:
    db_session = db_session or get_session()

    query = select(Address)

    accounts = await db_session.execute(query)

    return accounts.scalars().all()


async def get_address(
    address_id: UUID, db_session: AsyncSession | None = None
) -> Address | None:
    db_session = db_session or get_session()

    query = select(Address).where(Address.address_id == address_id)

    address = await db_session.execute(query)

    return address.scalar_one_or_none()
