from uuid import UUID

from fastapi import HTTPException, status
from fastapi_pagination import Page, Params
from fastapi_pagination.ext.sqlalchemy import paginate
from sqlalchemy import exc
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm.attributes import flag_modified
from sqlalchemy.sql.expression import false, true
from sqlmodel import cast, col, desc, select
from sqlmodel.sql.expression import Select, SelectOfScalar

from app.common.db.session import get_session
from app.common.models.enum import ServiceType
from app.common.models.tables import User
from app.common.models.user import (
    UserCreate,
    UserUpdate,
)

# https://github.com/tiangolo/sqlmodel/issues/189
SelectOfScalar.inherit_cache = True  # type: ignore
Select.inherit_cache = True  # type: ignore


async def create_user(
    user_create: UserCreate, db_session: AsyncSession | None = None
) -> User:
    db_session = db_session or get_session()

    user = User.from_orm(user_create)
    db_session.add(user)
    try:
        await db_session.commit()
        await db_session.refresh(user)
    except exc.IntegrityError as e:
        await db_session.rollback()
        # Checa se o erro é de duplicidade de email
        if 'duplicate key value violates unique constraint "User_email_key"' in str(e):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Email já cadastrado. \
                    Insira um email diferente e tente novamente.",
            ) from e

        # Checa se o erro é de duplicidade de cpf
        if 'duplicate key value violates unique constraint "User_document_key"' in str(
            e
        ):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="CPF já cadastrado. \
                    Insira um CPF diferente e tente novamente.",
            ) from e

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao inserir dados no banco de dados. Acione o suporte.",
        ) from e

    return user


async def get_user_by_id(
    user_id: UUID | str, db_session: AsyncSession | None = None
) -> User | None:
    db_session = db_session or get_session()
    result = await db_session.execute(
        select(User).where(User.user_id == user_id).where(User.deleted == false())
    )

    return result.scalar_one_or_none()


async def get_user_by_name(
    user_name: str, db_session: AsyncSession | None = None
) -> User | None:
    db_session = db_session or get_session()
    result = await db_session.execute(
        select(User).where(User.user_name == user_name).where(User.deleted == false())
    )

    return result.scalar_one_or_none()


async def get_user_by_email(
    user_email: str, db_session: AsyncSession | None = None
) -> list[User]:
    db_session = db_session or get_session()
    results = await db_session.execute(
        select(User).where(User.email == user_email).where(User.deleted == false())
    )

    return results.scalars().all()


async def update_user(
    current_user: User,
    new_user: UserUpdate,
    db_session: AsyncSession | None = None,
) -> User:
    db_session = db_session or get_session()

    update_data = new_user.dict(exclude_unset=True)

    for field in update_data:
        setattr(current_user, field, update_data[field])
        flag_modified(current_user, field)

    db_session.add(current_user)
    try:
        await db_session.commit()
        await db_session.refresh(current_user)
    except exc.IntegrityError as e:
        await db_session.rollback()
        # Checa se o erro é de duplicidade de email
        if 'duplicate key value violates unique constraint "User_email_key"' in str(e):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="Email já cadastrado. \
                    Insira um email diferente e tente novamente.",
            ) from e

        # Checa se o erro é de duplicidade de cpf
        if 'duplicate key value violates unique constraint "User_document_key"' in str(
            e
        ):
            raise HTTPException(
                status_code=status.HTTP_409_CONFLICT,
                detail="CPF já cadastrado. \
                    Insira um CPF diferente e tente novamente.",
            ) from e

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao inserir dados no banco de dados. Acione o suporte.",
        ) from e

    return current_user


async def delete_user(user: User, db_session: AsyncSession | None = None) -> None:
    db_session = db_session or get_session()

    user.deleted = True
    db_session.add(user)

    await db_session.commit()


async def remove_user_from_db(
    user: User, db_session: AsyncSession | None = None
) -> None:
    db_session = db_session or get_session()

    await db_session.delete(user)

    await db_session.commit()


async def deactivate_user(user: User, db_session: AsyncSession | None = None) -> None:
    db_session = db_session or get_session()

    user.active = False

    db_session.add(user)

    await db_session.commit()


async def get_users(
    db_session: AsyncSession | None = None, include_deleted: bool = False
) -> list[User]:
    db_session = db_session or get_session()

    query = select(User)

    if not include_deleted:
        query = query.where(User.deleted == false())

    users = await db_session.execute(query)

    return users.scalars().all()


async def get_users_paginated(
    params: Params | None = Params(),
    order_by: str | None = None,
    descending: bool = True,
    account_id: UUID | None = None,
    trade_name_contains: str | None = None,
    user_name_contains: str | None = None,
    email_contains: str | None = None,
    active: bool | None = None,
    role_ids: list[int] | None = None,
    services: list[ServiceType] | None = None,
    db_session: AsyncSession | None = None,
) -> Page[User]:
    db_session = db_session or get_session()

    query = select(User).where(User.deleted == false())

    query = query.join(User.account).join(User.role)

    if account_id:
        query = query.where(User.account_id == account_id)
    if trade_name_contains:
        query = query.where(
            col(User.account.trade_name).ilike(f"%{trade_name_contains}%")
        )
    if user_name_contains:
        query = query.where(col(User.user_name).ilike(f"%{user_name_contains}%"))
    if email_contains:
        query = query.where(col(User.email).ilike(f"%{email_contains}%"))
    if active is not None:
        query = query.where(User.active == (true() if active else false()))
    if role_ids:
        query = query.where(col(User.role_id).in_(role_ids))
    if services:
        # https://www.postgresql.org/docs/9.0/functions-array.html
        query = query.where(cast(col(User.acl), JSONB).op("@>")(services))

    try:
        order_by_attribute = col(User.user_name)
        if order_by:
            order_by_attribute = getattr(User, order_by)
    except AttributeError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid 'order_by' field. Valid options are: \
                {list(User.__fields__.keys())}",
        ) from e

    query = query.order_by(
        desc(order_by_attribute) if descending else order_by_attribute
    )

    return await paginate(db_session, query, params)  # type: ignore
