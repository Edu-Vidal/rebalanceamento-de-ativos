from uuid import UUID

from fastapi import HTTPException, status
from fastapi_pagination import Page, Params
from fastapi_pagination.ext.sqlalchemy import paginate
from sqlalchemy import exc
from sqlalchemy.dialects.postgresql import JSONB
from sqlalchemy.ext.asyncio import AsyncSession
from sqlalchemy.orm.attributes import flag_modified
from sqlalchemy.sql.expression import false, true
from sqlmodel import cast, col, desc, select
from sqlmodel.sql.expression import Select, SelectOfScalar

from app.common.db.session import get_session
from app.common.models.account import AccountCreate, AccountUpdate
from app.common.models.enum import ServiceType
from app.common.models.tables import Account

# https://github.com/tiangolo/sqlmodel/issues/189
SelectOfScalar.inherit_cache = True  # type: ignore
Select.inherit_cache = True  # type: ignore


async def create_account(
    account_create: AccountCreate, db_session: AsyncSession | None = None
) -> Account:
    db_session = db_session or get_session()

    account = Account.from_orm(
        account_create,
    )
    try:
        db_session.add(account)
        await db_session.commit()
    except exc.IntegrityError as e:
        await db_session.rollback()
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Conta ja existe. Verifique os dados e tente novamente.",
        ) from e
    await db_session.refresh(account)

    return account


async def get_account_by_id(
    account_id: UUID | str, db_session: AsyncSession | None = None
) -> Account | None:
    db_session = db_session or get_session()
    result = await db_session.execute(
        select(Account)
        .where(Account.account_id == account_id)
        .where(Account.deleted == false())
    )

    return result.scalar_one_or_none()


async def get_account_by_name(
    trade_name: str, db_session: AsyncSession | None = None
) -> Account | None:
    db_session = db_session or get_session()
    result = await db_session.execute(
        select(Account)
        .where(Account.trade_name == trade_name)
        .where(Account.deleted == false())
    )

    return result.scalar_one_or_none()


async def get_account_by_cnpj(
    cnpj: str, db_session: AsyncSession | None = None
) -> Account | None:
    db_session = db_session or get_session()
    result = await db_session.execute(
        select(Account).where(Account.cnpj == cnpj).where(Account.deleted == false())
    )

    return result.scalar_one_or_none()


async def update_account(
    current_account: Account,
    new_account: AccountUpdate,
    db_session: AsyncSession | None = None,
) -> Account:
    db_session = db_session or get_session()

    if new_account.services:
        # new_services = set(new_account.services)
        # current_services = set(current_account.services)

        # services_added = new_services - current_services
        # services_removed = current_services - new_services

        # for user in current_account.users:
        #     flag_modified(user, "acl")
        #     if services_added:
        #         user.acl.extend(services_added)

        #     if services_removed:
        #         user.acl[:] = [
        #             service for service in user.acl if service not in services_removed
        #         ]
        for user in current_account.users:
            flag_modified(user, "acl")
            user.acl = new_account.services

    update_data = new_account.dict(exclude_unset=True)

    for field in update_data:
        setattr(current_account, field, update_data[field])
        flag_modified(current_account, field)

    db_session.add(current_account)
    await db_session.commit()
    await db_session.refresh(current_account)

    return current_account


async def delete_account(account, db_session: AsyncSession | None = None) -> None:
    db_session = db_session or get_session()

    # Quando deletar uma conta, deletar todos os usuários vinculados
    # Deletar significar modificar o atributo deleted para True
    for user in account.users:
        user.deleted = True
        db_session.add(user)

    account.deleted = True
    db_session.add(account)

    await db_session.commit()


async def remove_account_from_db(
    account, db_session: AsyncSession | None = None
) -> None:
    db_session = db_session or get_session()

    # Quando deletar uma conta, deletar todos os usuários vinculados
    for user in account.users:
        await db_session.delete(user)

    await db_session.delete(account)
    await db_session.commit()


async def activate_account(
    account: Account, db_session: AsyncSession | None = None
) -> None:
    db_session = db_session or get_session()

    # Quando ativar uma conta, não ativa os usuários vinculados
    # Ativar significar modificar o atributo active para True
    account.active = True

    db_session.add(account)

    await db_session.commit()


async def deactivate_account(
    account: Account, db_session: AsyncSession | None = None
) -> None:
    db_session = db_session or get_session()

    # Quando desativar uma conta, desativar todos os usuários vinculados
    # Desativar significar modificar o atributo active para False
    for user in account.users:
        user.active = False
        db_session.add(user)

    account.active = False

    db_session.add(account)

    await db_session.commit()


async def get_accounts(
    db_session: AsyncSession | None = None, include_deleted: bool = False
) -> list[Account]:
    db_session = db_session or get_session()

    query = select(Account)
    if not include_deleted:
        query = query.where(Account.deleted == false())

    accounts = await db_session.execute(query)

    return accounts.scalars().all()


async def get_accounts_paginated(
    params: Params | None = Params(),
    order_by: str | None = None,
    descending: bool = True,
    trade_name_contains: str | None = None,
    active: bool | None = None,
    services: list[ServiceType] | None = None,
    db_session: AsyncSession | None = None,
) -> Page[Account]:
    db_session = db_session or get_session()

    query = select(Account).where(Account.deleted == false())

    if trade_name_contains:
        query = query.where(col(Account.trade_name).ilike(f"%{trade_name_contains}%"))
    if active is not None:
        query = query.where(Account.active == (true() if active else false()))
    if services:
        query = query.where(cast(col(Account.services), JSONB).op("@>")(services))

    try:
        order_by_attribute = col(Account.trade_name)
        if order_by:
            order_by_attribute = getattr(Account, order_by)
    except AttributeError as e:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail=f"Invalid 'order_by' field. Valid options are: \
                {list(Account.__fields__.keys())}",
        ) from e

    query = query.order_by(
        desc(order_by_attribute) if descending else order_by_attribute
    )

    return await paginate(db_session, query, params)  # type: ignore


async def store_web_socket_connection(
    connection_id: str, account: Account, db_session: AsyncSession | None = None
) -> None:
    db_session = db_session or get_session()

    connections_ids = set(account.websocket_connection_ids)
    connections_ids.add(connection_id)

    account.websocket_connection_ids = list(connections_ids)

    db_session.add(account)
    try:
        await db_session.commit()
    except Exception:
        await db_session.rollback()


async def delete_web_socket_connection(
    connection_id: str, account: Account, db_session: AsyncSession | None = None
) -> None:
    db_session = db_session or get_session()

    connection_ids = set(account.websocket_connection_ids)
    connection_ids.discard(connection_id)

    account.websocket_connection_ids = list(connection_ids)

    db_session.add(account)
    try:
        await db_session.commit()
    except Exception:
        await db_session.rollback()


async def get_web_socket_connections(
    account: Account, _db_session: AsyncSession | None = None
) -> set[str]:
    return set(account.websocket_connection_ids)
