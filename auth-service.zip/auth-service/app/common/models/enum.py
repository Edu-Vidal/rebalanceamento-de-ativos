from enum import Enum


class RoleType(str, Enum):
    SA = "sa"  # Admin ABLA
    ADMIN = "admin"  # Responsável pela locadora/conta
    USER = "user"  # Usuário da locadora


class ServiceType(str, Enum):
    BIOMETRIA = "BIOMETRIA"
    SGRLOC = "SGRLOC"
    CARBIGDATA = "CARBIGDATA"
    SIGN = "SIGN"
    CHECKLIST = "CHECKLIST"
    LICITA = "LICITA"
    LEGISLA = "LEGISLA"
    SINISTRO = "SINISTRO"
