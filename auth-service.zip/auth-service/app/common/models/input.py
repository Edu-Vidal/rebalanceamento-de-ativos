from pydantic import EmailStr, validator
from sqlmodel import Field, SQLModel

from app.common.models.enum import ServiceType
from app.utils.partial import optional
from app.utils.validators import is_cnpj_valid, is_cpf_valid


class AddressCreateInput(SQLModel):
    street: str
    number: str = Field(..., max_length=10)
    complement: str = Field(default="")
    neighborhood: str
    zip_code: str

    city_id: int | None
    state_id: int | None


@optional
class AddressUpdateInput(SQLModel):
    pass


class AccountCreateInput(SQLModel):
    trade_name: str = Field(..., index=True, description="Nome fantasia")
    corporate_name: str = Field(..., description="Razão social")
    cnpj: str
    responsible_name: str = Field(..., description="Nome do responsável")
    responsible_document: str = Field(..., description="CPF do responsável")
    responsible_phone: str = Field(..., description="Telefone do responsável")
    services: list[ServiceType]
    address: AddressCreateInput

    @validator("cnpj")
    def format_cnpj(cls, v: str):  # noqa N805
        if not v:
            return v
        if not is_cnpj_valid(v):
            raise ValueError("Invalid CNPJ")

        # Remove caracteres não numéricos
        v = "".join(filter(str.isdigit, v))
        # Formata CNPJ
        v = f"{v[:2]}.{v[2:5]}.{v[5:8]}/{v[8:12]}-{v[12:]}"

        return v

    @validator("responsible_document")
    def verify_document(cls, v: str, values: dict):  # noqa N805
        if not v:
            return v
        if not is_cpf_valid(v):
            raise ValueError("Invalid CPF")

        # Remove caracteres não numéricos
        v = "".join(filter(str.isdigit, v))
        # Formata CPF
        v = f"{v[:3]}.{v[3:6]}.{v[6:9]}-{v[9:]}"

        return v


class AccountUpdateInput(SQLModel):
    trade_name: str | None = None
    cnpj: str | None = None
    responsible_name: str | None = None
    responsible_document: str | None = None
    responsible_phone: str | None = None
    services: list[ServiceType] | None = None
    address: AddressUpdateInput | None = None

    @validator("cnpj", always=False)
    def format_cnpj(cls, v: str):  # noqa N805
        if not v:
            return v
        if not is_cnpj_valid(v):
            raise ValueError("Invalid CNPJ")

        # Remove caracteres não numéricos
        v = "".join(filter(str.isdigit, v))
        # Formata CNPJ
        v = f"{v[:2]}.{v[2:5]}.{v[5:8]}/{v[8:12]}-{v[12:]}"

        return v

    @validator("responsible_document", always=False)
    def verify_document(cls, v: str, values: dict):  # noqa N805
        if not v:
            return v
        if not is_cpf_valid(v):
            raise ValueError("Invalid CPF")

        # Remove caracteres não numéricos
        v = "".join(filter(str.isdigit, v))
        # Formata CPF
        v = f"{v[:3]}.{v[3:6]}.{v[6:9]}-{v[9:]}"

        return v


class UserCreateInput(SQLModel):
    account_id: str
    user_name: str = Field(regex=r"^[\w@.+/-]+$")
    name: str = "Placeholder"
    document: str
    phone: str
    email: EmailStr
    role_id: str = Field(..., max_length=2)
    acl: list[ServiceType] | None = Field(default=None)
    address: AddressCreateInput

    @validator("document")
    def verify_document(cls, v: str, values: dict):  # noqa N805
        if not v:
            return v
        if not is_cpf_valid(v):
            raise ValueError("Invalid CPF")

        # Remove caracteres não numéricos
        v = "".join(filter(str.isdigit, v))
        # Formata CPF
        v = f"{v[:3]}.{v[3:6]}.{v[6:9]}-{v[9:]}"

        return v


class UserUpdateInput(SQLModel):
    name: str | None = None
    document: str | None = None
    phone: str | None = None
    email: EmailStr | None = None
    role_id: str | None = Field(default=None, max_length=2)
    acl: list[ServiceType] | None = None
    address: AddressUpdateInput | None = None
    incomplete_registration: bool | None = None

    @validator("document")
    def verify_document(cls, v: str, values: dict):  # noqa N805
        if not v:
            return v
        if not is_cpf_valid(v):
            raise ValueError("Invalid CPF")

        # Remove caracteres não numéricos
        v = "".join(filter(str.isdigit, v))
        # Formata CPF
        v = f"{v[:3]}.{v[3:6]}.{v[6:9]}-{v[9:]}"

        return v


class ChangePasswordInput(SQLModel):
    old_password: str = Field(..., min_length=4, max_length=100)
    new_password: str = Field(..., min_length=4, max_length=100)


class TokenInput(SQLModel):
    token: str
