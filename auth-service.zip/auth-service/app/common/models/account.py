from datetime import datetime
from uuid import UUID

from pydantic import Extra, validator
from sqlmodel import JSON, Column, Field, SQLModel

from app.common.models.enum import ServiceType
from app.utils.partial import optional
from app.utils.validators import is_cnpj_valid, is_cpf_valid


class AccountBase(SQLModel):
    corporate_name: str
    trade_name: str = Field(..., index=True)
    cnpj: str = Field(..., index=True, sa_column_kwargs={"unique": True})
    responsible_name: str
    responsible_document: str
    responsible_phone: str
    active: bool = Field(default=True)
    deleted: bool = Field(default=False)
    services: list[ServiceType] = Field(default=[], sa_column=Column(JSON))
    websocket_connection_ids: list[str] = Field(default=[], sa_column=Column(JSON))
    incomplete_registration: bool = Field(default=False)

    address_id: int | None = Field(default=None, foreign_key="Address.address_id")

    @validator("cnpj")
    def format_cnpj(cls, v: str):  # noqa N805
        if not v:
            return v
        if not is_cnpj_valid(v):
            raise ValueError("Invalid CNPJ")

        # Remove caracteres não numéricos
        v = "".join(filter(str.isdigit, v))
        # Formata CNPJ
        v = f"{v[:2]}.{v[2:5]}.{v[5:8]}/{v[8:12]}-{v[12:]}"

        return v

    @validator("responsible_document")
    def verify_document(cls, v: str, values: dict):  # noqa N805
        if not v:
            return v
        if not is_cpf_valid(v):
            raise ValueError("Invalid CPF")

        # Remove caracteres não numéricos
        v = "".join(filter(str.isdigit, v))
        # Formata CPF
        v = f"{v[:3]}.{v[3:6]}.{v[6:9]}-{v[9:]}"

        return v

    class Config:
        extra = Extra.ignore
        validate_assignment = True
        orm_mode = True
        json_encoders = {
            datetime: lambda x: x.isoformat(),
        }


class AccountCreate(AccountBase):
    pass


@optional
class AccountUpdate(AccountBase):
    pass


class AccountRead(AccountBase):
    account_id: UUID
    websocket_connection_ids: list[str] = Field(
        default=[], sa_column=Column(JSON), exclude=True
    )
