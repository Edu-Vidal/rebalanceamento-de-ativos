from datetime import datetime

from pydantic import EmailStr, validator
from sqlmodel import JSON, Column, Field, SQLModel

from app.common.models.account import AccountRead
from app.common.models.enum import ServiceType
from app.common.models.role import RoleRead
from app.utils.partial import optional
from app.utils.uuid6 import UUID
from app.utils.validators import is_cpf_valid


class UserBase(SQLModel):
    user_name: str = Field(
        regex=r"^[\w@.+/-]+$",
        index=True,
        sa_column_kwargs={"unique": True},
        nullable=False,
    )
    email: EmailStr = Field(
        index=True, nullable=False, sa_column_kwargs={"unique": True}
    )
    name: str
    phone: str
    document: str = Field(
        default="",
        nullable=False,
        sa_column_kwargs={"unique": True},
    )
    active: bool = Field(default=True)
    deleted: bool = Field(default=False)
    acl: list[ServiceType] = Field(default=[], sa_column=Column(JSON))
    incomplete_registration: bool = Field(default=False)

    account_id: UUID | None = Field(default=None, foreign_key="Account.account_id")
    role_id: int | None = Field(default=None, foreign_key="Role.role_id")
    address_id: int | None = Field(default=None, foreign_key="Address.address_id")

    @validator("document")
    def verify_document(cls, v: str, values: dict):  # noqa N805
        if not v:
            return v
        if not is_cpf_valid(v):
            raise ValueError("Invalid CPF")

        # Remove caracteres não numéricos
        v = "".join(filter(str.isdigit, v))
        # Formata CPF
        v = f"{v[:3]}.{v[3:6]}.{v[6:9]}-{v[9:]}"

        return v

    class Config:
        extra = "ignore"
        validate_assignment = True
        orm_mode = True
        json_encoders = {
            datetime: lambda x: x.isoformat(),
        }


class UserCreate(UserBase):
    two_factor_authentication: bool = Field(default=False, const=True)
    backup_codes: list[str] = Field(default=[], const=True)
    totp_secret: str = Field(default="", const=True)

    password: str | None = Field(default=None)


@optional
class UserUpdate(UserBase):
    two_factor_authentication: bool | None
    backup_codes: list[str] | None
    totp_secret: str | None

    password: str | None


class UserRead(UserBase):
    user_id: UUID
    role: RoleRead | None = Field(default=None)
    account: AccountRead
    two_factor_authentication: bool
