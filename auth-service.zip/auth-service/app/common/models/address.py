from datetime import datetime

from pydantic import Extra
from sqlmodel import Field, SQLModel

from app.utils.partial import optional


class AddressBase(SQLModel):
    street: str = Field(..., nullable=False)
    number: str = Field(..., nullable=False, max_length=10)
    complement: str = Field(default="")
    neighborhood: str = Field(..., nullable=False)
    zip_code: str = Field(..., nullable=False)

    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(
        default_factory=datetime.utcnow, sa_column_kwargs={"onupdate": datetime.utcnow}
    )

    city_id: int | None = Field(default=None, foreign_key="City.id")
    state_id: int | None = Field(default=None, foreign_key="State.id")

    class Config:
        extra = Extra.ignore
        validate_assignment = True
        orm_mode = True
        json_encoders = {
            datetime: lambda x: x.isoformat(),
        }


class AddressCreate(AddressBase):
    pass


@optional
class AddressUpdate(AddressBase):
    pass
