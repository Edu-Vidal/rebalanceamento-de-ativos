from sqlmodel import SQLModel

from app.utils.partial import optional


class RoleBase(SQLModel):
    name: str
    description: str


class RoleCreate(RoleBase):
    pass


@optional
class RoleUpdate(RoleBase):
    pass


class RoleRead(RoleBase):
    role_id: int
