from datetime import datetime

from sqlalchemy.orm import declared_attr
from sqlmodel import JSON, Column, Field, Relationship, SQLModel

from app.common.models.account import AccountBase
from app.common.models.address import AddressBase
from app.common.models.role import RoleBase
from app.common.models.service import ServiceBase
from app.common.models.user import UserBase
from app.utils.uuid6 import UUID, uuid7


class Account(AccountBase, table=True):
    account_id: UUID = Field(default_factory=uuid7, primary_key=True, nullable=False)

    users: list["User"] = Relationship(
        back_populates="account", sa_relationship_kwargs={"lazy": "selectin"}
    )

    address: "Address" = Relationship(sa_relationship_kwargs={"lazy": "joined"})

    updated_at: datetime = Field(
        default_factory=datetime.utcnow, sa_column_kwargs={"onupdate": datetime.utcnow}
    )
    created_at: datetime = Field(default_factory=datetime.utcnow)

    @declared_attr
    def __tablename__(cls) -> str:  # noqa: N805
        return cls.__name__


class User(UserBase, table=True):
    user_id: UUID = Field(default_factory=uuid7, primary_key=True, nullable=False)

    password: str = Field(..., exclude=True, index=False)
    two_factor_authentication: bool = Field(default=False)
    backup_codes: list[str] = Field(
        ..., exclude=True, sa_column=Column(JSON), index=False
    )
    totp_secret: str = Field(default="", exclude=True)

    account: Account = Relationship(
        back_populates="users", sa_relationship_kwargs={"lazy": "joined"}
    )

    role: "Role" = Relationship(
        back_populates="users", sa_relationship_kwargs={"lazy": "joined"}
    )

    address: "Address" = Relationship(sa_relationship_kwargs={"lazy": "joined"})

    updated_at: datetime = Field(
        default_factory=datetime.utcnow, sa_column_kwargs={"onupdate": datetime.utcnow}
    )
    created_at: datetime = Field(default_factory=datetime.utcnow)

    @declared_attr
    def __tablename__(cls) -> str:  # noqa: N805
        return cls.__name__


class Role(RoleBase, table=True):
    role_id: int | None = Field(
        default=None, primary_key=True, index=True, nullable=False
    )

    users: list["User"] = Relationship(
        back_populates="role", sa_relationship_kwargs={"lazy": "selectin"}
    )

    @declared_attr
    def __tablename__(cls) -> str:  # noqa: N805
        return cls.__name__


class KeyStore(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True, index=True, nullable=False)
    public_key: str = Field(..., nullable=False)
    private_key: str = Field(..., index=False, nullable=False)
    created_at: datetime = Field(default_factory=datetime.utcnow)
    is_active: bool = Field(default=True)

    @declared_attr
    def __tablename__(cls) -> str:  # noqa: N805
        return cls.__name__


class Address(AddressBase, table=True):
    address_id: int | None = Field(
        default=None, primary_key=True, index=True, nullable=False
    )

    city: "City" = Relationship(sa_relationship_kwargs={"lazy": "joined"})
    state: "State" = Relationship(sa_relationship_kwargs={"lazy": "joined"})

    @declared_attr
    def __tablename__(cls) -> str:  # noqa: N805
        return cls.__name__


class State(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True, index=True, nullable=False)
    name: str = Field(..., nullable=False)
    acronym: str = Field(..., nullable=False)

    cities: list["City"] = Relationship(
        back_populates="state", sa_relationship_kwargs={"lazy": "selectin"}
    )

    @declared_attr
    def __tablename__(cls) -> str:  # noqa: N805
        return cls.__name__


class City(SQLModel, table=True):
    id: int | None = Field(default=None, primary_key=True, index=True, nullable=False)
    name: str = Field(..., nullable=False)
    state_id: int | None = Field(default=None, foreign_key="State.id")

    state: State = Relationship(back_populates="cities")

    @declared_attr
    def __tablename__(cls) -> str:  # noqa: N805
        return cls.__name__


class Service(ServiceBase, table=True):
    service_id: int | None = Field(
        default=None, primary_key=True, index=True, nullable=False
    )
    created_at: datetime = Field(default_factory=datetime.utcnow)
    updated_at: datetime = Field(
        default_factory=datetime.utcnow, sa_column_kwargs={"onupdate": datetime.utcnow}
    )

    @declared_attr
    def __tablename__(cls) -> str:  # noqa: N805
        return cls.__name__


if __name__ == "__main__":
    pass
