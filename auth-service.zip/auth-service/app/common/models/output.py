from sqlmodel import SQLModel

from app.common.models.user import UserRead


class Message(SQLModel):
    detail: str = ""


class TokenOutput(Message):
    access_token: str | None = None
    refresh_token: str | None = None
    token_type: str | None = None
    login_token: str | None = None


class OtpEnabledOutput(Message):
    totp_uri: str
    backup_codes: list[str]


class ResetBackupCodesOutput(Message):
    backup_codes: list[str]


class CreatedUserOutput(Message):
    first_access_password: str
    user: UserRead


class ResetPasswordOutput(Message):
    new_password: str
