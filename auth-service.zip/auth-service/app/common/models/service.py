from datetime import datetime

from sqlmodel import Field, SQLModel

from app.common.models.enum import ServiceType
from app.utils.partial import optional


class ServiceBase(SQLModel):
    name: ServiceType = Field(..., nullable=False)
    description: str = Field(..., nullable=False)
    active: bool = Field(default=True)

    class Config:
        extra = "ignore"
        validate_assignment = True
        orm_mode = True
        json_encoders = {
            datetime: lambda x: x.isoformat(),
        }


class ServiceCreate(ServiceBase):
    pass


@optional
class ServiceUpdate(ServiceBase):
    pass


class ServiceRead(ServiceBase):
    pass
