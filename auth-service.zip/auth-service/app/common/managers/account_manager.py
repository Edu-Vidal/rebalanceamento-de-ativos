import asyncio

import app.common.managers.consumers as consumers
from app.common.managers.consumers.interface import ConsumerInterface
from app.common.models.tables import Account
from app.utils.utils import logger


async def propagate_account_creation_to_services(
    account: Account,
    services: list[ConsumerInterface] = consumers.all_consumers,
) -> bool:
    creation_tasks = [service.create_account(account) for service in services]
    results = await asyncio.gather(*creation_tasks, return_exceptions=True)

    # Verificar se todas as criações foram bem-sucedidas
    if all(not isinstance(result, Exception) for result in results):
        return True

    # Se alguma criação falhou, preparar para desfazer as bem-sucedidas
    deletion_tasks = []
    for i, result in enumerate(results):
        service = services[i]
        if not isinstance(result, Exception):
            deletion_tasks.append(service.delete_account(account))
        else:
            logger.error(
                f"Erro ao criar conta {account.trade_name} em \
                    {service.service_type.value}. Erro: {result}"
            )

    # Executar as deleções em paralelo
    await asyncio.gather(*deletion_tasks, return_exceptions=True)
    return False


async def propagate_account_update_to_services(
    account_updated: Account,
    account: Account,
    services: list[ConsumerInterface] = consumers.all_consumers,
) -> bool:
    update_tasks = [
        service.update_account(account_updated, account) for service in services
    ]
    results = await asyncio.gather(*update_tasks, return_exceptions=True)

    # Verifica se todas as atualizações foram bem-sucedidas
    if all(not isinstance(result, Exception) for result in results):
        return True

    # Preparar para reverter as atualizações bem-sucedidas
    revert_tasks = []
    for i, result in enumerate(results):
        service = services[i]
        if not isinstance(result, Exception):
            revert_tasks.append(service.update_account(account, account_updated))
        else:
            logger.error(
                f"Erro ao atualizar conta {account.trade_name} em \
                    {service.service_type.value}. Erro: {result}"
            )

    # Executar as reversões em paralelo
    await asyncio.gather(*revert_tasks, return_exceptions=True)
    return False


async def propagate_account_deletion_to_services(
    account: Account, services: list[ConsumerInterface] = consumers.all_consumers
) -> bool:
    # Processa a deleção de conta em cada serviço sequencialmente
    for service in services:
        try:
            await service.delete_account(account)
        except Exception as e:
            logger.error(
                f"Erro ao deletar conta {account.trade_name} em serviço \
                    {service.service_type.value}. Erro: {e}"
            )
            return False

    return True
