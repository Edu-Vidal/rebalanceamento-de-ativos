import asyncio

from fastapi import HTTPException, status

from app.common.crud import account_crud, user_crud
from app.common.managers import consumers
from app.common.managers.auth import PasswordAuth, TotpAuth
from app.common.managers.consumers.interface import ConsumerInterface
from app.common.models.tables import User
from app.common.models.user import UserUpdate
from app.utils.utils import logger


async def login(user: User, password: str) -> bool:
    if not user.active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="usuario {user.name} desativado",
        )

    return await PasswordAuth.authenticate(user, password)


async def change_password(user: User, new_password: str) -> None:
    password = PasswordAuth.hash_password(new_password)

    user_update = UserUpdate(password=password)

    await user_crud.update_user(user, user_update)


async def reset_password(user: User) -> str:
    new_password = PasswordAuth.gen_random_string()
    password = PasswordAuth.hash_password(new_password)

    user_update = UserUpdate(password=password)

    await user_crud.update_user(user, user_update)

    return new_password


def authenticate_otp(user: User, otp: str) -> bool:
    if not user.active:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="usuario {user.name} desativado",
        )
    if not user.two_factor_authentication:
        raise HTTPException(
            status_code=status.HTTP_403_FORBIDDEN, detail="TOTP não configurado"
        )

    return TotpAuth.authenticate(user, otp)


async def setup_mfa(user: User) -> tuple[str, list]:
    # Gera informações para dupla autenticação
    # Não ativa funcionalidade enquanto não houver confirmação
    if user.two_factor_authentication:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="TOTP já configurado"
        )

    totp_secret = TotpAuth.generate_secret()
    totp_uri = TotpAuth.generate_totp_uri(user.user_name, totp_secret)

    backup_codes = TotpAuth.generate_backup_codes()

    user_update = UserUpdate.from_orm(
        user, update={"totp_secret": totp_secret, "backup_codes": backup_codes}
    )

    await user_crud.update_user(user, user_update)

    return totp_uri, backup_codes


async def confirm_mfa_setup(user: User, totp: str) -> None:
    if not TotpAuth.authenticate(user, totp):
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="Token inválido"
        )

    user_update = UserUpdate.from_orm(user, update={"two_factor_authentication": True})

    await user_crud.update_user(user, user_update)


async def disable_mfa(user: User) -> None:
    user_update = UserUpdate.from_orm(
        user,
        update={
            "two_factor_authentication": False,
            "totp_secret": "",
            "backup_codes": [],
        },
    )

    await user_crud.update_user(user, user_update)


async def use_backup_code(user: User, backup_code: str) -> None:
    if backup_code not in user.backup_codes:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Código de backup inválido",
        )
    # Remove código de lista de backup_codes
    backup_codes = user.backup_codes
    backup_codes.remove(backup_code)

    user_update = UserUpdate(backup_codes=backup_codes)

    await user_crud.update_user(user, user_update)


async def reset_backup_codes(user: User) -> list:
    backup_codes = TotpAuth.generate_backup_codes()

    user_update = UserUpdate.from_orm(user, update={"backup_codes": backup_codes})

    await user_crud.update_user(user, user_update)

    return user.backup_codes


async def deactivate(user: User) -> None:
    user_update = UserUpdate.from_orm(user, update={"active": False})

    await user_crud.update_user(user, user_update)


async def activate(user: User) -> None:
    # Verifica se Conta está ativa
    account = await account_crud.get_account_by_id(user.account.account_id)
    if not account or not account.active:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST,
            detail="Não foi possível ativar o usuario {user.name}, conta inativa. \
                Ative a conta primeiro.",
        )

    user_update = UserUpdate.from_orm(user, update={"active": True})
    await user_crud.update_user(user, user_update)


async def delete(user: User) -> None:
    user_update = UserUpdate.from_orm(user, update={"deleted": True})

    await user_crud.update_user(user, user_update)


async def propagate_user_creation_to_services(
    user: User,
    services: list[ConsumerInterface] = consumers.all_consumers,
) -> bool:
    creation_tasks = [service.create_user(user) for service in services]
    results = await asyncio.gather(*creation_tasks, return_exceptions=True)

    # Verificar se todas as criações foram bem-sucedidas
    if all(not isinstance(result, Exception) for result in results):
        return True

    # Se alguma criação falhou, preparar para desfazer as bem-sucedidas
    deletion_tasks = []
    for i, result in enumerate(results):
        service = services[i]
        if not isinstance(result, Exception):
            deletion_tasks.append(service.delete_user(user))
        else:
            logger.error(
                f"Erro ao criar usuario {user.name} em {service.service_type.value}. \
                    Erro: {result}"
            )

    # Executar as deleções em paralelo
    await asyncio.gather(*deletion_tasks, return_exceptions=True)
    return False


async def propagate_user_update_to_services(
    user_updated: User,
    user: User,
    services: list[ConsumerInterface] = consumers.all_consumers,
) -> bool:
    update_tasks = [service.update_user(user_updated, user) for service in services]
    results = await asyncio.gather(*update_tasks, return_exceptions=True)

    # Verifica se todas as atualizações foram bem-sucedidas
    if all(not isinstance(result, Exception) for result in results):
        return True

    # Preparar para reverter as atualizações bem-sucedidas
    revert_tasks = []
    for i, result in enumerate(results):
        service = services[i]
        if not isinstance(result, Exception):
            revert_tasks.append(service.update_user(user, user_updated))
        else:
            logger.error(
                f"Erro ao atualizar usuario {user.name} em \
                    {service.service_type.value}. Erro: {result}"
            )

    # Executar as reversões em paralelo
    await asyncio.gather(*revert_tasks, return_exceptions=True)
    return False


async def propagate_user_deletion_to_services(
    user: User,
    services: list[ConsumerInterface] = consumers.all_consumers,
) -> bool:
    for service in services:
        try:
            await service.delete_user(user)
        except Exception as e:
            logger.error(
                f"Erro ao deletar usuario {user.name} em servico \
                    {service.service_type.value}. Erro: {e}"
            )
            return False

    return True
