import json
import os
from enum import Enum
from uuid import UUID

import boto3
from mypy_boto3_lambda import LambdaClient
from sqlmodel import SQLModel

from app.utils.json_encoder import BaseModelEncoder

FUNCTION_NAME = os.environ["WS_BROADCAST_FUNCTION_NAME"]

client: LambdaClient = boto3.client(
    "lambda",
    region_name=os.getenv("AWS_REGION", "sa-east-1"),
)


class WebsocketMessageActionType(str, Enum):
    USER_CREATED = "user_created"
    USER_UPDATED = "user_updated"
    USER_DELETED = "user_deleted"
    USER_LOGGED_IN = "user_logged_in"
    USER_LOGGED_OUT = "user_logged_out"
    USER_PASSWORD_RESET_REQUESTED = "user_password_reset_requested"

    ACCOUNT_CREATED = "account_created"
    ACCOUNT_UPDATED = "account_updated"
    ACCOUNT_DELETED = "account_deleted"


class WebsocketMessage(SQLModel):
    action: WebsocketMessageActionType
    data: dict

    def serialize(self, **update) -> str:
        message = self.dict()
        message.update(update)
        return json.dumps(message, cls=BaseModelEncoder)


def send_ws_message(
    message: WebsocketMessage,
    account_id: UUID,
    api_stage: str = os.getenv("STAGE", "dev"),
    client: LambdaClient = client,
) -> None:
    client.invoke(
        FunctionName=FUNCTION_NAME,
        InvocationType="Event",
        Payload=message.serialize(account_id=account_id, api_stage=api_stage),
    )
