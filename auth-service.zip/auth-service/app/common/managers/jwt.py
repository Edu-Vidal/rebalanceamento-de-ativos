from datetime import datetime, timedelta
from typing import Any
from uuid import UUID

from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization
from cryptography.hazmat.primitives.asymmetric import rsa
from fastapi import HTTPException, status
from jose import ExpiredSignatureError, JWTError, jwk, jwt
from pydantic import BaseModel

import app.common.crud.key_store_crud as db
from app.common.models.enum import ServiceType
from app.common.models.tables import KeyStore

JWT_ALGORITHM = "RS256"
JWT_ACCESS_TOKEN_EXPIRE_MINUTES = timedelta(minutes=60)

JWT_REFRESH_TOKEN_EXPIRE_DAYS = timedelta(days=7)

JWT_LOGIN_TOKEN_EXPIRE_MINUTES = timedelta(minutes=2)


class TokenClaims(BaseModel):
    sub: str
    account: str
    account_id: str
    user_id: str
    role: str
    services: list[ServiceType] = []
    acl: list[str] = []


async def sign_jwt(payload: dict) -> str:
    keys = await db.get_keys(is_active=True)

    if not keys:
        private_key, public_key = generate_keys()
        key_item = KeyStore(
            public_key=public_key,
            private_key=private_key,
        )
        keys = [await db.create_key(key_item)]

    try:
        jwt_str = jwt.encode(
            claims=payload, key=keys[0].private_key, algorithm=JWT_ALGORITHM
        )

        return jwt_str
    except JWTError as err:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao gerar token JWT",
        ) from err


async def decode_jwt(token: str, keys: list[KeyStore] | None = None) -> dict[str, Any]:
    keys = keys or await db.get_keys()
    if not keys:
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Não há chaves cadastradas.",
        )

    for key in keys:
        try:
            return jwt.decode(
                token=token, key=key.public_key, algorithms=[JWT_ALGORITHM]
            )
        except ExpiredSignatureError as err:
            raise HTTPException(
                status_code=status.HTTP_403_FORBIDDEN,
                detail="Assinatura expirou. Faça login novamente",
            ) from err
        except JWTError:
            continue

    # Se não conseguiu decodificar com nenhuma chave, token é inválido
    raise HTTPException(status_code=status.HTTP_403_FORBIDDEN, detail="Token inválido")


async def create_access_token(token_claims: TokenClaims) -> str:
    payload = {
        **{
            "exp": datetime.utcnow() + JWT_ACCESS_TOKEN_EXPIRE_MINUTES,
            "iat": datetime.utcnow(),
        },
        **token_claims.dict(),
    }

    return await sign_jwt(payload)


async def create_refresh_token(token_claims: TokenClaims) -> str:
    payload = {
        **{
            "exp": datetime.utcnow() + JWT_ACCESS_TOKEN_EXPIRE_MINUTES,
            "iat": datetime.utcnow(),
        },
        **token_claims.dict(),
    }

    return await sign_jwt(
        payload,
    )


async def decode_refresh_token(token: str) -> dict[str, Any]:
    return await decode_jwt(token)


async def create_login_token(user_id: UUID) -> str:
    payload = {
        "exp": datetime.utcnow() + JWT_LOGIN_TOKEN_EXPIRE_MINUTES,
        "iat": datetime.utcnow(),
        "sub": str(user_id),
    }

    return await sign_jwt(payload)


async def decode_login_token(token: str) -> dict[str, Any]:
    return await decode_jwt(token)


def generate_keys() -> tuple[str, str]:
    # Gerar o par de chaves
    private_key = rsa.generate_private_key(
        backend=default_backend(), public_exponent=65537, key_size=2048
    )
    public_key = private_key.public_key()

    # Serializar as chaves
    private_pem = private_key.private_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PrivateFormat.PKCS8,
        encryption_algorithm=serialization.NoEncryption(),
    ).decode("utf-8")
    public_pem = public_key.public_bytes(
        encoding=serialization.Encoding.PEM,
        format=serialization.PublicFormat.SubjectPublicKeyInfo,
    ).decode("utf-8")

    return private_pem, public_pem


async def get_jwks() -> dict[str, Any]:
    results = await db.get_keys()

    keys = [
        jwk.construct(result.public_key, algorithm=JWT_ALGORITHM).to_dict()
        for result in results
    ]

    return {"keys": keys}
