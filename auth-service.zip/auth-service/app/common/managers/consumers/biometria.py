import os
from uuid import UUID

from httpx import AsyncClient, Timeout
from sqlmodel import SQLModel

from app.common.managers.consumers.interface import ConsumerInterface
from app.common.models.enum import ServiceType
from app.utils.partial import optional
from app.utils.utils import logger

API_URL = os.environ["BIOMETRIA_API_URL"]
API_KEY = os.environ["AUTH_API_KEY"]


class BiometriaAccount(SQLModel):
    account_name: str
    cnpj: str


class BiometriaAccountCreate(BiometriaAccount):
    account_id: UUID

    @property
    def payload(self) -> dict:
        return {
            "account_name": self.account_name,
            "cnpj": self.cnpj,
            "account_id": str(self.account_id),
        }


@optional
class BiometriaAccountUpdate(BiometriaAccount):
    pass


class BiometriaUser(SQLModel):
    user_name: str
    email: str


class BiometriaUserCreate(BiometriaUser):
    user_id: UUID
    account_id: UUID

    @property
    def payload(self) -> dict:
        return {
            "user_id": str(self.user_id),
            "account_id": str(self.account_id),
            "user_name": self.user_name,
            "email": self.email,
        }


@optional
class BiometriaUserUpdate(BiometriaUser):
    pass


class BiometriaConsumer(ConsumerInterface):
    service_type = ServiceType.BIOMETRIA

    async def create_account(self, account) -> None:
        account_create = BiometriaAccountCreate(
            account_id=account.account_id,
            account_name=account.trade_name,
            cnpj=account.cnpj,
        )

        async with AsyncClient(timeout=Timeout(None)) as client:
            response = await client.post(
                url=f"{API_URL}/v1/accounts/",
                json=account_create.payload,
                headers={"x-api-key": API_KEY},
            )

            logger.info(f"{self.service_type} account created: {response.json()}")

    async def update_account(self, account_update, account):
        account_update = BiometriaAccountUpdate(
            account_name=account_update.trade_name,
            cnpj=account_update.cnpj,
        )
        payload = account_update.dict()
        async with AsyncClient(timeout=Timeout(None)) as client:
            response = await client.put(
                url=f"{API_URL}/v1/accounts/{account.account_id}",
                json=payload,
                headers={"x-api-key": API_KEY},
            )

            response.raise_for_status()
            logger.info(f"{self.service_type} account updated: {response.json()}")

    async def delete_account(self, account):
        async with AsyncClient(timeout=Timeout(None)) as client:
            response = await client.delete(
                url=f"{API_URL}/v1/accounts/{account.account_id}",
                headers={"x-api-key": API_KEY},
            )

            logger.info(f"{self.service_type} account deleted: {response.json()}")

    async def create_user(self, user):
        user_create = BiometriaUserCreate(
            user_id=user.user_id,
            account_id=user.account_id if user.account_id else user.account.account_id,
            user_name=user.user_name,
            email=user.email,
        )

        async with AsyncClient(timeout=Timeout(None)) as client:
            response = await client.post(
                url=f"{API_URL}/v1/users/",
                json=user_create.payload,
                headers={"x-api-key": API_KEY},
            )

            logger.info(f"{self.service_type} user created: {response.json()}")

    async def update_user(self, user_update, user):
        user_update = BiometriaUserUpdate(
            user_name=user_update.user_name,
            email=user_update.email,
        )
        payload = user_update.dict()
        async with AsyncClient(timeout=Timeout(None)) as client:
            response = await client.put(
                url=f"{API_URL}/v1/users/{user.user_id}",
                json=payload,
                headers={"x-api-key": API_KEY},
            )

            response.raise_for_status()
            logger.info(f"{self.service_type} user updated: {response.json()}")

    async def delete_user(self, user):
        async with AsyncClient(timeout=Timeout(None)) as client:
            response = await client.delete(
                url=f"{API_URL}/v1/users/{user.user_id}",
                headers={"x-api-key": API_KEY},
            )

            logger.info(f"{self.service_type} user deleted: {response.json()}")
