# Importa todos os consumers com exceção da interface
from app.common.managers.consumers.biometria import BiometriaConsumer
from app.common.managers.consumers.carbigdata import CarBigDataConsumer
from app.common.managers.consumers.checklist import ChecklistConsumer
from app.common.managers.consumers.interface import ConsumerInterface
from app.common.managers.consumers.legisla import LegislaConsumer
from app.common.managers.consumers.licita import LicitaConsumer
from app.common.managers.consumers.sgrloc import SGRLocConsumer
from app.common.managers.consumers.sign import SignConsumer

all_consumers: list[ConsumerInterface] = [
    ChecklistConsumer(),
    BiometriaConsumer(),
    CarBigDataConsumer(),
    # LegislaConsumer(),
    # LicitaConsumer(),
    # SignConsumer(),
    SGRLocConsumer(),
]
