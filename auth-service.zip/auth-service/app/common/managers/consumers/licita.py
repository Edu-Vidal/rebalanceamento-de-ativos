import os

from app.common.managers.consumers.interface import ConsumerInterface
from app.common.models.enum import ServiceType

# API_URL = os.environ["LICITA_API_URL"]
# API_KEY = os.environ["AUTH_API_KEY"]


class LicitaConsumer(ConsumerInterface):
    service_type = ServiceType.LICITA

    async def create_account(self, account) -> None:
        return

    async def update_account(self, account_update, account) -> None:
        return

    async def delete_account(self, account) -> None:
        return

    async def create_user(self, user) -> None:
        return

    async def update_user(self, user_update, user) -> None:
        return

    async def delete_user(self, user) -> None:
        return
