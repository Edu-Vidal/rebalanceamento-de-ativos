from app.common.managers.consumers.interface import ConsumerInterface
from app.common.models.enum import ServiceType


class SignConsumer(ConsumerInterface):
    service_type = ServiceType.SIGN

    async def create_account(self, account) -> None:
        return

    async def update_account(self, account_update, account) -> None:
        return

    async def delete_account(self, account) -> None:
        return

    async def create_user(self, user) -> None:
        return

    async def update_user(self, user_update, user) -> None:
        return

    async def delete_user(self, user) -> None:
        return
