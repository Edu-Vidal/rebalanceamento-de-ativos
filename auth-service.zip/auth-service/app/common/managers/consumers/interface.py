from abc import ABC, abstractmethod

from app.common.models.enum import ServiceType
from app.common.models.tables import Account, User


class ConsumerInterface(ABC):
    service_type: ServiceType

    @abstractmethod
    async def create_account(self, account: Account) -> None:
        return

    @abstractmethod
    async def update_account(self, account_update: Account, account: Account) -> None:
        return

    @abstractmethod
    async def delete_account(self, account: Account) -> None:
        return

    @abstractmethod
    async def create_user(self, user: User) -> None:
        return

    @abstractmethod
    async def update_user(self, user_update: User, user: User) -> None:
        return

    @abstractmethod
    async def delete_user(self, user: User) -> None:
        return
