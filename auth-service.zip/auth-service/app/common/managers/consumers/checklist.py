import os

from httpx import AsyncClient, Timeout
from sqlmodel import SQLModel

from app.common.managers.consumers.interface import ConsumerInterface
from app.common.models.enum import RoleType, ServiceType
from app.migrations.import_.checklist.db import get_companies, get_users
from app.migrations.import_.import_ import gera_cpf
from app.utils.partial import optional
from app.utils.utils import logger

API_URL = os.environ["CHECKLIST_API_URL"]
CHECKLIST_USER = os.environ["CHECKLIST_USER"]
CHECKLIST_PASSWORD = os.environ["CHECKLIST_PASSWORD"]

ROLE = {
    RoleType.USER: "COLABORADOR",
    RoleType.ADMIN: "GESTOR",
    RoleType.SA: "SUPER_ADMIN",
}


class ChecklistAccount(SQLModel):
    corporate_name: str
    fantasy_name: str
    cnpj: str
    responsible_name: str
    responsible_document: str
    responsible_phone: str
    street: str
    number: str
    complement: str
    neighborhood: str
    zipcode: str
    city: int
    state: int


class ChecklistAccountCreate(ChecklistAccount):
    @property
    def payload(self) -> dict:
        return {
            "corporate_name": str(self.corporate_name),
            "fantasy_name": str(self.fantasy_name),
            "cnpj": str(self.cnpj),
            "responsible_name": str(self.responsible_name),
            "responsible_document": str(self.responsible_document),
            "responsible_phone": str(self.responsible_phone),
            "address": {
                "street": str(self.street),
                "number": str(self.number),
                "complement": str(self.complement),
                "neighborhood": str(self.neighborhood),
                "zipcode": str(self.zipcode),
                "city": self.city,
                "state": self.state,
            },
        }


@optional
class ChecklistAccountUpdate(ChecklistAccount):
    @property
    def payload(self) -> dict:
        return {
            "corporate_name": str(self.corporate_name),
            "fantasy_name": str(self.fantasy_name),
            "cnpj": str(self.cnpj),
            "responsible_name": str(self.responsible_name),
            "responsible_document": str(self.responsible_document),
            "responsible_phone": str(self.responsible_phone),
            "address": {
                "street": str(self.street),
                "number": str(self.number),
                "complement": str(self.complement),
                "neighborhood": str(self.neighborhood),
                "zipcode": str(self.zipcode),
                "city": self.city,
                "state": self.state,
            },
        }


class ChecklistUser(SQLModel):
    name: str
    document: str
    phone: str
    email: str
    street: str
    number: str
    complement: str
    neighborhood: str
    zipcode: str
    state: int
    city: int
    rental_company: int
    role: str


class ChecklistUserCreate(ChecklistUser):
    username: str
    password: str

    @property
    def payload(self) -> dict:
        return {
            "name": self.name,
            "document": self.document,
            "phone": self.phone,
            "email": self.email,
            "address": {
                "street": self.street,
                "number": self.number,
                "complement": self.complement,
                "neighborhood": self.neighborhood,
                "zipcode": self.zipcode,
                "state": self.state,
                "city": self.city,
            },
            "user_app": {"username": self.username, "password": self.password},
            "rental_company": self.rental_company,
            "role": self.role,
        }


@optional
class ChecklistUserUpdate(ChecklistUser):
    @property
    def payload(self) -> dict:
        return {
            "name": self.name,
            "document": self.document,
            "phone": self.phone,
            "email": self.email,
            "address": {
                "street": self.street,
                "number": self.number,
                "complement": self.complement,
                "neighborhood": self.neighborhood,
                "zipcode": self.zipcode,
                "state": self.state,
                "city": self.city,
            },
            "rental_company": self.rental_company,
            "role": self.role,
        }


class ChecklistConsumer(ConsumerInterface):
    service_type = ServiceType.CHECKLIST
    access_token = ""

    async def create_account(self, account) -> None:
        token = await self._login()

        checklist_accounts = await get_companies()

        for acc in checklist_accounts:
            if acc["fantasy_name"] == account.trade_name:
                logger.info(
                    f"{account.trade_name} já existe no banco de Accounts do Checklist."
                )
                return
        logger.info(
            f"{account.trade_name} não existe no banco de Accounts do Checklist. \
                Propagando..."
        )

        account_create = ChecklistAccountCreate(
            corporate_name=account.corporate_name,
            fantasy_name=account.trade_name,
            cnpj=account.cnpj,
            responsible_name=account.responsible_name,
            responsible_document=account.responsible_document
            or gera_cpf(punctuation=True),
            responsible_phone=account.responsible_phone,
            street=account.address.street,
            number=account.address.number or "123",
            complement=account.address.complement,
            neighborhood=account.address.neighborhood,
            zipcode=account.address.zip_code,
            city=account.address.city_id or 4964,
            state=account.address.state_id or 25,
        )

        async with AsyncClient(timeout=Timeout(None)) as client:
            response = await client.post(
                url=f"{API_URL}/rental_companies/",
                json=account_create.payload,
                headers={
                    "Authorization": f"Bearer {token}",
                },
            )
            response.raise_for_status()
            logger.info(f"{self.service_type} account created: {response.json()}")

    async def update_account(self, account_update, account) -> None:
        # CHECKLIST NÃO TEM UPDATE DE CONTA
        return

    async def delete_account(self, account) -> None:
        token = await self._login()

        checklist_accounts = await get_companies()

        checklist_account_id = None
        trade_name = account.trade_name
        for acc in checklist_accounts:
            if acc["fantasy_name"] == trade_name:
                checklist_account_id = acc["id"]
                break

        if not checklist_account_id:
            logger.info(
                f"{account.trade_name} não existe no banco de Accounts do Checklist. \
                    Propagando..."
            )

        async with AsyncClient(timeout=Timeout(None)) as client:
            response = await client.delete(
                url=f"{API_URL}/rental_companies/{checklist_account_id}",
                headers={"authorization": f"Bearer {token}"},
                follow_redirects=True,
            )

            response.raise_for_status()
            logger.info(f"{self.service_type} account deleted: {response.json()}")

    async def create_user(self, user) -> None:
        token = await self._login()

        checklist_users = await get_users()

        valid_email = True

        for cl_user in checklist_users:
            if (
                cl_user["username"] == user.user_name
                or (
                    user.document != "828.207.860-30"
                    and cl_user["document"] == user.document
                )
                or (cl_user["email"] == user.email and cl_user["name"] == user.name)
            ):
                logger.info(f"{user.name} já existe no banco de Users do Checklist.")
                return

            if cl_user["email"] == user.email:
                valid_email = False

        logger.info(
            f"{user.name} não existe no banco de Users do Checklist. Propagando..."
        )

        valid_doc = (
            user.document
            if user.document != "828.207.860-30"
            else gera_cpf(punctuation=True)
        )

        checklist_accounts = await get_companies()

        checklist_account_id = None
        trade_name = user.account.trade_name
        for account in checklist_accounts:
            if account["fantasy_name"] == trade_name:
                checklist_account_id = account["id"]
                break

        if not checklist_account_id:
            raise Exception("Conta não encontrada no Checklist")

        user_create = ChecklistUserCreate(
            name=user.name,
            document=valid_doc,
            phone=user.phone,
            email=user.email if valid_email else str(valid_doc) + "_" + str(user.email),
            street=user.address.street,
            number="123",
            complement=user.address.complement,
            neighborhood=user.address.neighborhood,
            zipcode=user.address.zip_code,
            state=25,
            city=4964,
            username=user.user_name,
            password="Placeholder",
            rental_company=checklist_account_id,
            role=ROLE[RoleType(user.role.name)],
        )

        async with AsyncClient(timeout=Timeout(None)) as client:
            response = await client.post(
                url=f"{API_URL}/user/",
                json=user_create.payload,
                headers={"authorization": f"Bearer {token}"},
            )

            response.raise_for_status()
            logger.info(f"{self.service_type} user created: {response.json()}")

    async def update_user(self, user_update, user) -> None:
        token = await self._login()

        checklist_accounts = await get_companies()

        checklist_account_id = None
        trade_name = user.account.trade_name
        for account in checklist_accounts:
            if account["fantasy_name"] == trade_name:
                checklist_account_id = account["id"]
                break
        if not checklist_account_id:
            raise Exception("Conta não encontrada no Checklist")

        checklist_users = await get_users()

        checklist_user_id = None
        username = user_update.user_name
        for cl_user in checklist_users:
            if cl_user["username"] == username:
                checklist_user_id = cl_user["id"]
                break
        if not checklist_user_id:
            raise Exception("Usuário não encontrado no Checklist")

        user_update_obj = ChecklistUserUpdate(
            name=user_update.name,
            document=user_update.document,
            phone=user_update.phone,
            email=user_update.email,
            street=user_update.address.street,
            number=user_update.address.number,
            complement=user_update.address.complement,
            neighborhood=user_update.address.neighborhood,
            zipcode=user_update.address.zip_code,
            state=user_update.address.state_id,
            city=user_update.address.city_id,
            rental_company=checklist_account_id,
            role=ROLE[RoleType(user.role.name)],
        )

        async with AsyncClient(timeout=Timeout(None)) as client:
            response = await client.put(
                url=f"{API_URL}/user/{checklist_user_id}/",
                json=user_update_obj.payload,
                headers={"authorization": f"Bearer {token}"},
                follow_redirects=True,
            )

            response.raise_for_status()
            logger.info(f"{self.service_type} user updated: {response.json()}")

    async def delete_user(self, user) -> None:
        token = await self._login()

        checklist_users = await get_users()

        checklist_user_id = None
        for cl_user in checklist_users:
            if cl_user["document"] == user.document:
                checklist_user_id = cl_user["id"]
                break
        if not checklist_user_id:
            raise Exception("Usuário não encontrado no Checklist")

        async with AsyncClient(timeout=Timeout(None)) as client:
            response = await client.delete(
                url=f"{API_URL}/user/{checklist_user_id}",
                headers={"authorization": f"Bearer {token}"},
                follow_redirects=True,
            )

            response.raise_for_status()
            logger.info(f"{self.service_type} user deleted: {response.json()}")

    async def _login(self) -> str:
        if self.access_token != "":
            return self.access_token

        async with AsyncClient(timeout=Timeout(None)) as client:
            payload = {
                "username": CHECKLIST_USER,
                "password": CHECKLIST_PASSWORD,
            }
            response = await client.post(
                url=f"{API_URL}/token/",
                json=payload,
            )
            self.access_token = response.json()["access"]

            return self.access_token
