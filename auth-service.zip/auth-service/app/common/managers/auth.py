import hashlib
import secrets
import string
from hmac import compare_digest

import pyotp
from passlib.hash import django_pbkdf2_sha256

from app.common.crud import user_crud
from app.common.models.tables import User
from app.common.models.user import UserUpdate

pwd_context: django_pbkdf2_sha256 = django_pbkdf2_sha256.using(rounds=260000)


class PasswordAuth:
    @classmethod
    async def authenticate(cls, user: User, password: str) -> bool:
        _, iterations, salt, hash_pass = user.password.split("$")
        # ------- Integração com senha de 32 bytes -------
        # Senhas com salt de 32 bytes possuem apenas uma iteração
        if iterations == "1":
            if not compare_digest(
                hashlib.pbkdf2_hmac(
                    "SHA256",
                    password.encode("utf-8"),
                    bytes.fromhex(salt),
                    int(iterations),
                ).hex(),
                hash_pass,
            ):
                return False

            new_hash = pwd_context.hash(password)
            user.password = new_hash

            user_update = UserUpdate(password=new_hash)
            await user_crud.update_user(user, user_update)
            return True

        # ------- Integração com senha de 16 bytes -------
        if not pwd_context.verify(password, user.password):
            return False

        return True

    @classmethod
    def hash_password(cls, password: str) -> str:
        return pwd_context.hash(password)

    @staticmethod
    def gen_random_string(length: int = 8) -> str:
        # Responsável por gerar uma string aleatória
        # com letras(maiúsculas, minúsculas) e números
        characters = string.ascii_letters + string.digits

        # Retorna uma string aleatória com o tamanho
        # especificado em length, utilze os.urandom

        return "".join(secrets.choice(characters) for _ in range(length))


class TotpAuth:
    backup_code_quantity = 6

    @staticmethod
    def authenticate(user: User, token: str) -> bool:
        # if token not in user.usedTotp:
        #     # Verifica se token já foi utilizado nos últimos 30s

        return pyotp.TOTP(str(user.totp_secret)).verify(token)

    @staticmethod
    def generate_totp_uri(username: str, secret: str) -> str:
        totp = pyotp.TOTP(secret)
        otp_uri = totp.provisioning_uri(name=username, issuer_name="ABLA biometria")
        return otp_uri

    @classmethod
    def generate_backup_codes(cls) -> list:
        # Create random 6 digit codes list using letters and numbers
        backup_codes = []
        for _ in range(cls.backup_code_quantity):
            backup_codes.append(
                "".join(
                    [
                        secrets.choice(string.ascii_letters + string.digits)
                        for _ in range(6)
                    ]
                )
            )

        return backup_codes

    @staticmethod
    def generate_secret() -> str:
        return pyotp.random_base32()
