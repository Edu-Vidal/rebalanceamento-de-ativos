# HANDLER PARA AUTORIZAÇÃO EM API GATEWAY
# ATUALMENTE NÃO UTILIZADO
from aws_lambda_powertools.utilities.data_classes import event_source
from aws_lambda_powertools.utilities.data_classes.api_gateway_authorizer_event import (
    DENY_ALL_RESPONSE,
    APIGatewayAuthorizerRequestEvent,
    APIGatewayAuthorizerResponse,
)
from fastapi import HTTPException

from app.common.managers.jwt import JWT_ACCESS_TOKEN_SECRET, decode_jwt


@event_source(data_class=APIGatewayAuthorizerRequestEvent)
def lambda_handler(event: APIGatewayAuthorizerRequestEvent, _context):
    token = event.query_string_parameters.get("Authorization")
    if not token:
        return DENY_ALL_RESPONSE

    try:
        payload = decode_jwt(token, JWT_ACCESS_TOKEN_SECRET)
    except HTTPException:
        return DENY_ALL_RESPONSE

    arn = event.parsed_arn

    policy = APIGatewayAuthorizerResponse(
        principal_id=payload["user_id"],
        context={
            "account_id": payload["account_id"],
            "user_id": payload["sub"],
        },
        region=arn.region,
        aws_account_id=arn.aws_account_id,
        api_id=arn.api_id,
        stage=arn.stage,
    )

    policy.allow_all_routes()
    return policy.asdict()
