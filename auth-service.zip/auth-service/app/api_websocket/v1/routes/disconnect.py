import json


def disconnect(event, context):
    # connection_id = event["requestContext"]["connectionId"] # noqa

    # TODO: Remover connection id de conta sem saber de qual conta é
    # db.delete_web_socket_connection(connection_id) # noqa

    return {
        "statusCode": 200,
        "body": json.dumps("Disconnected"),
        "isBase64Encoded": False,
    }
