import json

from fastapi import HTTPException

from app.common.crud import account_crud as db
from app.common.crud import key_store_crud
from app.common.db.session import SessionLocal
from app.common.managers.jwt import decode_jwt

session = SessionLocal()


async def connect(event: dict, _context):
    # Get Authorization token from query string
    token = event.get("queryStringParameters", {}).get("Authorization", None)
    if not token:
        return {
            "statusCode": 401,
            "body": json.dumps("Unauthorized"),
            "isBase64Encoded": False,
        }

    payload = {}
    try:
        keys = await key_store_crud.get_keys(db_session=session)
        payload = await decode_jwt(token, keys)
    except HTTPException:
        return {
            "statusCode": 401,
            "body": json.dumps("Unauthorized"),
            "isBase64Encoded": False,
        }

    account_id = payload["account_id"]

    connection_id = event["requestContext"]["connectionId"]

    account = await db.get_account_by_id(account_id, session)

    if not account:
        return {
            "statusCode": 404,
            "body": json.dumps("Empresa não encontrada"),
            "isBase64Encoded": False,
        }

    await db.store_web_socket_connection(connection_id, account, session)

    return {
        "statusCode": 200,
        "body": json.dumps("Connected"),
        "isBase64Encoded": False,
    }
