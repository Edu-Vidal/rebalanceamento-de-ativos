import json
import os

import boto3

from app.utils.web_socket_utils import get_websocket_api_url


def default(event, _context):
    client = boto3.client(
        "apigatewaymanagementapi",
        endpoint_url=get_websocket_api_url(os.getenv("STAGE", "dev")),
        region_name=os.getenv("AWS_REGION", "sa-east-1"),
    )
    connection_id = event["requestContext"]["connectionId"]

    client.post_to_connection(ConnectionId=connection_id, Data=b"Connected")
    return {"statusCode": 200, "isBase64Encoded": False, "body": json.dumps("OK")}
