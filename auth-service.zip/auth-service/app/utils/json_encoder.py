import json
from datetime import datetime
from uuid import UUID

from sqlmodel import SQLModel


class BaseModelEncoder(json.JSONEncoder):
    def default(self, obj):
        if isinstance(obj, datetime):
            return obj.strftime("%Y-%m-%d %H:%M:%S")
        if isinstance(obj, UUID):
            return str(obj)
        if isinstance(obj, SQLModel):
            return json.dumps(obj.dict(), cls=BaseModelEncoder)
        return json.JSONEncoder.default(self, obj)
