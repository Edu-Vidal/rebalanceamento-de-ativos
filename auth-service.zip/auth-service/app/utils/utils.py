import base64
import os
from datetime import date, datetime, timedelta

from aws_lambda_powertools import Logger, Metrics, Tracer
from aws_xray_sdk.core.patcher import SUPPORTED_MODULES
from cryptography.hazmat.backends import default_backend
from cryptography.hazmat.primitives import serialization

logger: Logger = Logger()
metrics: Metrics = Metrics()
metrics.set_default_dimensions(environment=os.getenv("STAGE", "dev"))
tracer = Tracer(auto_patch=False)
modules_to_patch = [
    m for m in SUPPORTED_MODULES if m not in ("aioboto3", "aiobotocore")
]  # https://github.com/aws/aws-xray-sdk-python/issues/164


def bytes_to_base_64(bytes: bytes) -> str:
    # Responsável por converter bytes para base64
    return base64.b64encode(bytes).decode("utf-8")


def base_64_to_bytes(b64: str) -> bytes:
    # Responsável por converter base64 para bytes
    return base64.b64decode(b64)


def create_public_pem_key(private_key: str) -> str:
    # Responsável por criar chave pública a partir da chave privada
    public_pem_bytes = (
        serialization.load_pem_private_key(
            base_64_to_bytes(private_key), password=None, backend=default_backend()
        )
        .public_key()
        .public_bytes(
            encoding=serialization.Encoding.PEM,
            format=serialization.PublicFormat.SubjectPublicKeyInfo,
        )
    )

    return bytes_to_base_64(public_pem_bytes)


def get_week_start() -> datetime:
    # Retorna último domingo
    return datetime.now() - timedelta(days=(date.today().isoweekday() % 7))
