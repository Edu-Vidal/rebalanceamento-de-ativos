import os
from collections.abc import Generator

import boto3
from dyntastic import A
from fastapi import HTTPException, status

from .models.account import Account, AccountCreate, AccountUpdatePayload
from .models.table import DynamodbItem, EntityType
from .models.user import (
    User,
    UserCreate,
    UserUpdatePayload,
    UserUpdateSensitivePayload,
)


class DynamoDatabase:
    TABLE_NAME = os.environ.get("DYNAMODB_TABLE_NAME", "")
    ENDPOINT_URL = os.environ.get("DYNAMODB_ENDPOINT_URL", None)
    REGION = os.environ.get("DYNAMODB_REGION", "us-east-1")

    dynamodb = boto3.client("dynamodb", endpoint_url=ENDPOINT_URL)

    def create_account(self, account_create: AccountCreate) -> Account:
        try:
            account_create.save(condition=A("account_id").not_exists())
        except self.dynamodb.exceptions.ConditionalCheckFailedException as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Conta já existe. Verifique os dados e tente novamente.",
            ) from e

        return Account(**account_create.dict())

    def get_account(self, account_id: str) -> Account:
        item = Account.safe_get(
            hash_key=f"ACC#{account_id}", range_key=f"ACC#{account_id}"
        )

        if not item:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Conta não encontrada. Verifique os parâmetros inseridos.",
            )
        return item

    def update_account(
        self, account_id: str, update_payload: AccountUpdatePayload
    ) -> Account:
        account = self.get_account(account_id)

        try:
            actions_expression = [
                A(k).set(v) for k, v in update_payload.dict(exclude_none=True).items()
            ]
            account.update(
                *actions_expression,
                condition=A("deleted").eq(False),
                refresh=True,
                require_condition=True,
            )
        except self.dynamodb.exceptions.ConditionalCheckFailedException as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Erro durante atualização. Conta foi removida.",
            ) from e

        # Remove dos usuários as permissões perdidas da conta
        # Permissões adicionadas não são propagadas
        if update_payload.services:
            permissions_to_remove = set(account.services) - set(update_payload.services)
            if permissions_to_remove:
                users = self.get_users(account_id)
                self.dynamodb.transact_write_items(
                    TransactItems=[
                        {
                            "Update": {
                                "TableName": self.TABLE_NAME,
                                "Key": {
                                    "PK": {"S": user.PK},
                                    "SK": {"S": user.SK},
                                },
                                "UpdateExpression": "SET #acl :acl",
                                "ExpressionAttributeNames": {"#acl": "acl"},
                                "ExpressionAttributeValues": {
                                    ":acl": {
                                        "L": [
                                            {"S": service}
                                            for service in set(user.acl)
                                            - permissions_to_remove
                                        ]
                                    }
                                },
                            }
                        }
                        for user in users
                    ]
                )

        return account

    def delete_account(self, account_id: str) -> None:
        # Busca entidades usuário e conta para deleção
        items = DynamodbItem.query(
            A("PK").eq(f"ACC#{account_id}"),
            filter_condition=(
                A("entity_type").eq(EntityType.ACCOUNT)
                | A("entity_type").eq(EntityType.USER)
            ),
        )
        # Ação propaga, feitas/desfeitas todas juntas
        self.dynamodb.transact_write_items(
            TransactItems=[
                {
                    "Update": {
                        "TableName": self.TABLE_NAME,
                        "Key": {
                            "PK": {"S": item.PK},
                            "SK": {"S": item.SK},
                        },
                        "UpdateExpression": "SET #deleted = :deleted",
                        "ExpressionAttributeNames": {"#deleted": "deleted"},
                        "ExpressionAttributeValues": {":deleted": {"BOOL": True}},
                    }
                }
                for item in items
            ]
        )

    def deactivate_account(self, account_id: str) -> None:
        # Busca entidades usuário e conta para desativar
        items = DynamodbItem.query(
            A("PK").eq(f"ACC#{account_id}"),
            filter_condition=(
                A("entity_type").eq(EntityType.ACCOUNT)
                | A("entity_type").eq(EntityType.USER)
            ),
        )
        # Ação propaga, feitas/desfeitas todas juntas
        self.dynamodb.transact_write_items(
            TransactItems=[
                {
                    "Update": {
                        "TableName": self.TABLE_NAME,
                        "Key": {
                            "PK": {"S": item.PK},
                            "SK": {"S": item.SK},
                        },
                        "UpdateExpression": "SET #active = :active",
                        "ExpressionAttributeNames": {"#active": "active"},
                        "ExpressionAttributeValues": {":active": {"BOOL": False}},
                    }
                }
                for item in items
            ]
        )

    def get_accounts(self) -> Generator[Account, None, None]:
        yield from Account.query(
            A("GSI1-PK").eq("ACC") & A("GSI1-SK").begins_with("ACC#"), index="GSI1"
        )

    def create_user(self, user_create: UserCreate) -> User:
        try:
            user_create.save(condition=A("user_id").not_exists())
        except self.dynamodb.exceptions.ConditionalCheckFailedException as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Usuário já existe. Verifique os dados e tente novamente.",
            ) from e

        return User(**user_create.dict())

    def get_user(
        self, user_id: str | None = None, user_name: str | None = None
    ) -> User:
        if not user_id and not user_name:
            raise ValueError("É necessário informar user_id ou user_name")
        user = None
        if user_id:
            user = next(
                User.query(
                    A("GSI1-PK").eq("USER") & A("GSI1-SK").eq(f"USER#{user_id}"),
                    index="GSI1",
                ),
                None,
            )
        else:
            user = next(
                User.query(
                    A("GSI1-PK").eq("USER") & A("GSI1-SK").begins_with("USER#"),
                    index="GSI1",
                    filter_condition=A("user_name").eq(user_name),
                ),
                None,
            )
        if not user:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Usuário não encontrado",
            )

        return user

    def get_users(self, account_id: str | None = None) -> Generator[User, None, None]:
        if not account_id:
            yield from User.query(
                A("GSI1-PK").eq("USER") & A("GSI1-SK").begins_with("USER#"),
                index="GSI1",
            )
        else:
            yield from User.query(
                A("PK").eq(f"ACC#{account_id}") & A("SK").begins_with("USER#")
            )

    def update_user(
        self,
        user_id: str,
        update_payload: UserUpdatePayload | UserUpdateSensitivePayload,
    ) -> User:
        user = self.get_user(user_id)

        try:
            actions_expression = [
                A(k).set(v) for k, v in update_payload.dict(exclude_none=True).items()
            ]
            user.update(
                *actions_expression,
                condition=A("deleted").eq(False),
                refresh=True,
                require_condition=True,
            )
        except self.dynamodb.exceptions.ConditionalCheckFailedException as e:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail="Erro durante atualização. Usuário foi removido.",
            ) from e

        return user

    def delete_user(self, user_id: str) -> None:
        user = self.get_user(user_id)
        user.update(A("deleted").set(True), refresh=False)

    def store_web_socket_connection(self, connection_id: str, account_id: str) -> None:
        account = self.get_account(account_id)
        account.update(
            A("websocket_connection_ids").append(connection_id), refresh=False
        )

    def delete_web_socket_connection(self, connection_id: str, account_id: str) -> None:
        account = self.get_account(account_id)
        account.update(
            A("websocket_connection_ids").remove(
                account.websocket_connection_ids.index(connection_id)
            ),
            refresh=False,
        )

    def get_web_socket_connections(self, account_id: str) -> set[str]:
        account = self.get_account(account_id)
        return set(account.websocket_connection_ids)


def main():
    # Script para listar todos os usuários que possuem user_name duplicado
    users = DynamoDatabase().get_users()

    for user in users:
        if user.user_name == "marcelo-fret":
            print(user)


if __name__ == "__main__":
    main()
