from datetime import datetime
from uuid import UUID, uuid4

from pydantic import Extra, Field, root_validator, validator

from .base_model import BaseModel
from .enum import RoleType, ServiceType
from .table import DynamodbItem, EntityType


class User(DynamodbItem):
    user_id: str
    account_id: str
    account_name: str
    user_name: str
    email: str
    role: RoleType
    acl: list[ServiceType]
    active: bool
    deleted: bool
    hashed_password: str
    salt: str
    two_factor_authentication: bool
    backup_codes: list[str]
    totp_secret: str
    created_at: datetime
    updated_at: datetime

    entity_type: EntityType = Field(default=EntityType.USER, const=True)

    # Migration
    incomplete_registration: bool = Field(default=False)

    @root_validator
    def set_pk_and_sk(cls, values: dict):  # noqa: N805
        values["PK"] = f"ACC#{values['account_id']}"
        values["SK"] = f"USER#{values['user_id']}"
        values["GSI1PK"] = "USER"
        values["GSI1SK"] = f"USER#{values['user_id']}"

        return values

    class Config:
        extra = "ignore"
        validate_assignment = True
        orm_mode = True
        json_encoders = {
            datetime: lambda x: x.isoformat(),
        }


class UserCreate(User):
    user_id: str = Field(default_factory=lambda: str(uuid4()), const=True)

    active: bool = Field(default=True)
    deleted: bool = Field(default=False)
    acl: list[ServiceType] = Field(default=[])
    two_factor_authentication: bool = Field(default=False)

    created_at: datetime = Field(default_factory=datetime.utcnow, const=True)
    updated_at: datetime = Field(default_factory=datetime.utcnow, const=True)

    backup_codes: list[str] = Field(default=[], const=True)
    totp_secret: str = Field(default="", const=True)

    @validator("account_id")
    def validate_account_id(cls, v: str):  # noqa N805
        if not UUID(v, version=4):
            raise ValueError("Invalid UUID")
        return v


class UserUpdatePayload(BaseModel):
    user_name: str | None = None
    email: str | None = None
    role: RoleType | None = None
    acl: list[ServiceType] | None = None

    updated_at: datetime = Field(default_factory=datetime.utcnow, const=True)

    two_factor_authentication: bool | None = None
    active: bool | None = None
    deleted: bool | None = None

    class Config:
        extra = Extra.forbid
        json_encoders = {
            datetime: lambda v: v.isoformat(),
        }


class UserUpdateSensitivePayload(UserUpdatePayload):
    hashed_password: str | None = Field(default=None)
    salt: str | None = Field(default=None)
    backup_codes: list[str] | None = Field(default=None)
    totp_secret: str | None = Field(default=None)
