from datetime import datetime

from pydantic import BaseModel as PydanticBaseModel


class BaseModel(PydanticBaseModel):
    def dynamodb_payload(self, *args, **kwargs):
        payload = super().dict(*args, **kwargs)
        for key, value in payload.items():
            if isinstance(value, datetime):
                payload[key] = value.isoformat(timespec="seconds")
        return payload

    class Config:
        json_encoders = {
            datetime: lambda x: x.isoformat(timespec="seconds"),
        }
