import os
from enum import Enum

from dyntastic import Dyntastic
from pydantic import Extra, Field


class EntityType(str, Enum):
    ACCOUNT = "ACCOUNT"
    USER = "USER"
    CHECK = "CHECK"
    INVOICE = "INVOICE"


class DynamodbIndex(str, Enum):
    GSI1 = "GSI1"
    LSI1 = "LSI1"
    LSI2 = "LSI2"


# Implementation of DynamoDB uses a single table design
class DynamodbItem(Dyntastic):
    # __table_name__ = os.environ["DYNAMODB_TABLE_NAME", ""]
    __table_name__ = os.getenv("DYNAMODB_TABLE_NAME", "")
    __table_host__ = os.getenv("DYNAMODB_ENDPOINT_URL", "")

    __hash_key__ = "PK"
    __range_key__ = "SK"

    PK: str | None = None
    SK: str | None = None
    GSI1PK: str | None = Field(default=None, alias="GSI1-PK", title="GSI1-PK")
    GSI1SK: str | None = Field(default=None, alias="GSI1-SK", title="GSI1-SK")
    LSI1SK: str | None = Field(default=None, alias="LSI1-SK", title="LSI1-SK")
    LSI2SK: str | None = Field(default=None, alias="LSI2-SK", title="LSI2-SK")
    entity_type: EntityType | None = None

    class Config:
        extra = Extra.allow
