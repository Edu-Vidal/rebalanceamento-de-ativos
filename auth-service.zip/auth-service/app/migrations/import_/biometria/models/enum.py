from enum import Enum


class RoleType(str, Enum):
    SA = "SA"  # Super Admin
    ADMIN = "ADMIN"
    USER = "USER"


class ServiceType(str, Enum):
    UNICO = "UNICO"
    SGRLOC = "SGRLOC"


class DocumentType(str, Enum):
    CPF = "CPF"
