from datetime import datetime
from uuid import uuid4

from pydantic import Extra, Field, root_validator, validator

from app.utils.validators import is_cnpj_valid

from .base_model import BaseModel
from .enum import ServiceType
from .table import DynamodbItem, EntityType
from .user import User


class Account(DynamodbItem):
    account_id: str
    account_name: str
    active: bool
    deleted: bool
    services: list[ServiceType]
    cnpj: str
    websocket_connection_ids: list[str]
    created_at: datetime
    updated_at: datetime
    users: list[User] = Field(default=[])

    entity_type: EntityType = Field(default=EntityType.ACCOUNT, const=True)

    # Migration
    incomplete_registration: bool = Field(default=False)

    @root_validator
    def set_pk_and_sk(cls, values: dict):  # noqa: N805
        values["PK"] = f"ACC#{values['account_id']}"
        values["SK"] = f"ACC#{values['account_id']}"
        values["GSI1PK"] = "ACC"
        values["GSI1SK"] = f"ACC#{values['account_id']}"
        values["LSI1SK"] = f"ACC#{values['account_name']}"
        return values

    @validator("cnpj")
    def format_cnpj(cls, v: str):  # noqa N805
        if not is_cnpj_valid(v):
            raise ValueError("Invalid CNPJ")

        # Remove caracteres não numéricos
        v = "".join(filter(str.isdigit, v))
        # Formata CNPJ
        v = f"{v[:2]}.{v[2:5]}.{v[5:8]}/{v[8:12]}-{v[12:]}"

        return v

    class Config:
        extra = Extra.ignore
        validate_assignment = True
        orm_mode = True
        json_encoders = {
            datetime: lambda x: x.isoformat(),
        }


class AccountCreate(Account):
    account_id: str = Field(default_factory=lambda: str(uuid4()), const=True)
    created_at: datetime = Field(default_factory=datetime.utcnow, const=True)
    updated_at: datetime = Field(default_factory=datetime.utcnow, const=True)

    active: bool = Field(default=True)
    deleted: bool = Field(default=False)
    services: list[ServiceType] = Field(default=[])
    websocket_connection_ids: list[str] = Field(default=[])


class AccountUpdatePayload(BaseModel):
    account_name: str | None = None
    cnpj: str | None = None
    services: list[ServiceType] | None = None
    active: bool | None = None

    updated_at: datetime = Field(default_factory=datetime.utcnow, const=True)

    @validator("cnpj")
    def format_cnpj(cls, v: str):  # noqa N805
        if not v:
            return v
        if not is_cnpj_valid(v):
            raise ValueError("Invalid CNPJ")

        # Remove caracteres não numéricos
        v = "".join(filter(str.isdigit, v))
        # Formata CNPJ
        v = f"{v[:2]}.{v[2:5]}.{v[5:8]}/{v[8:12]}-{v[12:]}"

        return v

    class Config:
        extra = "ignore"
        validate_assignment = True
        json_encoders = {
            datetime: lambda x: x.isoformat(),
        }
