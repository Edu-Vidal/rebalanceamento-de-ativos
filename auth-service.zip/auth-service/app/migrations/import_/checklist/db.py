# https://stackoverflow.com/questions/75252097/fastapi-testing-runtimeerror-task-attached-to-a-different-loop/75444607#75444607
import os
from collections.abc import AsyncGenerator

from sqlalchemy.engine import URL
from sqlalchemy.ext.asyncio import AsyncSession, create_async_engine
from sqlalchemy.orm import sessionmaker
from sqlalchemy.sql import text

POOL_SIZE = 30

DATABASE_URL = URL.create(
    drivername="mysql+asyncmy",
    username=os.getenv("CHECKLIST_DB_USER", "mysql"),
    password=os.getenv("CHECKLIST_DB_PASSWORD", "pass"),
    host=os.getenv("CHECKLIST_DB_HOST", "localhost"),
    port=int(os.getenv("CHECKLIST_DB_PORT", "3306")),
    database=os.getenv("CHECKLIST_DB", "mysql"),
)

connect_args = {"check_same_thread": False}

engine = create_async_engine(
    DATABASE_URL,
    echo=False,
    echo_pool=False,
    future=True,
    pool_size=POOL_SIZE,
)

SessionLocal = sessionmaker(
    autocommit=False,
    autoflush=False,
    bind=engine,
    class_=AsyncSession,
    expire_on_commit=False,
)


async def get_local_session() -> AsyncGenerator[AsyncSession, None]:
    """
    Get a local session independent of fastapi_async_sqlalchemy's db.session.
    Which depends on fastapi's execution context.
    """
    async with SessionLocal() as session:
        yield session


async def get_companies():
    async with SessionLocal() as session:
        stmt = text("""SELECT * FROM rentalCompany""")
        companies = await session.execute(stmt)

    return [company._asdict() for company in companies.all()]


async def get_users():
    stmt = text(
        """
    SELECT info.id as id, role, document, created_at, updated_at, rental_company_id,
       phone, username, name, info.email, password, is_active as active,
       address_id
        from userApp as info
            JOIN auth_user as auth
                ON info.user_app_id = auth.id"""
    )
    async with SessionLocal() as session:
        users = await session.execute(stmt)

    # Retorna dicionário com os dados dos usuários
    return [user._asdict() for user in users.all()]


async def get_addresses():
    async with SessionLocal() as session:
        stmt = text("""SELECT * FROM address""")
        addresses = await session.execute(stmt)

    return [address._asdict() for address in addresses.all()]


async def get_cities():
    async with SessionLocal() as session:
        stmt = text("""SELECT * FROM city""")
        cities = await session.execute(stmt)

    result = cities.all()

    return result


async def get_states():
    async with SessionLocal() as session:
        stmt = text("""SELECT * FROM state""")
        states = await session.execute(stmt)

    result = states.all()

    return result
