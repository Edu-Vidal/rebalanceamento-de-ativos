import asyncio
import random

from pydantic import EmailStr

import app.migrations.import_.checklist.db as checklist_db
from app.common.crud import role_crud
from app.common.db.session import SessionLocal
from app.common.models.enum import ServiceType
from app.common.models.tables import Account, Address, User
from app.migrations.import_.biometria.dynamo import DynamoDatabase
from app.migrations.import_.biometria.models.account import Account as dynamoAccount
from app.migrations.import_.biometria.models.enum import RoleType as DynamoRoleType
from app.migrations.import_.biometria.models.enum import (
    ServiceType as DynamoServiceType,
)
from app.utils.validators import is_cnpj_valid, is_cpf_valid

dynamo = DynamoDatabase()


def gera_cnpj(punctuation=False):
    n = [random.randrange(10) for i in range(8)] + [0, 0, 0, 1]
    v = [2, 3, 4, 5, 6, 7, 8, 9, 2, 3, 4, 5, 6]
    # calcula dígito 1 e acrescenta ao total
    s = sum(x * y for x, y in zip(reversed(n), v, strict=False))
    d1 = 11 - s % 11
    if d1 >= 10:
        d1 = 0
    n.append(d1)
    # idem para o dígito 2
    s = sum(x * y for x, y in zip(reversed(n), v, strict=False))
    d2 = 11 - s % 11
    if d2 >= 10:
        d2 = 0
    n.append(d2)
    if punctuation:
        return "%d%d.%d%d%d.%d%d%d/%d%d%d%d-%d%d" % tuple(n)
    return "%d%d%d%d%d%d%d%d%d%d%d%d%d%d" % tuple(n)


def gera_cpf(punctuation=False):
    # Gerando os nove primeiros dígitos do CPF de forma aleatória
    num = [random.randint(0, 9) for _ in range(9)]

    # Cálculo do primeiro dígito verificador
    soma = sum(x * (10 - i) for i, x in enumerate(num))
    num.append((soma * 10 % 11) % 10)

    # Cálculo do segundo dígito verificador
    soma = sum(x * (11 - i) for i, x in enumerate(num))
    num.append((soma * 10 % 11) % 10)

    # Transformando os números em uma string
    num_str = "".join(map(str, num))

    # Formatação opcional com pontuação
    if punctuation:
        return f"{num_str[:3]}.{num_str[3:6]}.{num_str[6:9]}-{num_str[9:]}"
    else:
        return num_str


async def join_biometria_checklist(
    biometria_data: list[dynamoAccount],
    checklist_data,
) -> list[Account]:
    async with SessionLocal() as session:
        roles = await role_crud.get_roles(db_session=session)

    role_sa = next((role for role in roles if role.name == "sa"), None)
    role_admin = next((role for role in roles if role.name == "admin"), None)
    role_user = next((role for role in roles if role.name == "user"), None)
    biometria_role_equivalence = {
        DynamoRoleType.SA: role_sa,
        DynamoRoleType.ADMIN: role_admin,
        DynamoRoleType.USER: role_user,
    }
    checklist_role_equivalence = {
        "GESTOR": role_admin,
        "COLABORADOR": role_user,
        "SUPER_ADMIN": role_sa,
    }
    companies = []
    for company in biometria_data:
        cnpj = company.cnpj
        checklist_company = next((c for c in checklist_data if c["cnpj"] == cnpj), None)
        if checklist_company is None:
            # ----------- Locadora não existe em Checklist ------------
            # Cria locadora com acesso somente ao Biometria,
            # Campo "incomplete_registration" = True
            account = Account(
                corporate_name=company.account_name,
                trade_name=company.account_name,
                cnpj=company.cnpj,
                responsible_name="Placeholder",
                responsible_document="82820786030",
                responsible_phone="(84) 2559-8994",
                active=company.active,
                deleted=company.deleted,
                services=[
                    ServiceType.SGRLOC
                    if service == DynamoServiceType.SGRLOC
                    else ServiceType.BIOMETRIA
                    for service in company.services
                ],
                incomplete_registration=True,
                created_at=company.created_at,
            )
            account_address = Address(
                street="Placeholder",
                number="123",
                complement="Placeholder",
                neighborhood="Placeholder",
                zip_code="Placeholder",
                city_id=1,
                state_id=13,
            )
            account.address = account_address

            users = []
            for user in company.users:
                users.append(
                    User(
                        user_name=user.user_name,
                        name=user.user_name,
                        email=EmailStr(user.email),
                        phone="(84) 2559-8994",
                        document="82820786030",
                        active=user.active,
                        deleted=user.deleted,
                        acl=[
                            ServiceType.SGRLOC
                            if service == DynamoServiceType.SGRLOC
                            else ServiceType.BIOMETRIA
                            for service in user.acl
                        ],
                        password=user.hashed_password,
                        two_factor_authentication=user.two_factor_authentication,
                        backup_codes=user.backup_codes,
                        totp_secret=user.totp_secret,
                        created_at=user.created_at,
                        address=account_address,
                        role=biometria_role_equivalence[user.role],
                        incomplete_registration=True,
                    )
                )
            account.users = users
            companies.append(account)
            continue
        # ----------------------------------------------------------
        # -------- Locadora existe em Biometria e Checklist --------
        # Cria locadora com acesso ao Biometria, Sgrloc e Checklist
        # Dados do Checklist sobrescrevem os dados do Biometria
        account = Account(
            corporate_name=checklist_company["corporate_name"],
            trade_name=checklist_company["fantasy_name"],
            cnpj=checklist_company["cnpj"],
            responsible_name=checklist_company["responsible_name"],
            responsible_document=checklist_company["responsible_document"],
            responsible_phone=checklist_company["responsible_phone"],
            active=checklist_company["is_activated"] or company.active,
            services=[
                ServiceType.CHECKLIST,
                *[
                    ServiceType.SGRLOC
                    if service == DynamoServiceType.SGRLOC
                    else ServiceType.BIOMETRIA
                    for service in company.services
                ],
            ],
            created_at=min(
                company.created_at,
                checklist_company["created_at"],
            ),
            incomplete_registration=checklist_company.get(
                "incomplete_registration", False
            ),
        )
        address = Address(
            street=checklist_company["address"]["street"],
            number=checklist_company["address"]["number"],
            complement=checklist_company["address"]["complement"],
            neighborhood=checklist_company["address"]["neighborhood"],
            zip_code=checklist_company["address"]["zipcode"],
            city_id=checklist_company["address"]["city_id"],
            state_id=checklist_company["address"]["state_id"],
        )
        account.address = address
        users = []
        # Adiciona usuários que estão presentes no Biometria
        for user in company.users:
            concurrent_user = (
                next(
                    (
                        u
                        for u in checklist_company.get("users", [])
                        if u["username"] == user.user_name
                    ),
                    None,
                )
                if checklist_company
                else None
            )
            if concurrent_user:
                # Usuário presente em Checklist e biometria
                # Dados do Checklist sobrescrevem os dados do Biometria
                address = Address(
                    street=concurrent_user["address"]["street"],
                    number=concurrent_user["address"]["number"],
                    complement=concurrent_user["address"]["complement"],
                    neighborhood=concurrent_user["address"]["neighborhood"],
                    zip_code=concurrent_user["address"]["zipcode"],
                    city_id=concurrent_user["address"]["city_id"],
                    state_id=concurrent_user["address"]["state_id"],
                    created_at=concurrent_user["address"]["created_at"],
                )
                users.append(
                    User(
                        user_name=concurrent_user["username"],
                        name=concurrent_user["name"],
                        email=EmailStr(concurrent_user["email"]),
                        phone=concurrent_user["phone"],
                        document=concurrent_user["document"],
                        active=concurrent_user["active"] or user.active,
                        acl=[
                            ServiceType.CHECKLIST,
                            *[
                                ServiceType.SGRLOC
                                if service == DynamoServiceType.SGRLOC
                                else ServiceType.BIOMETRIA
                                for service in user.acl
                            ],
                        ],
                        password=concurrent_user["password"],
                        two_factor_authentication=user.two_factor_authentication,
                        backup_codes=user.backup_codes,
                        totp_secret=user.totp_secret,
                        address=address,
                        role=checklist_role_equivalence[concurrent_user["role"]],
                        incomplete_registration=concurrent_user.get(
                            "incomplete_registration", False
                        )
                        or user.incomplete_registration,
                        created_at=min(
                            user.created_at,
                            concurrent_user["created_at"],
                        ),
                    )
                )
                continue
            # Usuário presente somente em Biometria
            address = Address(
                street="Placeholder",
                number="123",
                complement="Placeholder",
                neighborhood="Placeholder",
                zip_code="Placeholder",
                city_id=1,
                state_id=13,
            )
            users.append(
                User(
                    user_name=user.user_name,
                    name=user.user_name,
                    email=EmailStr(user.email),
                    phone="(84) 2559-8994",
                    document="82820786030",
                    active=user.active,
                    deleted=user.deleted,
                    acl=[
                        ServiceType.SGRLOC
                        if service == DynamoServiceType.SGRLOC
                        else ServiceType.BIOMETRIA
                        for service in user.acl
                    ],
                    password=user.hashed_password,
                    two_factor_authentication=user.two_factor_authentication,
                    backup_codes=user.backup_codes,
                    totp_secret=user.totp_secret,
                    created_at=user.created_at,
                    address=address,
                    role=biometria_role_equivalence[user.role],
                    incomplete_registration=True,
                )
            )

        # Adiciona usuários que estão presentes no Checklist
        # que ainda não foram adicionados
        for user in checklist_company.get("users", []):
            if user["username"] in [u.user_name for u in users]:
                continue
            address = Address(
                street=user["address"]["street"],
                number=user["address"]["number"],
                complement=user["address"]["complement"],
                neighborhood=user["address"]["neighborhood"],
                zip_code=user["address"]["zipcode"],
                city_id=user["address"]["city_id"],
                state_id=user["address"]["state_id"],
            )
            users.append(
                User(
                    user_name=user["username"],
                    email=EmailStr(user["email"]),
                    name=user["name"],
                    phone=user["phone"],
                    document=user["document"],
                    active=user["active"],
                    password=user["password"],
                    backup_codes=[],
                    address=address,
                    acl=[ServiceType.CHECKLIST],
                    role=checklist_role_equivalence[user["role"]],
                    created_at=user["created_at"],
                    incomplete_registration=user.get("incomplete_registration", False),
                )
            )
        account.users = users
        companies.append(account)
    # ----------- Locadora não existe em Biometria ------------
    # Cria locadora com acesso somente ao Checklist
    # Computar lista de empresas do checklist que ainda não foram inseridas em "companies"
    added_cnpjs = ["".join(filter(str.isalnum, c.cnpj)) for c in companies]
    checklist_companies = [
        c
        for c in checklist_data
        if "".join(filter(str.isalnum, c["cnpj"])) not in added_cnpjs
    ]
    for company in checklist_companies:
        account = Account(
            corporate_name=company["corporate_name"],
            trade_name=company["fantasy_name"],
            cnpj=company["cnpj"],
            responsible_name=company["responsible_name"],
            responsible_document=company["responsible_document"],
            responsible_phone=company["responsible_phone"],
            active=company["is_activated"],
            services=[ServiceType.CHECKLIST],
            created_at=company["created_at"],
            incomplete_registration=company.get("incomplete_registration", False),
        )
        address = Address(
            street=company["address"]["street"],
            number=company["address"]["number"],
            complement=company["address"]["complement"],
            neighborhood=company["address"]["neighborhood"],
            zip_code=company["address"]["zipcode"],
            city_id=company["address"]["city_id"],
            state_id=company["address"]["state_id"],
        )
        account.address = address
        users = []
        for user in company["users"]:
            address = Address(
                street=user["address"]["street"],
                number=user["address"]["number"],
                complement=user["address"]["complement"],
                neighborhood=user["address"]["neighborhood"],
                zip_code=user["address"]["zipcode"],
                city_id=user["address"]["city_id"],
                state_id=user["address"]["state_id"],
            )
            users.append(
                User(
                    user_name=user["username"],
                    email=EmailStr(user["email"]),
                    name=user["name"],
                    phone=user["phone"],
                    document=user["document"],
                    active=user["active"],
                    password=user["password"],
                    backup_codes=[],
                    address=address,
                    acl=[ServiceType.CHECKLIST],
                    role=checklist_role_equivalence[user["role"]],
                    created_at=user["created_at"],
                    incomplete_registration=user.get("incomplete_registration", False),
                )
            )
        account.users = users
        companies.append(account)

    return companies


async def main():
    # Busca e formata dados do checklist
    checklist_companies, checklist_users, addresses = await asyncio.gather(
        checklist_db.get_companies(),
        checklist_db.get_users(),
        checklist_db.get_addresses(),
    )
    checklist_data = []
    # Agrupa usuários em suas respectivas empresas no atributo users
    for company in checklist_companies:
        users = []
        for user in checklist_users:
            if user["rental_company_id"] != company["id"]:
                continue
            for address in addresses:
                if address["id"] == user["address_id"]:
                    user["address"] = address
                    continue

            # ------- Formata dados de usuário vindo do checklist ----------
            if not is_cpf_valid(user["document"]):
                user["document"] = "82820786030"
                user["incomplete_registration"] = True

            users.append(user)
        company["users"] = users
        for address in addresses:
            if address["id"] == company["address_id"]:
                company["address"] = address
                continue

        #  ------- Formata dados de empresa vinda do checklist ----------
        if not is_cnpj_valid(company["cnpj"]):
            company["cnpj"] = gera_cnpj()
            company["incomplete_registration"] = True

        if not is_cpf_valid(company["responsible_document"]):
            company["responsible_document"] = "82820786030"
            company["incomplete_registration"] = True

        checklist_data.append(company)

    # Busca e formata dados do biometria
    biometria_companies = list(dynamo.get_accounts())
    biometria_users = list(dynamo.get_users())
    biometria_data = []
    # Agrupa usuários em suas respectivas empresas no atributo users
    for company in biometria_companies:
        users = []
        for user in biometria_users:
            if user.account_id == company.account_id:
                # Formata dados do usuário
                user.hashed_password = (
                    f"pbkdf2_sha256$1${user.salt}${user.hashed_password}"
                )

                users.append(user)
        company.users = users

        # Formata dados de empresa
        # Não é necessário, pois os dados já estão formatados

        biometria_data.append(company)

    # Agrupa dados do biometria e checklist
    companies = await join_biometria_checklist(biometria_data, checklist_data)

    # Insert companies
    async with SessionLocal() as session:
        for company in companies:
            session.add(company)
        await session.commit()


if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main())
