import asyncio

from app.common.crud.account_crud import get_accounts
from app.common.db.session import SessionLocal
from app.common.managers.account_manager import propagate_account_creation_to_services
from app.common.managers.user_manager import propagate_user_creation_to_services


async def main():
    async with SessionLocal() as session:
        accounts = await get_accounts(db_session=session, include_deleted=True)

    for account in accounts:
        await propagate_account_creation_to_services(account=account)
        users = account.users
        for user in users:
            await propagate_user_creation_to_services(user=user)


if __name__ == "__main__":
    loop = asyncio.get_event_loop()
    loop.run_until_complete(main())
