import asyncio

from aws_lambda_powertools.utilities.typing import LambdaContext

from app.api_websocket.v1.routes.connect import connect
from app.api_websocket.v1.routes.default import default
from app.api_websocket.v1.routes.disconnect import disconnect
from app.utils.utils import logger, metrics


@logger.inject_lambda_context(
    log_event=True,
    clear_state=True,
)
@metrics.log_metrics(capture_cold_start_metric=True)
def lambda_handler(event, context: LambdaContext):
    return asyncio.get_event_loop().run_until_complete(main(event, context))


async def main(event, context: LambdaContext):
    route_key = event.get("requestContext", {}).get("routeKey")

    if route_key == "$connect":
        return await connect(event, context)

    if route_key == "$disconnect":
        return disconnect(event, context)

    if route_key == "$default":
        return default(event, context)

    return {"statusCode": 200}
