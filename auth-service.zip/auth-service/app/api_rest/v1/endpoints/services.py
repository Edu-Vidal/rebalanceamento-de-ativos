from fastapi import APIRouter, Depends

from app.api_rest import deps
from app.common.crud import service_crud as db
from app.common.models.service import ServiceRead
from app.common.models.tables import User

router = APIRouter()


@router.get("/")
async def get_services(
    curr_user: User = Depends(deps.get_current_user()),
) -> list[ServiceRead]:
    """
    Serviços disponíveis.
    """
    services = await db.get_services()

    return [ServiceRead.from_orm(service) for service in services]
