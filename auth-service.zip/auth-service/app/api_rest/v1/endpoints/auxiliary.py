from fastapi import APIRouter, Depends

from app.api_rest import deps
from app.common.crud import city_crud as db
from app.common.crud import role_crud
from app.common.models.role import RoleRead
from app.common.models.tables import City, State, User

router = APIRouter()


@router.get("/states")
async def get_states(
    curr_user: User = Depends(deps.get_current_user()),
) -> list[State]:
    """
    Cidades disponíveis.
    """
    return await db.get_states()


@router.get("/cities")
async def get_cities(
    curr_user: User = Depends(deps.get_current_user()),
) -> list[City]:
    """
    Estados disponíveis.
    """
    return await db.get_cities()


@router.get("/roles")
async def get_roles(
    curr_user: User = Depends(deps.get_current_user()),
) -> list[RoleRead]:
    """
    Rota para obter todos os cargos.
    """
    return [RoleRead.from_orm(role) for role in await role_crud.get_roles()]
