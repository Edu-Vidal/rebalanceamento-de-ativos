from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from fastapi.responses import JSONResponse
from fastapi_pagination import Page, Params

from app.api_rest import deps
from app.common.crud import account_crud, address_crud, role_crud
from app.common.crud import user_crud as db
from app.common.managers import user_manager
from app.common.managers.auth import PasswordAuth
from app.common.models.address import AddressCreate, AddressUpdate
from app.common.models.enum import RoleType, ServiceType
from app.common.models.input import (
    UserCreateInput,
    UserUpdateInput,
)
from app.common.models.output import (
    CreatedUserOutput,
    Message,
    ResetPasswordOutput,
)
from app.common.models.tables import User
from app.common.models.user import UserCreate, UserRead, UserUpdate

router = APIRouter()


@router.get("/", response_model=Page[UserRead])
async def get_users(
    params: Params = Depends(),
    order_by: str = Depends(deps.get_order_by(model=UserRead), use_cache=True),
    desc: bool = True,
    user_name: str | None = None,
    email: str | None = None,
    active: bool | None = None,
    role_ids: list[int] | None = Query(None, alias="role_id"),
    services: list[ServiceType] | None = Query(None, alias="service"),
    curr_user: User = Depends(deps.get_current_user()),
) -> Page[User]:
    """
    Rota para obter todos os usuários.
    """
    user_is_admin = curr_user.role.name == RoleType.SA
    if not user_is_admin:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    return await db.get_users_paginated(
        params=params,
        order_by=order_by,
        descending=desc,
        user_name_contains=user_name,
        email_contains=email,
        active=active,
        role_ids=role_ids,
        services=services,
    )


@router.get("/{user_id}")
async def get_user(
    user_id: UUID,
    curr_user: User = Depends(deps.get_current_user()),
) -> UserRead:
    """
    Rota para obter um usuário específico.
    """
    user = await db.get_user_by_id(user_id)

    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Usuário não encontrado"
        )

    own_information = curr_user.user_id == user_id
    user_is_account_manager = (
        curr_user.account.account_id == user.account.account_id
        and curr_user.role.name == RoleType.ADMIN
    )

    if not (
        own_information or user_is_account_manager or curr_user.role.name == RoleType.SA
    ):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    return UserRead.from_orm(user)


@router.post("/")
async def create_user(
    user_create_input: UserCreateInput,
    curr_user: User = Depends(deps.get_current_user()),
) -> CreatedUserOutput:
    """
    Rota para criar um novo usuário.
    """
    user_is_account_manager = (
        curr_user.account.account_id == user_create_input.account_id
        and curr_user.role.name == RoleType.ADMIN
    )
    user_is_admin = curr_user.role.name == RoleType.SA
    if not (user_is_account_manager or user_is_admin):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    first_access_password = PasswordAuth.gen_random_string()
    password = PasswordAuth.hash_password(first_access_password)

    account = await account_crud.get_account_by_id(user_create_input.account_id)
    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Locadora não encontrada"
        )

    role = await role_crud.get_role_by_id(int(user_create_input.role_id))
    if not role:
        raise HTTPException(
            status_code=status.HTTP_400_BAD_REQUEST, detail="Cargo não encontrado"
        )

    address = await address_crud.create_address(
        AddressCreate(**user_create_input.address.dict())
    )
    user_create = UserCreate(
        account_id=account.account_id,
        name=user_create_input.name,
        phone=user_create_input.phone,
        document=user_create_input.document,
        user_name=user_create_input.user_name,
        email=user_create_input.email,
        role_id=int(user_create_input.role_id),
        acl=user_create_input.acl
        if user_create_input.acl is not None
        else account.services,
        password=password,
        address_id=address.address_id,
    )

    user = await db.create_user(user_create)

    user_created = await user_manager.propagate_user_creation_to_services(user)

    if not user_created:
        await db.remove_user_from_db(user)

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao criar usuário. Entre em contato com o suporte.",
        )

    return CreatedUserOutput(
        detail=f"Usuário {user.user_name} criado com sucesso",
        first_access_password=first_access_password,
        user=UserRead.from_orm(user),
    )


@router.patch("/{user_id}")
async def update_user(
    user_id: UUID,
    user_update_payload: UserUpdateInput,
    curr_user: User = Depends(deps.get_current_user()),
) -> UserRead:
    """
    Rota para atualizar um usuário.
    """
    user_to_update = await db.get_user_by_id(user_id)
    if not user_to_update:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Usuário não encontrado"
        )

    user_is_account_manager = (
        curr_user.account.account_id == user_to_update.account.account_id
        and curr_user.role.name == RoleType.ADMIN
    )
    user_is_admin = curr_user.role.name == RoleType.SA
    updating_own_permission = curr_user.user_id == user_id and (
        user_update_payload.role_id or user_update_payload.acl
    )
    account_has_permissions = (
        any(
            service not in user_to_update.account.services
            for service in user_update_payload.acl
        )
        if user_update_payload.acl
        else True
    )

    if not (user_is_account_manager or user_is_admin):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    if (updating_own_permission or not account_has_permissions) and not user_is_admin:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado."
        )

    if user_update_payload.address:
        address_update = AddressUpdate(**user_update_payload.address.dict())
        await address_crud.update_address(user_to_update.address, address_update)

    if user_update_payload.role_id:
        role = await role_crud.get_role_by_id(int(user_update_payload.role_id))
        if not role:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST, detail="Cargo não encontrado"
            )

    new_user = UserUpdate.from_orm(
        user_to_update, update=user_update_payload.dict(exclude_unset=True)
    )
    updated_user = await db.update_user(user_to_update, new_user)

    update_succesful = await user_manager.propagate_user_update_to_services(
        updated_user, user_to_update
    )

    if not update_succesful:
        # Reverte atualização no banco de dados
        await db.update_user(updated_user, UserUpdate.from_orm(user_to_update))

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao atualizar usuário. Entre em contato com o suporte.",
        )

    return UserRead.from_orm(updated_user)


@router.get("/{user_id}/activate", response_model=Message)
async def activate_user(
    user_id: UUID,
    curr_user: User = Depends(deps.get_current_user()),
) -> Response:
    """
    Rota para ativar uma conta específica.
    """
    user_to_activate = await db.get_user_by_id(user_id)
    if not user_to_activate:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Usuário não encontrado"
        )

    user_is_admin = curr_user.role.name == RoleType.SA
    user_is_account_manager = (
        curr_user.account.account_id == user_to_activate.account.account_id
        and curr_user.role.name == RoleType.ADMIN
    )
    if not (user_is_admin or user_is_account_manager):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    await user_manager.activate(user_to_activate)

    return JSONResponse(content={"detail": "Conta ativada com sucesso"})


@router.get("/{user_id}/deactivate", response_model=Message)
async def deactivate_user(
    user_id: UUID,
    curr_user: User = Depends(deps.get_current_user()),
) -> Response:
    """
    Rota para desativar uma conta específica.
    """
    user_to_deactivate = await db.get_user_by_id(user_id)
    if not user_to_deactivate:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Usuário não encontrado"
        )

    user_is_admin = curr_user.role.name == RoleType.SA
    user_is_account_manager = (
        curr_user.account.account_id == user_to_deactivate.account.account_id
        and curr_user.role.name == RoleType.ADMIN
    )
    if not (user_is_admin or user_is_account_manager):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    await user_manager.deactivate(user_to_deactivate)

    return JSONResponse(content={"detail": "Usuário desativado com sucesso"})


@router.delete("/{user_id}", response_model=Message)
async def delete_user(
    user_id: UUID,
    curr_user: User = Depends(deps.get_current_user()),
) -> Response:
    """
    Rota para deletar um usuário.
    """
    user_to_delete = await db.get_user_by_id(user_id)
    if not user_to_delete:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Usuário não encontrado"
        )

    user_is_admin = curr_user.role.name == RoleType.SA
    user_is_account_manager = (
        curr_user.account.account_id == user_to_delete.account.account_id
        and curr_user.role.name == RoleType.ADMIN
    )
    if not (user_is_admin or user_is_account_manager):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    await user_manager.delete(user_to_delete)

    await user_manager.propagate_user_deletion_to_services(user_to_delete)

    return JSONResponse(content={"detail": f"Usuário {user_id} deletado com sucesso"})


@router.get("/{user_id}/reset-password")
async def reset_password(
    user_id: UUID,
    curr_user: User = Depends(deps.get_current_user()),
) -> ResetPasswordOutput:
    """
    Rota para resetar a senha de um usuário.
    """
    user_is_admin = curr_user.role.name == RoleType.SA
    own_user = curr_user.user_id == user_id
    if not (own_user or user_is_admin):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    user = await db.get_user_by_id(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Usuário não encontrado"
        )

    new_password = await user_manager.reset_password(user)
    return ResetPasswordOutput(
        detail="Senha resetada com sucesso", new_password=new_password
    )


@router.post("/reset-password")
async def reset_password_by_email(
    user_email: str,
    curr_user: User = Depends(deps.get_current_user()),
) -> ResetPasswordOutput:
    """
    Rota para resetar a senha de um usuário.
    """
    users = await db.get_user_by_email(user_email)
    if len(users) > 1:
        raise HTTPException(
            status_code=status.HTTP_409_CONFLICT,
            detail="Mais de um usuário encontrado para o mesmo email. \
                Entre em contato com o suporte.",
        )
    if len(users) == 0:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Usuário não encontrado"
        )
    user = users[0]

    user_is_admin = curr_user.role.name == RoleType.SA
    own_user = curr_user.user_id == user.user_id
    if not (own_user or user_is_admin):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    new_password = await user_manager.reset_password(user)
    return ResetPasswordOutput(
        detail="Senha resetada com sucesso", new_password=new_password
    )
