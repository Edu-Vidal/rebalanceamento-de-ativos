import asyncio
from typing import Annotated

from fastapi import APIRouter, Depends, Form, Header, HTTPException, Response, status
from fastapi.responses import JSONResponse
from fastapi.security import OAuth2PasswordRequestForm

from app.api_rest import deps
from app.common.crud import user_crud
from app.common.managers import jwt, user_manager
from app.common.models.input import ChangePasswordInput, TokenInput
from app.common.models.output import (
    Message,
    OtpEnabledOutput,
    ResetBackupCodesOutput,
    TokenOutput,
)
from app.common.models.tables import User
from app.common.models.user import UserRead

router = APIRouter()


@router.post("/token")
async def login(
    form_data: Annotated[OAuth2PasswordRequestForm, Depends()],
) -> TokenOutput:
    """
    Rota para fazer aquisição de token de acesso a partir de usuário e senha.
    """
    user = await user_crud.get_user_by_name(user_name=form_data.username)

    if not user or not await user_manager.login(user, form_data.password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Usuário ou senha inválidos",
        )

    if user.two_factor_authentication:
        # Para usuário com dupla autenticação ativada é retornado um
        # token JWT com pouca duração. O token é esperado pelo endpoint de
        # dupla autenticação.
        login_token = await jwt.create_login_token(user.user_id)
        return TokenOutput(
            detail="Autenticação de dois fatores necessária",
            login_token=login_token,
        )

    token_claims = jwt.TokenClaims(
        sub=user.user_name,
        account=user.account.trade_name,
        account_id=str(user.account.account_id),
        user_id=str(user.user_id),
        role=user.role.name,
        services=user.acl,
    )
    access_token = await jwt.create_access_token(token_claims)
    refresh_token = await jwt.create_refresh_token(token_claims)

    return TokenOutput(
        detail="Login bem-sucedido",
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer",  # noqa: S106
    )


@router.post("/otp")
async def login_otp(
    otp: Annotated[str, Form(...)],
    login_token: Annotated[str, Form(...)],
) -> TokenOutput:
    """
    Rota para fazer aquisição de tokens de acesso a partir de token de uso único.
    """
    payload = await jwt.decode_jwt(login_token)
    user_id = payload["sub"]

    user = await user_crud.get_user_by_id(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Usuário não encontrado"
        )

    if not user_manager.authenticate_otp(user, otp):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Token inválido"
        )

    token_claims = jwt.TokenClaims(
        sub=user.user_name,
        account=user.account.trade_name,
        account_id=str(user.account.account_id),
        user_id=str(user.user_id),
        role=user.role.name,
        services=user.acl,
    )
    access_token, refresh_token = await asyncio.gather(
        jwt.create_access_token(token_claims), jwt.create_refresh_token(token_claims)
    )

    return TokenOutput(
        detail="Login bem-sucedido",
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer",  # noqa: S106
    )


@router.post("/backup")
async def login_backup_code(
    backup_code: Annotated[str, Form(...)],
    login_token: Annotated[str, Form(...)],
) -> TokenOutput:
    """
    Rota para fazer aquisição de tokens de acesso a partir de código de backup.
    Uso único! Token é invalidado após uso.
    """
    payload = await jwt.decode_jwt(login_token)
    user_id = payload["sub"]

    user = await user_crud.get_user_by_id(user_id)
    if not user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Usuário não encontrado"
        )

    await user_manager.use_backup_code(user, backup_code)

    token_claims = jwt.TokenClaims(
        sub=user.user_name,
        account=user.account.trade_name,
        account_id=str(user.account.account_id),
        user_id=str(user.user_id),
        role=user.role.name,
        services=user.acl,
    )
    access_token, refresh_token = await asyncio.gather(
        jwt.create_access_token(token_claims), jwt.create_refresh_token(token_claims)
    )

    return TokenOutput(
        detail="Login bem-sucedido",
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer",  # noqa: S106
    )


@router.get("/refresh-token")
async def refresh_token(
    refresh_token: str = Header(),
) -> TokenOutput:
    """
    Rota para atualizar tokens de um usuário.
    Espera receber um token de atualização válido.
    """
    refresh_token_claims = await jwt.decode_refresh_token(refresh_token)
    user_id = refresh_token_claims["user_id"]

    curr_user = await user_crud.get_user_by_id(user_id)
    if not curr_user:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Usuário não encontrado"
        )

    token_claims = jwt.TokenClaims(
        sub=curr_user.user_name,
        account=curr_user.account.trade_name,
        account_id=str(curr_user.account.account_id),
        user_id=str(curr_user.user_id),
        role=curr_user.role.name,
        services=curr_user.acl,
    )
    access_token, refresh_token = await asyncio.gather(
        jwt.create_access_token(token_claims), jwt.create_refresh_token(token_claims)
    )

    return TokenOutput(
        detail="Token atualizado",
        access_token=access_token,
        refresh_token=refresh_token,
        token_type="bearer",  # noqa: S106
    )


@router.get("/profile")
async def get_profile(
    curr_user: User = Depends(deps.get_current_user()),
) -> UserRead:
    """
    Rota para obter o perfil de um usuário.
    Espera receber um token de acesso válido.
    """
    return UserRead.from_orm(curr_user)


@router.get("/.well-known/jwks.json")
async def get_jwks() -> dict:
    """
    Rota para obter a chave pública do servidor de autenticação.
    """
    return await jwt.get_jwks()


@router.post("/{user_id}/change-password", response_model=Message)
async def change_password(
    change_password_input: ChangePasswordInput,
    curr_user: User = Depends(deps.get_current_user()),
) -> Response:
    """
    Rota para alterar a própria senha.
    """
    if not user_manager.login(curr_user, change_password_input.old_password):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED,
            detail="Senha incorreta. Tente novamente.",
        )

    await user_manager.change_password(curr_user, change_password_input.new_password)

    return JSONResponse(content={"detail": "Senha alterada com sucesso"})


# 2FA
@router.get("/otp/enable")
async def enable_otp(
    curr_user: User = Depends(deps.get_current_user()),
) -> OtpEnabledOutput:
    """
    Rota para habilitar a autenticação de dois fatores com o One Time Password.
    """
    totp_uri, backup_codes = await user_manager.setup_mfa(curr_user)
    return OtpEnabledOutput(
        detail="QRCode para geração de OTP criado com sucesso.",
        totp_uri=totp_uri,
        backup_codes=backup_codes,
    )


@router.get("/otp/disable", response_model=Message)
async def disable_otp(
    curr_user: User = Depends(deps.get_current_user()),
) -> Response:
    """
    Rota para desabilitar a autenticação de dois fatores com One Time Password.
    """
    await user_manager.disable_mfa(curr_user)
    return JSONResponse(content={"detail": "Dupla Autenticação desativada com sucesso"})


@router.post("/otp/verify", response_model=Message)
async def verify_otp(
    token_input: TokenInput,
    curr_user: User = Depends(deps.get_current_user()),
) -> Response:
    """
    Rota para verificar a geração de OTP de um usuário.
    """
    token = token_input.token

    await user_manager.confirm_mfa_setup(curr_user, token)
    return JSONResponse(content={"detail": "Dupla Autenticação ativada com sucesso"})


@router.get("/otp/reset-backup-codes")
async def reset_backup_codes(
    curr_user: User = Depends(deps.get_current_user()),
) -> ResetBackupCodesOutput:
    """
    Rota para resetar os códigos de backup de autenticação de um usuário.
    """
    backup_codes = await user_manager.reset_backup_codes(curr_user)

    return ResetBackupCodesOutput(
        detail="Códigos de backup resetados com sucesso.",
        backup_codes=backup_codes,
    )
