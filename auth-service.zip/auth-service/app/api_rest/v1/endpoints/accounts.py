from uuid import UUID

from fastapi import APIRouter, Depends, HTTPException, Query, Response, status
from fastapi.responses import JSONResponse
from fastapi_pagination import Page, Params

from app.api_rest import deps
from app.common.crud import account_crud as db
from app.common.crud import address_crud, user_crud
from app.common.managers.account_manager import (
    propagate_account_creation_to_services,
    propagate_account_update_to_services,
)
from app.common.models.account import AccountCreate, AccountRead, AccountUpdate
from app.common.models.address import AddressCreate, AddressUpdate
from app.common.models.enum import RoleType, ServiceType
from app.common.models.input import AccountCreateInput, AccountUpdateInput
from app.common.models.output import Message
from app.common.models.tables import Account, User
from app.common.models.user import UserRead

router = APIRouter()


@router.post("/")
async def create_account(
    account_create_input: AccountCreateInput,
    curr_user: User = Depends(deps.get_current_user()),
) -> AccountRead:
    """
    Rota para criar uma nova conta/locadora.
    """
    if curr_user.role.name != RoleType.SA:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    address = await address_crud.create_address(
        AddressCreate(**account_create_input.address.dict())
    )

    account_create = AccountCreate(
        corporate_name=account_create_input.corporate_name,
        trade_name=account_create_input.trade_name,
        responsible_name=account_create_input.responsible_name,
        responsible_document=account_create_input.responsible_document,
        responsible_phone=account_create_input.responsible_phone,
        cnpj=account_create_input.cnpj,
        services=account_create_input.services,
        address_id=address.address_id,
    )

    account_created = await db.create_account(account_create)

    creation_succeded = await propagate_account_creation_to_services(account_created)

    if not creation_succeded:
        await db.remove_account_from_db(account_created)
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao criar conta",
        )

    return AccountRead.from_orm(account_created)


@router.patch("/{account_id}")
async def update_account(
    account_id: UUID,
    account_update_payload: AccountUpdateInput,
    curr_user: User = Depends(deps.get_current_user()),
) -> AccountRead:
    """
    Rota para atualizar uma conta específica.
    Somente remoção de permissões são propagadas para usuários. Idempotente.
    """
    account = await db.get_account_by_id(account_id)

    #  ----- Checando Autorização -----
    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Conta não encontrada"
        )

    if curr_user.role.name != RoleType.SA and not (
        curr_user.account.account_id == account_id
        and curr_user.role.name == RoleType.ADMIN
    ):  # Usuário não é SA e não é admin da conta
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )
    if curr_user.role.name != RoleType.SA:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )  # Usuários, exceto SA, não podem atualizar permissões da própria conta
    #  --------------------------------
    if account_update_payload.address:
        address_update = AddressUpdate(**account_update_payload.address.dict())
        await address_crud.update_address(account.address, address_update)

    account_update = AccountUpdate(**account_update_payload.dict(exclude_unset=True))
    account_updated = await db.update_account(account, account_update)

    update_succesful = await propagate_account_update_to_services(
        account_updated, account
    )

    if not update_succesful:
        await db.update_account(account_updated, AccountUpdate.from_orm(account))

        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail="Erro ao atualizar conta",
        )

    return AccountRead.from_orm(account_updated)


@router.delete("/{account_id}", response_model=Message)
async def delete_account(
    account_id: UUID,
    curr_user: User = Depends(deps.get_current_user()),
) -> Response:
    """
    Rota para deletar uma conta específica.
    Contas deletadas são mantidas no banco de dados, mas não podem ser recuperadas.
    Efeito é propagado para usuários.
    """
    if curr_user.role.name != RoleType.SA:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    account = await db.get_account_by_id(account_id)
    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Conta não encontrada"
        )

    await db.delete_account(account)

    return JSONResponse(content={"detail": "Conta deletada com sucesso"})


@router.get("/{account_id}")
async def get_account(
    account_id: UUID, curr_user: User = Depends(deps.get_current_user())
) -> AccountRead:
    """
    Rota para buscar uma conta específica.
    """
    if (
        curr_user.role.name != RoleType.SA
        and curr_user.account.account_id != account_id
    ):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    account = await db.get_account_by_id(account_id)
    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Conta não encontrada"
        )
    return AccountRead.from_orm(account)


@router.get("/", response_model=Page[AccountRead])
async def get_accounts(
    params: Params = Depends(),
    curr_user: User = Depends(deps.get_current_user()),
    order_by: str = Depends(deps.get_order_by(model=AccountRead), use_cache=True),
    desc: bool = True,
    trade_name: str | None = None,
    active: bool | None = None,
    services: list[ServiceType] | None = Query(None, alias="service"),
) -> Page[Account]:
    """
    Rota para listar as contas cadastradas.
    """
    if curr_user.role.name != RoleType.SA:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    return await db.get_accounts_paginated(
        params,
        order_by=order_by,
        descending=desc,
        trade_name_contains=trade_name,
        active=active,
        services=services,
    )


@router.get("/{account_id}/activate", response_model=Message)
async def activate_account(
    account_id: UUID,
    curr_user: User = Depends(deps.get_current_user()),
) -> Response:
    """
    Rota para ativar uma conta específica.
    """
    if curr_user.role.name != RoleType.SA:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    account = await db.get_account_by_id(account_id)
    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Conta não encontrada"
        )

    await db.activate_account(account)

    return JSONResponse(content={"detail": "Conta ativada com sucesso"})


@router.get("/{account_id}/deactivate", response_model=Message)
async def deactivate_account(
    account_id: UUID,
    curr_user: User = Depends(deps.get_current_user()),
) -> Response:
    """
    Rota para desativar uma conta específica.
    """
    if curr_user.role.name != RoleType.SA:
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    account = await db.get_account_by_id(account_id)
    if not account:
        raise HTTPException(
            status_code=status.HTTP_404_NOT_FOUND, detail="Conta não encontrada"
        )

    await db.deactivate_account(account)

    return JSONResponse(content={"detail": "Conta desativada com sucesso"})


# Users
@router.get("/{account_id}/users", response_model=Page[UserRead])
async def list_account_users(
    account_id: UUID,
    params: Params = Depends(),
    curr_user: User = Depends(deps.get_current_user()),
    order_by: str = Depends(deps.get_order_by(model=UserRead), use_cache=True),
    desc: bool = True,
    user_name: str | None = None,
    email: str | None = None,
    active: bool | None = None,
    services: list[ServiceType] | None = Query(None, alias="service"),
    role_ids: list[int] | None = Query(None, alias="role_id"),
) -> Page[User]:
    """
    Rota para listar todos os usuários de uma conta específica.
    """
    if (
        curr_user.role.name != RoleType.SA
        and curr_user.account.account_id != account_id
    ):
        raise HTTPException(
            status_code=status.HTTP_401_UNAUTHORIZED, detail="Não autorizado"
        )

    return await user_crud.get_users_paginated(
        params=params,
        account_id=account_id,
        order_by=order_by,
        descending=desc,
        user_name_contains=user_name,
        email_contains=email,
        active=active,
        role_ids=role_ids,
        services=services,
    )
