from fastapi import APIRouter

from .endpoints import accounts, auth, auxiliary, services, users

router = APIRouter()
router.include_router(auth.router, tags=["Auth"])
router.include_router(accounts.router, prefix="/accounts", tags=["Accounts"])
router.include_router(users.router, prefix="/users", tags=["Users"])
router.include_router(services.router, prefix="/services", tags=["Services"])
router.include_router(auxiliary.router, prefix="/auxiliary", tags=["Auxiliary"])
