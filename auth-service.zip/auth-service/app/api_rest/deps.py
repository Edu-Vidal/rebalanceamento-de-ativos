from collections.abc import Callable
from typing import Annotated

from fastapi import Depends, HTTPException, Query, status
from fastapi.security import OAuth2PasswordBearer
from jose import JWTError
from pydantic import BaseModel

from app.common.crud import user_crud
from app.common.managers import jwt
from app.common.models.tables import User

oauth2_scheme = OAuth2PasswordBearer(tokenUrl="v1/token")


def get_current_user(
    required_roles: list[str] | None = None,
    required_permissions: list[str] | None = None,
) -> Callable[[str], User]:
    async def current_user(
        access_token: Annotated[str, Depends(oauth2_scheme)],
    ) -> User:
        try:
            payload = await jwt.decode_jwt(access_token)
        except JWTError as err:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST, detail="Token inválido"
            ) from err

        user = await user_crud.get_user_by_id(payload["user_id"])
        if not user:
            raise HTTPException(
                status_code=status.HTTP_404_UNAUTHORIZED,
                detail="Usuário não encontrado",
            )

        if not user.active or user.deleted:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST, detail="Usuário inativo"
            )

        if required_roles:
            is_valid_role = False
            for role in required_roles:
                if role == user.role.name:
                    is_valid_role = True

            if not is_valid_role:
                raise HTTPException(
                    status_code=403,
                    detail=f"Cargo {required_roles} é necessário para essa requisição",
                )

        if required_permissions:
            is_valid_permission = False
            for permission in required_permissions:
                if permission in user.acl:
                    is_valid_permission = True

            if not is_valid_permission:
                raise HTTPException(
                    status_code=403,
                    detail=f"Permissão {required_permissions} é necessária para essa requisição",
                )

        return user

    return current_user  # type: ignore


def get_order_by(model: type[BaseModel]) -> Callable[[str], str]:
    def order_by(order_by: str = Query(None)) -> str:
        valid_fields = list(model.__fields__.keys())
        if order_by:
            if order_by not in valid_fields:
                raise HTTPException(
                    status_code=400,
                    detail=f"Invalid 'order_by' field. Valid options are: {valid_fields}",
                )

        return order_by

    return order_by
