import asyncio
import json
import os

import boto3
from aws_lambda_powertools.utilities.typing import LambdaContext

from app.common.crud import account_crud as db
from app.common.db.session import SessionLocal
from app.utils.utils import logger, metrics
from app.utils.web_socket_utils import get_websocket_api_url

session = SessionLocal()


@logger.inject_lambda_context(
    log_event=True,
    clear_state=True,
)
@metrics.log_metrics(capture_cold_start_metric=True)
def lambda_handler(event, context: LambdaContext):
    asyncio.get_event_loop().run_until_complete(main(event, context))


async def main(event, context: LambdaContext):
    account_id = event["account_id"]
    api_stage = event["api_stage"]
    action = event["action"]
    data = event["data"]

    message = {
        "action": action,
        "data": data,
    }

    client = boto3.client(
        "apigatewaymanagementapi",
        endpoint_url=get_websocket_api_url(api_stage),
        region_name=os.getenv("AWS_REGION", "sa-east-1"),
    )
    account = await db.get_account_by_id(account_id, session)
    if not account:
        return {"status_code": 404}

    for connection_id in account.websocket_connection_ids:
        try:
            client.post_to_connection(
                ConnectionId=connection_id, Data=json.dumps(message).encode("utf-8")
            )
        except Exception:
            # Significa que o usuário não está mais conectado,
            # porém foi desconectado incorretamente.
            await db.delete_web_socket_connection(connection_id, account, session)

    return {"status_code": 200}
